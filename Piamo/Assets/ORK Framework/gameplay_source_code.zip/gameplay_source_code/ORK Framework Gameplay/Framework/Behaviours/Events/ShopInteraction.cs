
using ORKFramework;
using ORKFramework.Events;
using ORKFramework.Shop;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Events/Shop Interaction")]
	public class ShopInteraction : BaseInteraction, IEventStarter
	{
		public string shopSceneID = "";
		
		[ORKEditorInfo(ORKDataType.Shop)]
		public int shopID = 0;
		
		
		// faction settings
		public bool useFaction = false;
		
		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;
		
		
		// ingame
		private ShopScreen shopScreen;
		
		
		/*
		============================================================================
		Interaction type functions
		============================================================================
		*/
		public override InteractionType Type
		{
			get{ return InteractionType.Shop;}
		}
		
		
		/*
		============================================================================
		Event functions
		============================================================================
		*/
		public override void StartEvent(GameObject startingObject)
		{
			this.CancelInvoke("AutoDestroy");
			this.isInvoking = false;
			
			if(!this.eventStarted)
			{
				this.eventStarted = true;
				this.shopScreen = new ShopScreen(this, this.shopID, this.shopSceneID, this.useFaction ? this.factionID : -1);
			}
		}
		
		public void EventEnded()
		{
			this.shopScreen = null;
			this.SetVariables();
			this.eventStarted = false;
		}
		
		public void DontDestroy()
		{
		
		}
		
		public GameObject GameObject
		{
			get{ return this.gameObject;}
		}
		
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "ShopEvent.psd");
		}
	}
}
