
using ORKFramework;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class ActorEventRotator : MonoBehaviour
	{
		private Transform actor;
	
		private float time;

		private float time2;
	
		private Function interpolate;

		private Vector3 startRotation;

		private Vector3 rotationDistance;
	
		private float startY;

		private float distanceY;

		private bool rotateToPosition = false;

		private bool rotateDirection = false;
		
		private bool rotateCurve = false;
	
		private Vector3 direction = Vector3.zero;
		
		// curves
		private AnimationCurve xCurve;
		
		private AnimationCurve yCurve;
		
		private AnimationCurve zCurve;
	
		public void StopMoving()
		{
			this.actor = null;
			this.rotateToPosition = false;
			this.rotateDirection = false;
			this.interpolate = null;
			
			this.rotateCurve = false;
			this.xCurve = null;
			this.yCurve = null;
			this.zCurve = null;
		}
		
		
		/*
		============================================================================
		Rotate functions
		============================================================================
		*/
		public void RotateToPosition(Transform a, Vector3 pos, EaseType et, float t)
		{
			this.StopMoving();
		
			this.actor = a;
			this.interpolate = Interpolate.Ease(et);
			this.time = 0;
			this.time2 = t;
			
			Transform tmp = new GameObject().transform;
			tmp.position = this.actor.position;
			tmp.rotation = this.actor.rotation;
			tmp.LookAt(pos);
			this.startY = this.actor.eulerAngles.y;
			this.distanceY = tmp.eulerAngles.y - this.startY;
			if(this.distanceY >= 190)
			{
				this.distanceY -= 360;
			}
			GameObject.Destroy(tmp.gameObject);
			this.rotateToPosition = true;
		}
	
		public void Rotation(Transform a, float t, Vector3 d)
		{
			this.StopMoving();
		
			this.actor = a;
			this.time = 0;
			this.time2 = t;
			this.direction = d;
			
			this.rotateDirection = true;
		}
	
		public void Rotation(Transform a, float t, Vector3 d, EaseType et)
		{
			this.StopMoving();
		
			this.actor = a;
			this.interpolate = Interpolate.Ease(et);
			this.time = 0;
			this.time2 = t;
			this.rotationDistance = d;
			this.startRotation = this.actor.eulerAngles;
			
			this.rotateDirection = true;
		}
	
		public void RotateByCurve(Transform a, AnimationCurve xCurve, AnimationCurve yCurve, AnimationCurve zCurve, float t)
		{
			this.StopMoving();
		
			this.actor = a;
			this.startRotation = this.actor.eulerAngles;
			
			this.xCurve = xCurve;
			this.yCurve = yCurve;
			this.zCurve = zCurve;
			
			this.time = 0;
			this.time2 = t;
			
			this.rotateCurve = true;
		}
	
	
		/*
		============================================================================
		Update functions
		============================================================================
		*/
		void Update()
		{
			if(!ORK.Game.Paused)
			{
				if(this.rotateToPosition)
				{
					this.time += ORK.Game.DeltaTime;
					this.actor.eulerAngles = new Vector3(this.actor.eulerAngles.x, 
						Interpolate.Ease(this.interpolate, this.startY, this.distanceY, this.time, this.time2),
						this.actor.eulerAngles.z);
					if(this.time >= this.time2)
					{
						this.rotateToPosition = false;
					}
				}
				else if(this.rotateDirection)
				{
					float t = ORK.Game.DeltaTime;
					this.time += t;
					if(this.interpolate == null)
					{
						this.actor.Rotate(this.direction * t);
					}
					else
					{
						this.actor.eulerAngles = Interpolate.Ease(this.interpolate, this.startRotation, this.rotationDistance, this.time, this.time2);
					}
					if(this.time >= this.time2)
					{
						this.rotateDirection = false;
					}
				}
				else if(this.rotateCurve)
				{
					this.time += ORK.Game.DeltaTime;
					
					Vector3 tmp = Vector3.zero;
					if(this.xCurve != null)
					{
						tmp.x = this.xCurve.Evaluate(this.time);
					}
					if(this.yCurve != null)
					{
						tmp.y = this.yCurve.Evaluate(this.time);
					}
					if(this.zCurve != null)
					{
						tmp.z = this.zCurve.Evaluate(this.time);
					}
					
					this.actor.eulerAngles = this.startRotation + tmp;
					
					if(this.time >= this.time2)
					{
						this.rotateCurve = false;
					}
				}
			}
		}
	}
}
