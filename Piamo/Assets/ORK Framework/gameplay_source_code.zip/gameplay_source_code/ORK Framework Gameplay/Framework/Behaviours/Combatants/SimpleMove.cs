
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Simple Move")]
	public class SimpleMove : MonoBehaviour
	{
		public bool ignoreYRotation = true;
		
		public bool smooth = true;
		
		public float speedSmoothing = 10;
		
		public float rotationDamping = 6.0f;
		
		// move target
		private bool doMove = true;
		
		private Vector3 targetPosition;
		
		private float maxSpeed = 5;
		
		
		// movement
		private CharacterController controller;
		
		private Vector3 moveDirection;
		
		private float moveSpeed = 0;
		
		void Start()
		{
			this.controller = this.transform.root.GetComponentInChildren<CharacterController>();
		}
		
		void Update()
		{
			if(this.doMove)
			{
				float t = ORK.Game.DeltaMovementTime;
				
				if(this.ignoreYRotation)
				{
					this.targetPosition.y = this.transform.position.y;
				}
				
				if(this.smooth)
				{
					this.transform.rotation = Quaternion.Slerp(this.transform.rotation, 
						Quaternion.LookRotation(this.targetPosition - this.transform.position), 
						this.rotationDamping * t);
					this.moveSpeed = Mathf.Lerp(this.moveSpeed, this.maxSpeed, this.speedSmoothing * t);
				}
				else
				{
					this.transform.LookAt(this.targetPosition);
					this.moveSpeed = this.maxSpeed;
				}
				
				this.moveDirection = this.transform.TransformDirection(Vector3.forward);
				if(this.controller != null)
				{
					this.controller.Move((this.moveDirection * this.moveSpeed + Physics.gravity) * t);
				}
				else
				{
					this.transform.Translate(this.moveDirection * this.moveSpeed * t, Space.World);
				}
			}
		}
		
		
		/*
		============================================================================
		Move functions
		============================================================================
		*/
		public void MoveTo(float speed, Vector3 position)
		{
			this.maxSpeed = speed;
			this.targetPosition = position;
			this.doMove = true;
		}
		
		public void Stop()
		{
			this.doMove = false;
			if(this.controller != null)
			{
				this.controller.Move(Vector3.zero);
			}
		}
	}
}
