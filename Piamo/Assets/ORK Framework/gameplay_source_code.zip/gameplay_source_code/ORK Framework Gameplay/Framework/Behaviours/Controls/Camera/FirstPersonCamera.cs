
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera: First Person")]
	public class FirstPersonCamera : BaseCameraControl
	{
		public string onChild = "";

		public Vector3 offset = Vector3.zero;
	
		public int horizontalAxis = 0;

		public int verticalAxis = 0;
	
		public Vector2 sensitivity = new Vector2(15, 15);
	
		public bool lockCursor = false;
	
		void LateUpdate()
		{
			GameObject obj = this.CameraTarget;
			if(obj != null)
			{
				Transform target = obj.transform;
			
				if(this.lockCursor)
				{
					Screen.lockCursor = true;
				}
			
				float rotX = ORK.InputKeys.Get(this.horizontalAxis).GetAxis() * this.sensitivity.x;
				float rotY = ORK.InputKeys.Get(this.verticalAxis).GetAxis() * this.sensitivity.y;
			
				// X on player
				target.Rotate(0, rotX, 0);
			
				//  Y on camera
				Vector3 tmp = this.transform.eulerAngles;
				tmp.y = target.eulerAngles.y;
				tmp.z = 0;
				tmp.x -= rotY;
				this.transform.eulerAngles = tmp;
			
				if(this.onChild != "")
				{
					Transform t = target.Find(this.onChild);
					if(t != null)
						target = t;
				}
				this.transform.position = target.position + target.TransformDirection(this.offset);
			}
		}
	
		void OnDisable()
		{
			if(this.lockCursor)
			{
				Screen.lockCursor = false;
				Screen.showCursor = true;
			}
		}
	}
}
