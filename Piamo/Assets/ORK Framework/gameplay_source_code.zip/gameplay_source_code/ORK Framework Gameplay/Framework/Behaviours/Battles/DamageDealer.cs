
using ORKFramework;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Battles/Damage Dealer")]
	public class DamageDealer : DamageBase
	{
		public DamageDealerType type = DamageDealerType.TriggerEnter;
		
		public bool changeCollider = false;
		
		public float expand = 0;
		
		
		// always on
		public bool alwaysOn = false;
		
		[ORKEditorInfo(ORKDataType.Ability)]
		public int alwaysOnAbilityID = 0;
		
		public bool setCombatant = false;
		
		[ORKEditorInfo(ORKDataType.Faction)]
		public int factionID = 0;
	
		public CombatantGroupMember combatantSetting;
		
		
		// destroy settings
		public bool destroyAfterTime = false;
		
		public float destroyTime = 0;
		
		public bool destroyOnDamage = false;
		
		public bool destroyOnCollision = false;
		
		
		// damage settings
		// auto activate
		public bool autoField = false;
		
		public bool autoTurnBased = false;
		
		public bool autoActiveTime = false;
		
		public bool autoRealTime = false;
		
		public bool autoPhase = false;
		
		
		// target settings
		public bool oneTimeDamage = false;
		
		public bool oneTarget = false;
		
		public bool resetTargets = false;
		
		public float targetResetTime = 1;
		
		public float damageEvery = 0;
		
		
		// supported actions
		public bool baseAttack = false;
		
		public bool counterAttack = false;
		
		[ORKEditorInfo(ORKDataType.Ability)]
		public int[] abilityID = new int[0];
		
		[ORKEditorInfo(ORKDataType.Item)]
		public int[] itemID = new int[0];
		
		
		// tags
		public string[] activationTag = new string[0];
		
		
		// ingame
		private BaseAction action = null;
		
		private bool damageActive = false;
		
		private Dictionary<Combatant, float> blocked = new Dictionary<Combatant, float>();
		
		private Dictionary<Combatant, float> damageBlocked = new Dictionary<Combatant, float>();
		
		private AudioClip audioClip = null;
		
		private PlayAudioSettings audioSettings;
		
		private bool doExpand = false;
		
		
		// prefab
		private GameObject prefab = null;
		
		private float destroyPrefabAfter = 0;
		
		private float stopEmittingAfter = -1;
		
		void Start()
		{
			if(this.destroyAfterTime)
			{
				GameObject.Destroy(this.gameObject, this.destroyTime);
			}
			
			// combatant
			if(this.alwaysOn && this.setCombatant)
			{
				this.combatant = this.combatantSetting.Create(new Group(this.factionID));
				this.combatant.SetGameObjectSimple(this.gameObject);
			}
			else
			{
				this.combatant = ComponentHelper.GetCombatant(this.transform.root.gameObject);
			}
			
			if(this.alwaysOn && this.combatant != null)
			{
				AbilityShortcut ability = this.combatant.Abilities.GetUseable(this.alwaysOnAbilityID);
				if(ability != null)
				{
					this.SetAction(new AbilityAction(this.combatant, ability));
					if(this.action != null)
					{
						DamageDealerActivation ddActivation = this.action.GetDamageDealerActivation();
						if(ddActivation != null)
						{
							ddActivation.Add(this, this.combatant);
						}
						this.SetDamageActive(true, new string[0]);
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public void SetAudioClip(AudioClip a, PlayAudioSettings aset)
		{
			this.audioClip = a;
			this.audioSettings = aset;
		}
		
		public void SetAudioType(int typeID, PlayAudioSettings aset)
		{
			this.audioClip = this.Combatant.Animations.GetAudioClip(typeID);
			this.audioSettings = aset;
		}
		
		public void SetPrefab(GameObject p, float t, float emitTime)
		{
			this.prefab = p;
			this.destroyPrefabAfter = t;
			this.stopEmittingAfter = emitTime;
		}
		
		public void SetAction(BaseAction a)
		{
			this.action = a;
			if(this.action != null && this.action.user != null && 
				this.combatant == null)
			{
				this.combatant = this.action.user;
			}
		}
		
		public void SetDamageActive(bool dmg, string[] tags)
		{
			this.damageActive = dmg;
			if(this.damageActive)
			{
				this.doExpand = true;
				if(!this.alwaysOn && (this.action == null || 
					(!this.CheckTags(tags) && !this.action.CheckDamageDealer(this))))
				{
					this.damageActive = false;
				}
			}
			if(!this.damageActive)
			{
				this.doExpand = false;
				this.blocked = new Dictionary<Combatant, float>();
				this.damageBlocked = new Dictionary<Combatant, float>();
				this.audioClip = null;
				this.audioSettings = null;
				this.prefab = null;
			}
		}
		
		private bool CheckTags(string[] tags)
		{
			for(int i=0; i<tags.Length; i++)
			{
				for(int j=0; j<this.activationTag.Length; j++)
				{
					if(tags[i] == this.activationTag[j])
					{
						return true;
					}
				}
			}
			return false;
		}
		
		private void DoDamage(GameObject obj, Vector3 position, Quaternion rotation)
		{
			if(this.action != null)
			{
				DamageZone zone = obj.GetComponent<DamageZone>();
				if(zone != null && this.action.CanDamage(zone.Combatant) &&
					(!this.oneTimeDamage || !this.blocked.ContainsKey(zone.Combatant)) &&
					(!this.oneTarget || this.blocked.Count == 0 || 
					(this.blocked.Count == 1 && this.blocked.ContainsKey(zone.Combatant))) &&
					(this.damageEvery == 0 || !this.damageBlocked.ContainsKey(zone.Combatant)))
				{
					zone.Damage(this.action);
					if(this.prefab != null)
					{
						GameObject pref = (GameObject)GameObject.Instantiate(this.prefab, position, rotation);
						if(this.stopEmittingAfter >= 0)
						{
							ComponentHelper.EmitParticles(pref, false);
						}
						if(this.destroyPrefabAfter > 0)
						{
							GameObject.Destroy(pref, this.destroyPrefabAfter);
						}
					}
					if(this.audioClip != null)
					{
						this.audioSettings.PlayAudio(obj, this.audioClip);
					}
					
					if(!this.blocked.ContainsKey(zone.Combatant))
					{
						this.blocked.Add(zone.Combatant, this.resetTargets ? this.targetResetTime : Mathf.Infinity);
					}
					if(!this.damageBlocked.ContainsKey(zone.Combatant))
					{
						this.damageBlocked.Add(zone.Combatant, this.damageEvery);
					}
					
					if(this.destroyOnDamage)
					{
						GameObject.Destroy(this.gameObject);
					}
				}
			}
		}
		
		public bool CheckOrigin(Transform t)
		{
			bool ok = this.transform.root != t;
			if(ok && this.combatant != null && 
				this.combatant.GameObject != null)
			{
				ok = this.combatant.GameObject.transform.root != t;
			}
			return ok;
		}
		
		void Update()
		{
			if(this.damageEvery > 0)
			{
				List<Combatant> keys = new List<Combatant>(this.damageBlocked.Keys);
				for(int i=0; i<keys.Count; i++)
				{
					this.damageBlocked[keys[i]] -= ORK.Game.DeltaBattleTime;
					if(this.damageBlocked[keys[i]] <= 0)
					{
						this.damageBlocked.Remove(keys[i]);
					}
				}
			}
			if(this.resetTargets)
			{
				List<Combatant> keys = new List<Combatant>(this.blocked.Keys);
				for(int i=0; i<keys.Count; i++)
				{
					this.blocked[keys[i]] -= ORK.Game.DeltaBattleTime;
					if(this.blocked[keys[i]] <= 0)
					{
						this.blocked.Remove(keys[i]);
					}
				}
			}
			if(this.collider != null && this.changeCollider && this.doExpand)
			{
				float change = expand * ORK.Game.DeltaBattleTime;
				if(this.collider is BoxCollider)
				{
					BoxCollider bc = this.collider as BoxCollider;
					bc.size += new Vector3(change, change, change);
				}
				else if(this.collider is SphereCollider)
				{
					SphereCollider sc = this.collider as SphereCollider;
					sc.radius += change;
				}
				else if(this.collider is CapsuleCollider)
				{
					CapsuleCollider cc = this.collider as CapsuleCollider;
					cc.radius += change;
					cc.height += change;
				}
			}
		}
		
		
		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		void OnTriggerEnter(Collider other)
		{
			if(this.damageActive && DamageDealerType.TriggerEnter.Equals(this.type) &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other.gameObject, other.transform.position, other.transform.rotation);
				if(this.destroyOnCollision)
				{
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		void OnTriggerExit(Collider other)
		{
			if(this.damageActive && DamageDealerType.TriggerExit.Equals(this.type) &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other.gameObject, other.transform.position, other.transform.rotation);
				if(this.destroyOnCollision)
				{
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		void OnTriggerStay(Collider other)
		{
			if(this.damageActive && DamageDealerType.TriggerStay.Equals(this.type) &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other.gameObject, other.transform.position, other.transform.rotation);
				if(this.destroyOnCollision)
				{
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		
		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		void OnTriggerEnter2D(Collider2D other)
		{
			if(this.damageActive && DamageDealerType.TriggerEnter.Equals(this.type) &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other.gameObject, other.transform.position, other.transform.rotation);
				if(this.destroyOnCollision)
				{
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		void OnTriggerExit2D(Collider2D other)
		{
			if(this.damageActive && DamageDealerType.TriggerExit.Equals(this.type) &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other.gameObject, other.transform.position, other.transform.rotation);
				if(this.destroyOnCollision)
				{
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		void OnTriggerStay2D(Collider2D other)
		{
			if(this.damageActive && DamageDealerType.TriggerStay.Equals(this.type) &&
				this.CheckOrigin(other.transform.root))
			{
				this.DoDamage(other.gameObject, other.transform.position, other.transform.rotation);
				if(this.destroyOnCollision)
				{
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		
		/*
		============================================================================
		Collision functions
		============================================================================
		*/
		void OnCollisionEnter(Collision collisionInfo)
		{
			if(this.damageActive && DamageDealerType.CollisionEnter.Equals(this.type) &&
				this.CheckOrigin(collisionInfo.transform.root))
			{
				Vector3 position = collisionInfo.transform.position;
				if(collisionInfo.contacts.Length > 0)
				{
					position = collisionInfo.contacts[0].point;
				}
				this.DoDamage(collisionInfo.gameObject, position, collisionInfo.transform.rotation);
				if(this.destroyOnCollision)
				{
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		void OnCollisionExit(Collision collisionInfo)
		{
			if(this.damageActive && DamageDealerType.CollisionExit.Equals(this.type) &&
				this.CheckOrigin(collisionInfo.transform.root))
			{
				Vector3 position = collisionInfo.transform.position;
				if(collisionInfo.contacts.Length > 0)
				{
					position = collisionInfo.contacts[0].point;
				}
				this.DoDamage(collisionInfo.gameObject, position, collisionInfo.transform.rotation);
				if(this.destroyOnCollision)
				{
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		void OnCollisionStay(Collision collisionInfo)
		{
			if(this.damageActive && DamageDealerType.CollisionStay.Equals(this.type) &&
				this.CheckOrigin(collisionInfo.transform.root))
			{
				Vector3 position = collisionInfo.transform.position;
				if(collisionInfo.contacts.Length > 0)
				{
					position = collisionInfo.contacts[0].point;
				}
				this.DoDamage(collisionInfo.gameObject, position, collisionInfo.transform.rotation);
				if(this.destroyOnCollision)
				{
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		
		/*
		============================================================================
		Collision2D functions
		============================================================================
		*/
		void OnCollisionEnter2D(Collision2D collisionInfo)
		{
			if(this.damageActive && DamageDealerType.CollisionEnter.Equals(this.type) &&
				this.CheckOrigin(collisionInfo.transform.root))
			{
				Vector3 position = collisionInfo.transform.position;
				if(collisionInfo.contacts.Length > 0)
				{
					position = collisionInfo.contacts[0].point;
				}
				this.DoDamage(collisionInfo.gameObject, position, collisionInfo.transform.rotation);
				if(this.destroyOnCollision)
				{
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		void OnCollisionExit2D(Collision2D collisionInfo)
		{
			if(this.damageActive && DamageDealerType.CollisionExit.Equals(this.type) &&
				this.CheckOrigin(collisionInfo.transform.root))
			{
				Vector3 position = collisionInfo.transform.position;
				if(collisionInfo.contacts.Length > 0)
				{
					position = collisionInfo.contacts[0].point;
				}
				this.DoDamage(collisionInfo.gameObject, position, collisionInfo.transform.rotation);
				if(this.destroyOnCollision)
				{
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		void OnCollisionStay2D(Collision2D collisionInfo)
		{
			if(this.damageActive && DamageDealerType.CollisionStay.Equals(this.type) &&
				this.CheckOrigin(collisionInfo.transform.root))
			{
				Vector3 position = collisionInfo.transform.position;
				if(collisionInfo.contacts.Length > 0)
				{
					position = collisionInfo.contacts[0].point;
				}
				this.DoDamage(collisionInfo.gameObject, position, collisionInfo.transform.rotation);
				if(this.destroyOnCollision)
				{
					GameObject.Destroy(this.gameObject);
				}
			}
		}
		
		
		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		void OnDrawGizmos()
		{
			Gizmos.DrawIcon(this.transform.position, "DamageDealer.psd");
		}
	}
}
