
using UnityEngine;

namespace ORKFramework.Behaviours
{
	public abstract class SceneID : MonoBehaviour
	{
		// scene ID for tracking certain events
		public bool useSceneID = true;
	
		public int sceneID = -1;
	}
}
