
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BaseImage : BaseData
	{
		[ORKEditorHelp("Use Image", "An image is used.\n" +
			"If disabled, a color is used to fill the image.", "")]
		public bool useImage = false;
		
		
		// image
		[ORKEditorHelp("Image", "Select the image that will be displayed.", "")]
		[ORKEditorLayout("useImage", true)]
		public Texture2D image;
		
		
		// alpha mask
		[ORKEditorHelp("Use Alpha Mask", "Use a texture as alpha mask to hide parts of the image.", "")]
		public bool useAlphaMask = false;
		
		[ORKEditorHelp("Use Material", "Use a material with shader and alpha mask texture assigned.\n" +
			"If disabled, a default mask shader will be used and you can define the used alpha mask texture here.", "")]
		[ORKEditorLayout("useAlphaMask", true)]
		public bool useMaterial = false;
		
		[ORKEditorHelp("Mask Material", "Select the material that will be used.", "")]
		[ORKEditorLayout("useMaterial", true, setDefault=true, defaultValue=null)]
		public Material maskMaterial;
		
		[ORKEditorHelp("Alpha Mask Texture", "Select the image that will be used as alpha mask texture.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2, setDefault=true, defaultValue=null)]
		public Texture2D alphaMaskTexture;
		
		
		// no alpha mask
		[ORKEditorHelp("Scale Mode", "How to scale the image when the aspect ratio of it doesn't fit the aspect ratio to be drawn within.", "")]
		[ORKEditorLayout("useAlphaMask", false)]
		public ScaleMode scaleMode = ScaleMode.StretchToFill;
		
		[ORKEditorHelp("Alpha Blend", "Whether to alpha blend the image on to the display (the default).\n" +
			"If false, the picture is drawn on to the display.", "")]
		public bool alphaBlend = true;
		
		[ORKEditorHelp("Image Aspect", "Aspect ratio to use for the source image.\n" +
			"If 0 (the default), the aspect ratio from the image is used. Pass in w/h for the desired aspect ratio.\n" +
			"This allows the aspect ratio of the source image to be adjusted without changing the pixel width and height.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float imageAspect = 0;
		
		
		// color
		[ORKEditorHelp("Color", "Select the color that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Color)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int color = 0;
		
		
		// in-game
		private Material material;
		
		public BaseImage()
		{
			
		}
		
		private void CreateMaterial()
		{
			if(this.material == null)
			{
				if(this.useMaterial)
				{
					this.material = this.maskMaterial;
				}
				else
				{
					this.material = new Material(ORK.ALPHA_MASK_SHADER);
					this.material.SetTexture("_Mask", this.alphaMaskTexture);
				}
			}
		}
		
		public void Show(Rect bounds)
		{
			if(this.useImage)
			{
				if(this.image != null)
				{
					if(this.useAlphaMask)
					{
						if(Event.current.type == EventType.repaint)
						{
							this.CreateMaterial();
							Graphics.DrawTexture(bounds, this.image, this.material);
						}
					}
					else
					{
						GUI.DrawTexture(bounds, this.image, this.scaleMode, this.alphaBlend, this.imageAspect);
					}
				}
			}
			else
			{
				GUI.DrawTexture(bounds, ORK.Colors.Get(this.color).GetTexture());
			}
		}
		
		public ImageLabel Create(Rect bounds)
		{
			if(this.useImage)
			{
				if(this.image != null)
				{
					if(this.useAlphaMask)
					{
						this.CreateMaterial();
						return new ImageLabel(this.image, bounds, this.material);
					}
					else
					{
						return new ImageLabel(this.image, bounds, 
							this.scaleMode, this.alphaBlend, this.imageAspect);
					}
				}
			}
			else
			{
				return new ImageLabel(ORK.Colors.Get(this.color).GetTexture(), bounds, 
					this.scaleMode, this.alphaBlend, this.imageAspect);
			}
			return null;
		}
	}
}
