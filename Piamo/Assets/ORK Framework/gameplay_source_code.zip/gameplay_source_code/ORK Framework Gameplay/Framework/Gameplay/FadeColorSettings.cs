
using UnityEngine;

namespace ORKFramework
{
	[System.Serializable]
	public class FadeColorSettings : BaseData
	{
		[ORKEditorHelp("Time (s)", "The time in seconds used for fading.", "")]
		public float time = 0.25f;

		[ORKEditorHelp("Interpolation", "The interpolation used for fading.", "")]
		public EaseType interpolation = EaseType.Linear;
		
		
		// fade selection
		[ORKEditorHelp("Fade Alpha", "The alpha value of the color will fade.", "")]
		[ORKEditorInfo(separator=true)]
		public bool alpha = true;
		
		[ORKEditorHelp("Fade Red", "The red value of the color will fade.", "")]
		public bool red = false;
		
		[ORKEditorHelp("Fade Green", "The green value of the color will fade.", "")]
		public bool green = false;
		
		[ORKEditorHelp("Fade Blue", "The blue value of the color will fade.", "")]
		public bool blue = false;
		
		
		// start color
		[ORKEditorHelp("From Current", "The current color values will be used as start value.\n" +
			"If disabled, a selected colur is used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool fromCurrent = false;
		
		[ORKEditorHelp("Start Color", "Select the color that will be faded from.", "")]
		[ORKEditorLayout("fromCurrent", false, endCheckGroup=true)]
		public Color startColor = new Color(0, 0, 0, 0);
		
		
		// end color
		[ORKEditorHelp("End Color", "Select the color that will be faded to.", "")]
		public Color endColor = new Color(0, 0, 0, 1);
		
		
		// ingame
		private Function ease;
		
		public FadeColorSettings()
		{
			
		}
		
		public FadeColorSettings(float t, float s, float e)
		{
			this.time = t;
			this.startColor = new Color(0, 0, 0, s);
			this.endColor = new Color(0, 0, 0, e);
		}
		
		
		/*
		============================================================================
		Color functions
		============================================================================
		*/
		public void GetStart(ref Color start)
		{
			if(!this.fromCurrent)
			{
				if(this.alpha)
				{
					start.a = this.startColor.a;
				}
				if(this.red)
				{
					start.r = this.startColor.r;
				}
				if(this.green)
				{
					start.g = this.startColor.g;
				}
				if(this.blue)
				{
					start.b = this.startColor.b;
				}
			}
		}
		
		public bool Fade(ref Color color, Color colStart, float t)
		{
			return this.Fade(ref color, colStart, t, this.time);
		}
		
		public bool Fade(ref Color color, Color colStart, float t, float t2)
		{
			if(this.ease == null)
			{
				this.ease = Interpolate.Ease(this.interpolation);
			}
			if(this.alpha)
			{
				color.a = Interpolate.Ease(this.ease, colStart.a, this.endColor.a - colStart.a, t, t2);
			}
			if(this.red)
			{
				color.r = Interpolate.Ease(this.ease, colStart.r, this.endColor.r - colStart.r, t, t2);
			}
			if(this.green)
			{
				color.g = Interpolate.Ease(this.ease, colStart.g, this.endColor.g - colStart.g, t, t2);
			}
			if(this.blue)
			{
				color.b = Interpolate.Ease(this.ease, colStart.b, this.endColor.b - colStart.b, t, t2);
			}
			return t >= t2;
		}
		
		public bool RevertFade(ref Color color, Color colStart, float t)
		{
			return this.RevertFade(ref color, colStart, t, this.time);
		}
		
		public bool RevertFade(ref Color color, Color colStart, float t, float t2)
		{
			if(this.ease == null)
			{
				this.ease = Interpolate.Ease(this.interpolation);
			}
			if(this.alpha)
			{
				color.a = Interpolate.Ease(this.ease, this.endColor.a, colStart.a - this.endColor.a, t, t2);
			}
			if(this.red)
			{
				color.r = Interpolate.Ease(this.ease, this.endColor.r, colStart.r - this.endColor.r, t, t2);
			}
			if(this.green)
			{
				color.g = Interpolate.Ease(this.ease, this.endColor.g, colStart.g - this.endColor.g, t, t2);
			}
			if(this.blue)
			{
				color.b = Interpolate.Ease(this.ease, this.endColor.b, colStart.b - this.endColor.b, t, t2);
			}
			return t >= t2;
		}
	}
}
