
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class CheckVariableBase : BaseData
	{
		[ORKEditorHelp("Is Valid", "The check must be valid.\n" +
			"If disabled, the check must be invalid.", "")]
		[ORKEditorInfo(separator=true)]
		public bool isValid = true;
		
		[ORKEditorHelp("Type", "Select the type of the game variable:\n" +
			"- String: A string variable.\n" +
			"- Bool: A bool variable.\n" +
			"- Float: A float variable.\n" +
			"- Vector3: A Vector3 variable.", "")]
		public GameVariableType type = GameVariableType.String;
		
		
		// string
		[ORKEditorInfo(labelText="String Value")]
		[ORKEditorLayout("type", GameVariableType.String, endCheckGroup=true, autoInit=true)]
		public StringValue stringValue;
		
		
		// float
		[ORKEditorHelp("Check Type", "The check is valid if the current value " +
			"is equal, not equal, less or greater than the defined value.", "")]
		[ORKEditorLayout("type", GameVariableType.Float)]
		public ValueCheck floatCheck = ValueCheck.IsEqual;
		
		[ORKEditorInfo(labelText="Float Value", label=new string[] {"The player is used as user and target."})]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public FloatValue floatValue;
		
		
		// vector3
		[ORKEditorHelp("Check Type", "The check is valid if the distance between the current and the defined value " +
			"is equal, not equal, less or greater than the defined distance.", "")]
		[ORKEditorLayout("type", GameVariableType.Vector3)]
		public ValueCheck vector3Check = ValueCheck.IsLess;
		
		[ORKEditorHelp("Distance", "The distance used for the check.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float vector3Distance = 0;
		
		[ORKEditorInfo(labelText="Vector3 Value")]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public Vector3Value vector3Value;
		
		public CheckVariableBase()
		{
			
		}
		
		public bool Check(string key, VariableHandler handler)
		{
			if(GameVariableType.String.Equals(this.type))
			{
				return this.isValid == handler.Check(key, this.stringValue.GetValue());
			}
			else if(GameVariableType.Bool.Equals(this.type))
			{
				return this.isValid == handler.Check(key, true);
			}
			else if(GameVariableType.Float.Equals(this.type))
			{
				return this.isValid == handler.CheckFloat(key, 
					this.floatValue.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader), 
					this.floatCheck);
			}
			else if(GameVariableType.Vector3.Equals(this.type))
			{
				return this.isValid == handler.CheckVector3(key, 
					this.vector3Value.GetValue(), this.vector3Distance, this.vector3Check);
			}
			return false;
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return (this.isValid ? "is" : "is not") + " (" + this.type + ") ";
		}
	}
}
