
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class MainMenuChoice : BaseData, IChoice, IValueInputChoice
	{
		[ORKEditorHelp("GUI Box", "The GUI box used to display the main menu.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		// layout
		[ORKEditorInfo("Content Layout", "Define the layout of the buttons.", "", 
			endFoldout=true, separatorForce=true)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		
		// message
		[ORKEditorHelp("Message Text", "The text displayed in the main menu.\n" +
			"Leave empty if no additional text should be displayed.", "")]
		[ORKEditorInfo("Main Menu Text", "The text displayed in the main menu.\n" +
			"Leave empty if no additional text should be displayed.", "",
			endFoldout=true, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] message = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// general portrait
		[ORKEditorHelp("Use Portrait", "The main menu displays a portrait.\n" +
			"The portrait is displayed when a menu item without a portrait is selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Portrait Settings")]
		public bool usePortrait = false;
		
		[ORKEditorLayout("usePortrait", true, endCheckGroup=true, autoInit=true)]
		public Portrait portrait;
		
		
		// new game button
		[ORKEditorInfo("New Game Button", "Define the button to start a new game.", "")]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageInfo[] newButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"New Game"});
		
		[ORKEditorHelp("Use Portrait", "The new game button displays a portrait when selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Portrait Settings")]
		public bool useNewGamePortrait = false;
		
		[ORKEditorLayout("useNewGamePortrait", true, endCheckGroup=true, autoInit=true)]
		public Portrait newGamePortrait;
		
		
		// difficulty
		[ORKEditorHelp("Difficulty Selection", "A difficulty selection menu will be shown after selecting the new game option.\n" +
			"The difficulty choice texts use the names and icons of the difficulty settings.", "")]
		[ORKEditorInfo("Difficulty Menu", "A difficulty selection menu can be displayed after selecting the new game option.", "")]
		public bool difficultySelection = false;
		
		[ORKEditorHelp("Difficulty GUI Box", "The GUI box used to display the difficulty menu.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("difficultySelection", true)]
		public int difficultyGuiBoxID = 0;
		
		// difficulty title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used difficulty GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useDifTitle = false;
		
		[ORKEditorHelp("Title", "The title of the difficulty menu.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useDifTitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] difTitle;
		
		// difficulty message
		[ORKEditorHelp("Difficulty Text", "The text displayed difficulty menu.\n" +
			"Leave empty if no additional text should be displayed.", "")]
		[ORKEditorInfo("Difficulty Text", "The text displayed difficulty menu.\n" +
			"Leave empty if no additional text should be displayed.", "", 
			endFoldout=true, endFolds=3, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string[] difficultyMessage = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// load button
		[ORKEditorHelp("Show Load", "A load button will be displayed in the main menu.\n" +
			"Selecting this option will call the load menu.\n" +
			"The name of the button can be defined in all languages and have an icon.", "")]
		[ORKEditorInfo("Load Button", "Define the button to load a saved game.", "")]
		public bool showLoad = true;
		
		[ORKEditorLayout("showLoad", true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageInfo[] loadButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Load Game"});
		
		[ORKEditorHelp("Auto Select", "The load option is automatically marked as selected if a save game exists.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool selectLoad = true;
		
		[ORKEditorHelp("Use Portrait", "The load button displays a portrait when selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Portrait Settings")]
		public bool useLoadPortrait = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useLoadPortrait", true, endCheckGroup=true, autoInit=true)]
		public Portrait loadPortrait;
		
		
		// language button
		[ORKEditorHelp("Show Language", "A language button will be displayed in the main menu.\n" +
			"Selecting this option will call the language selection.\n" +
			"The name of the button can be defined in all languages and have an icon.", "")]
		[ORKEditorInfo("Language Button", "Define the button to change the language.", "")]
		public bool showLanguage = false;
		
		[ORKEditorLayout("showLanguage", true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageInfo[] languageButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Language"});
		
		[ORKEditorHelp("Use Portrait", "The language button displays a portrait when selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Portrait Settings")]
		public bool useLanguagePortrait = false;
		
		[ORKEditorLayout("useLanguagePortrait", true, endCheckGroup=true, autoInit=true)]
		public Portrait languagePortrait;
		
		[ORKEditorHelp("Language GUI Box", "The GUI box used to display the language menu.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox, separator=true, labelText="Language Menu")]
		public int languageGuiBoxID = 0;
		
		// language title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used language GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useLangTitle = false;
		
		[ORKEditorHelp("Title", "The title of the language menu.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useLangTitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] langTitle;
		
		// language message
		[ORKEditorHelp("Language Message", "The text displayed in the language menu.\n" +
			"Leave empty if no additional text should be displayed.", "")]
		[ORKEditorInfo("Language Message", "The text displayed in the language menu.\n" +
			"Leave empty if no additional text should be displayed.", "", 
			endFoldout=true, endFolds=2, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string[] languageMessage = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// option button
		[ORKEditorHelp("Show Options", "An options button will be displayed in the main menu.\n" +
			"Selecting this option will call the language selection.\n" +
			"The name of the button can be defined in all languages and have an icon.", "")]
		[ORKEditorInfo("Options Button", "Define the button to change game options.", "")]
		public bool showOptions = false;
		
		[ORKEditorLayout("showOptions", true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageInfo[] optionsButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Options"});
		
		[ORKEditorHelp("Use Portrait", "The options button displays a portrait when selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Portrait Settings")]
		public bool useOptionsPortrait = false;
		
		[ORKEditorLayout("useOptionsPortrait", true, endCheckGroup=true, autoInit=true)]
		public Portrait optionsPortrait;
		
		[ORKEditorHelp("Options GUI Box", "The GUI box used to display the options menu.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox, separator=true, labelText="Options Menu")]
		public int optionsGuiBoxID = 0;
		
		// language title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used options GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useOptionsTitle = false;
		
		[ORKEditorHelp("Title", "The title of the options menu.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useOptionsTitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] optionsTitle;
		
		// language message
		[ORKEditorHelp("Options Message", "The text displayed in the options menu.\n" +
			"Leave empty if no additional text should be displayed.", "")]
		[ORKEditorInfo("Options Message", "The text displayed in the options menu.\n" +
			"Leave empty if no additional text should be displayed.", "", 
			endFoldout=true, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] optionsMessage = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		[ORKEditorArray(false, "Add Option", "Adds an option to the options menu.", "", 
			"Remove", "Removes this option from the options menu.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Option", "Define the option that will be displayed", ""
		})]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public GameOption[] gameOptions;
		
		
		// about button
		[ORKEditorHelp("Show About", "An about button will be displayed in the main menu.\n" +
			"Selecting this option will show the about info.\n" +
			"The name of the button can be defined in all languages and have an icon.", "")]
		[ORKEditorInfo("About Button", "Define the button to show information.", "")]
		public bool showAbout = false;
		
		[ORKEditorLayout("showAbout", true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageInfo[] aboutButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"About"});
		
		[ORKEditorHelp("Use Portrait", "The about button displays a portrait when selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Portrait Settings")]
		public bool useAboutPortrait = false;
		
		[ORKEditorLayout("useAboutPortrait", true, endCheckGroup=true, autoInit=true)]
		public Portrait aboutPortrait;
		
		[ORKEditorHelp("About GUI Box", "The GUI box used to display the about info.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox, separator=true, labelText="About Info Text")]
		public int aboutGuiBoxID = 0;
		
		// language title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used about GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useAboutTitle = false;
		
		[ORKEditorHelp("Title", "The title of the about dialogue.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useAboutTitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] aboutTitle;
		
		// language message
		[ORKEditorHelp("About Message", "The text displayed in the about dialogue.", "")]
		[ORKEditorInfo("About Message", "The text displayed in the about dialogue.", "", 
			endFoldout=true, endFolds=2, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string[] aboutMessage = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// custom options
		[ORKEditorInfo("Custom Choice Settings", 
			"You can use custom choices to extend the functionality of the main menu.\n" +
			"Custom choices will search for a defined game object in the scene and " +
			"try to call a function on a defined component.\n" +
			"The call is made after the main menu is closed - " +
			"to open the main menu again from your custom script, " +
			"call 'ORK.MainMenu.menu.Show()'.", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Custom Choice", "Adds a custom choice to the main menu.\n" +
			"You can use custom choices to extend the functionality of the main menu.\n" +
			"Custom choices will search for a defined game object in the scene and " +
			"try to call a function on a defined component.", "", 
			"Remove", "Removes this custom choice", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {
				"Custom Choice", "Custom choices will search for a defined game object in the scene and " +
				"try to call a function on a defined component.", ""
		})]
		public CustomChoiceCall[] customChoice = new CustomChoiceCall[0];
		
		
		// exit button
		[ORKEditorHelp("Show Exit", "An exit button will be displayed in the main menu.\n" +
			"Selecting this option will exit the game.\n" +
			"The name of the button can be defined in all languages and have an icon.", "")]
		[ORKEditorInfo("Exit Button", "Define the button to end the game.", "")]
		public bool showExit = true;
		
		[ORKEditorLayout("showExit", true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageInfo[] exitButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Exit"});
		
		[ORKEditorHelp("Use Portrait", "The exit button displays a portrait when selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Portrait Settings")]
		public bool useExitPortrait = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useExitPortrait", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public Portrait exitPortrait;
		
		
		// choices
		private GUIBox box;
		
		private string tmpName = "";
		
		private int lastSelection = -1;
		
		private int current = -1;
		
		private ChoiceContent[] choices;

		private int[] choiceActions;
		
		private List<BaseValueInput> valueInputs;
		
		
		// modes
		private static int NEW_GAME = 0;
		
		private static int DIFFICULTY = 1;

		private static int LOAD = 2;

		private static int LANGUAGE = 3;
		
		private static int OPTIONS = 4;

		private static int ABOUT = 5;

		private static int EXIT = 6;

		private static int CUSTOM = 7;
		
		public MainMenuChoice()
		{
			
		}
		
		public string Message
		{
			get
			{
				if(this.current == MainMenuChoice.DIFFICULTY)
				{
					this.tmpName = this.useDifTitle ? this.difTitle[ORK.Game.Language] : "";
					return this.difficultyMessage[ORK.Game.Language];
				}
				else if(this.current == MainMenuChoice.LANGUAGE)
				{
					this.tmpName = this.useLangTitle ? this.langTitle[ORK.Game.Language] : "";
					return this.languageMessage[ORK.Game.Language];
				}
				else if(this.current == MainMenuChoice.OPTIONS)
				{
					this.tmpName = this.useOptionsTitle ? this.optionsTitle[ORK.Game.Language] : "";
					return this.optionsMessage[ORK.Game.Language];
				}
				else if(this.current == MainMenuChoice.ABOUT)
				{
					this.tmpName = this.useAboutTitle ? this.aboutTitle[ORK.Game.Language] : "";
					return this.aboutMessage[ORK.Game.Language];
				}
				this.tmpName = this.useTitle ? this.title[ORK.Game.Language] : "";
				return this.message[ORK.Game.Language];
			}
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return true;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return true;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show()
		{
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.SetOutDone();
				this.box = null;
			}
			
			// options menu
			if(this.current == MainMenuChoice.OPTIONS)
			{
				this.box = ORK.GUIBoxes.Create(this.optionsGuiBoxID);
				this.valueInputs = new List<BaseValueInput>();
				for(int i=0; i<this.gameOptions.Length; i++)
				{
					this.valueInputs.Add(this.gameOptions[i].GetValueInput(ORK.Game.Variables));
				}
				this.box.Content = new ValueInputContent(this.Message, this.tmpName, this.valueInputs, this, null);
			}
			// others
			else
			{
				int sel = this.lastSelection;
				if(this.current == MainMenuChoice.DIFFICULTY)
				{
					this.box = ORK.GUIBoxes.Create(this.difficultyGuiBoxID);
					sel = ORK.Game.Difficulty;
				}
				else if(this.current == MainMenuChoice.LANGUAGE)
				{
					this.box = ORK.GUIBoxes.Create(this.languageGuiBoxID);
					sel = ORK.Game.Language;
				}
				else if(this.current == MainMenuChoice.ABOUT)
				{
					this.box = ORK.GUIBoxes.Create(this.aboutGuiBoxID);
				}
				else
				{
					this.current = -1;
					this.box = ORK.GUIBoxes.Create(this.guiBoxID);
					if(sel == -1 && this.showLoad && this.selectLoad && ORK.SaveGame.FileExists())
					{
						sel = 1;
					}
				}
				this.CreateChoices();
				this.box.Content = new DialogueContent(this.Message, this.tmpName, this.choices, this, sel, 
					this.usePortrait ? this.portrait : null);
			}
			
			this.box.InitIn();
			ORK.GUI.FocusBlocked = true;
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		public void Closed(GUIBox origin)
		{
			if(this.box == origin)
			{
				this.box = null;
				if(this.current == MainMenuChoice.NEW_GAME)
				{
					this.current = -1;
					ORK.Game.NewGame(true);
				}
				else if(this.current == MainMenuChoice.LOAD)
				{
					this.current = -1;
					ORK.SaveGameMenu.loadMenu.Show(this, null);
				}
				else if(this.current == -1 || 
					this.current == MainMenuChoice.DIFFICULTY || 
					this.current == MainMenuChoice.LANGUAGE || 
					this.current == MainMenuChoice.OPTIONS || 
					this.current == MainMenuChoice.ABOUT)
				{
					if(this.valueInputs != null)
					{
						for(int i=0; i<this.valueInputs.Count; i++)
						{
							this.gameOptions[i].SetNewValue(ORK.Game.Variables, this.valueInputs[i]);
						}
						this.valueInputs = null;
					}
					
					this.Show();
				}
				else if(this.current == MainMenuChoice.EXIT)
				{
					Application.Quit();
				}
				else if(this.current >= MainMenuChoice.CUSTOM)
				{
					int customIndex = this.current - MainMenuChoice.CUSTOM;
					this.current = -1;
					if(customIndex < 0 && 
						customIndex >= this.customChoice.Length || 
						!this.customChoice[customIndex].Selected())
					{
						this.Show();
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void CreateChoices()
		{
			if(this.current == -1)
			{
				List<ChoiceContent> cc = new List<ChoiceContent>();
				List<int> ca = new List<int>();
				
				ChoiceContent newGame = this.contentLayout.GetChoiceContent(this.newButton);
				if(this.useNewGamePortrait)
				{
					newGame.portrait = this.newGamePortrait;
				}
				cc.Add(newGame);
				if(this.difficultySelection)
				{
					ca.Add(MainMenuChoice.DIFFICULTY);
				}
				else
				{
					ca.Add(MainMenuChoice.NEW_GAME);
				}
				
				if(this.showLoad)
				{
					ChoiceContent load = this.contentLayout.GetChoiceContent(this.loadButton);
					load.active = ORK.SaveGame.FileExists();
					if(this.useLoadPortrait)
					{
						load.portrait = this.loadPortrait;
					}
					cc.Add(load);
					ca.Add(MainMenuChoice.LOAD);
				}
				if(this.showLanguage)
				{
					ChoiceContent lang = this.contentLayout.GetChoiceContent(this.languageButton);
					if(this.useLanguagePortrait)
					{
						lang.portrait = this.languagePortrait;
					}
					cc.Add(lang);
					ca.Add(MainMenuChoice.LANGUAGE);
				}
				if(this.showOptions)
				{
					ChoiceContent options = this.contentLayout.GetChoiceContent(this.optionsButton);
					if(this.useOptionsPortrait)
					{
						options.portrait = this.optionsPortrait;
					}
					cc.Add(options);
					ca.Add(MainMenuChoice.OPTIONS);
				}
				if(this.showAbout)
				{
					ChoiceContent about = this.contentLayout.GetChoiceContent(this.aboutButton);
					if(this.useAboutPortrait)
					{
						about.portrait = this.aboutPortrait;
					}
					cc.Add(about);
					ca.Add(MainMenuChoice.ABOUT);
				}
				
				for(int i=0; i<this.customChoice.Length; i++)
				{
					ChoiceContent custom = this.contentLayout.GetChoiceContent(this.customChoice[i].button);
					if(this.customChoice[i].usePortrait)
					{
						custom.portrait = this.customChoice[i].portrait;
					}
					cc.Add(custom);
					ca.Add(MainMenuChoice.CUSTOM + i);
				}
				
				if(this.showExit)
				{
					ChoiceContent exit = this.contentLayout.GetChoiceContent(this.exitButton);
					if(this.useExitPortrait)
					{
						exit.portrait = this.exitPortrait;
					}
					cc.Add(exit);
					ca.Add(MainMenuChoice.EXIT);
				}
				
				this.choices = cc.ToArray();
				this.choiceActions = ca.ToArray();
			}
			else if(this.current == MainMenuChoice.DIFFICULTY)
			{
				this.choices = ORK.Difficulties.GetDifficultyChoice(this.contentLayout);
				this.choiceActions = null;
			}
			else if(this.current == MainMenuChoice.LANGUAGE)
			{
				this.choices = ORK.Languages.GetLanguageChoice(this.contentLayout);
				this.choiceActions = null;
			}
			else
			{
				this.choices = null;
				this.choiceActions = null;
			}
		}
		
		public void ChoiceSelected(int index, GUIBox origin)
		{
			if(this.current == -1)
			{
				this.lastSelection = index;
				this.current = this.choiceActions[index];
			}
			else if(this.current == MainMenuChoice.DIFFICULTY)
			{
				if(index < this.choices.Length - 1)
				{
					ORK.Game.Difficulty = index;
					this.current = MainMenuChoice.NEW_GAME;
				}
				else
				{
					this.current = -1;
				}
			}
			else if(this.current == MainMenuChoice.LANGUAGE)
			{
				if(index < this.choices.Length - 1)
				{
					ORK.Game.Language = index;
					this.current = MainMenuChoice.NEW_GAME;
				}
				this.current = -1;
			}
			else
			{
				this.current = -1;
			}
			this.box.InitOut();
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}
		
		public void ValueInputChanged(int index, GUIBox origin)
		{
			if(this.valueInputs != null && 
				index >= 0 && index < this.gameOptions.Length)
			{
				this.gameOptions[index].SetNewValue(ORK.Game.Variables, this.valueInputs[index]);
			}
		}
		
		public void Canceled(GUIBox origin)
		{
			if(this.valueInputs != null)
			{
				for(int i=0; i<this.valueInputs.Count; i++)
				{
					this.gameOptions[i].ResetValue(ORK.Game.Variables);
				}
				this.valueInputs = null;
			}
			
			if(this.current != -1)
			{
				origin.Audio.PlayCancel();
				this.current = -1;
				this.box.InitOut();
			}
		}
	}
}
