
using UnityEngine;

namespace ORKFramework
{
	public class ColorSetting : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of this color.", "")]
		[ORKEditorInfo("Color Settings", "Set the name and color.", "", callbackAfter="label:indexCheck", 
			expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Color", "The color that will be used.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public Color color = Color.white;
		
		
		// ingame
		private Texture2D texture;
		
		public ColorSetting()
		{
			
		}
		
		public ColorSetting(string n, Color c)
		{
			this.name = n;
			this.color = c;
		}
		
		public Texture2D GetTexture()
		{
			if(this.texture == null)
			{
				this.texture = new Texture2D(1, 1);
				this.texture.SetPixel(0, 0, this.color);
				this.texture.Apply();
				GameObject.DontDestroyOnLoad(this.texture);
			}
			return this.texture;
		}
	}
}

