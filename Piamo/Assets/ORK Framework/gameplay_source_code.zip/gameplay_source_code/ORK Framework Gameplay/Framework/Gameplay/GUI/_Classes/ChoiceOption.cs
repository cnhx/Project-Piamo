
namespace ORKFramework
{
	public class ChoiceOption : BaseData
	{
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		
		// text/icon
		[ORKEditorInfo(labelText="Choice Text/Icon")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageContent[] content = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count);
		
		
		// variable conditions
		[ORKEditorHelp("Use Condition", "A variable condition is used to decide if this choice is available.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Conditions")]
		public bool useCondition = false;
		
		[ORKEditorLayout("useCondition", true, endCheckGroup=true)]
		public VariableCondition condition = new VariableCondition();
		
		
		// item
		[ORKEditorHelp("Add Item", "An item, weapon or armor is added to the inventory if this choice is selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Item Settings")]
		public bool addItem = false;
		
		[ORKEditorLayout("addItem", true, endCheckGroup=true)]
		[ORKEditorInfo(callbackAfter="info:choiceitem")]
		public ItemGain item = new ItemGain();
		
		public ChoiceOption()
		{
			
		}
		
		public bool Available()
		{
			return !this.useCondition || this.condition.CheckVariables();
		}
		
		public ChoiceContent GetContent()
		{
			ChoiceContent cc = this.content[ORK.Game.Language].GetChoiceContent();
			if(this.addItem)
			{
				if(!this.item.IsMoney())
				{
					cc.Content.text = cc.Content.text.Replace("%n", this.item.GetName());
				}
				cc.Content.text = cc.Content.text.Replace("%", this.item.quantity.ToString());
			}
			return cc;
		}
	}
}

