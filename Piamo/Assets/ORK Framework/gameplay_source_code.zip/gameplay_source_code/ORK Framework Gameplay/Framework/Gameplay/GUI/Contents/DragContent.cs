
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DragContent : GUIBoxContent
	{
		private DragInfo info;
		
		private ChoiceContent content;
		
		
		// scroll/bounds
		private Vector2 scroll = Vector2.zero;
		
		private Rect contentBounds;
		
		private Rect scrollRect;
		
		public DragContent(DragInfo info)
		{
			this.info = info;
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public override void Init(GUIBox box)
		{
			if(this.newContent || this.box == null)
			{
				this.box = box;
				
				this.CalculateContent(this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), false);
				
				this.newContent = false;
			}
		}
		
		private void CalculateContent(float baseWidth, bool recalced)
		{
			Rect textBounds = new Rect(0, 0, baseWidth, 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			GUIStyle textStyle = new GUIStyle(GUI.skin.label);
			textStyle.wordWrap = false;
			
			this.content = ORK.MenuSettings.dragContentLayout.GetChoiceContent(this.info.Shortcut, this.info.User);
			this.content.isButton = false;
			this.content.InitContent(textStyle, textBounds, false, this.box.Settings.buttonSettings, null);
			
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
				!this.box.forceSize)
			{
				this.box.bounds.height = this.content.buttonBounds.height + this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
			}
			else if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				this.scrollRect = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
					baseWidth, this.content.buttonBounds.height);
			}
			
			this.contentBounds = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
				this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			if(!recalced && this.content.buttonBounds.height > textBounds.height && 
				BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				this.CalculateContent(baseWidth - (GUI.skin.verticalScrollbar.fixedWidth + this.box.Settings.scrollPadding), true);
			}
		}
		
		public override void Tick()
		{
			
		}

		public override void Closed()
		{
			
		}

		public override bool CheckDrop(DragInfo drag, Vector2 mousePosition)
		{
			return false;
		}

		public override void ShowBefore()
		{
			
		}

		public override void ShowAfter()
		{
			
		}

		public override void ShowWindow()
		{
			if(this.box != null)
			{
				GUIStyle textStyle = new GUIStyle(GUI.skin.label);
				textStyle.wordWrap = false;
				
				if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
				{
					GUI.skin.horizontalScrollbar = GUIStyle.none;
					this.scroll = GUI.BeginScrollView(this.contentBounds, this.scroll, this.scrollRect);
					GUI.BeginGroup(this.scrollRect);
				}
				else
				{
					GUI.BeginGroup(this.contentBounds);
				}
				
				GUI.BeginGroup(this.content.buttonBounds);
				if(this.content.statusContent != null)
				{
					for(int i=0; i<this.content.statusContent.Count; i++)
					{
						this.box.SetGUIColor(this.content.statusContent[i].setting.noFlash);
						this.content.statusContent[i].Show(textStyle);
						this.box.SetGUIColor(false);
					}
				}
				// content
				if(!this.box.Settings.buttonSettings.alignIcons && this.content.Content.image != null)
				{
					textStyle.alignment = TextAnchor.MiddleLeft;
					GUI.Label(this.content.cImgBounds, new GUIContent(this.content.Content.image), textStyle);
					textStyle.alignment = TextAnchor.UpperLeft;
				}
				if(this.content.contentLabel != null && this.content.contentLabel.label.Count > 0)
				{
					for(int i=0; i<this.content.contentLabel.label.Count; i++)
					{
						this.content.contentLabel.label[i].Show(textStyle);
					}
				}
				// info
				if(this.content.infoLabel != null && this.content.infoLabel.label.Count > 0)
				{
					for(int i=0; i<this.content.infoLabel.label.Count; i++)
					{
						this.content.infoLabel.label[i].Show(textStyle);
					}
				}
				GUI.EndGroup();
				
				GUI.EndGroup();
				if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
				{
					GUI.EndScrollView();
				}
			}
		}
	}
}
