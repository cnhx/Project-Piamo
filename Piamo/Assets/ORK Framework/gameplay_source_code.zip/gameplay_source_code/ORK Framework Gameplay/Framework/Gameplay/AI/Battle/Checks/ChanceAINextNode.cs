
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class ChanceAINextNode : BaseData
	{
		[ORKEditorInfo(labelText="Minimum Range")]
		public AIFloat minimum = new AIFloat();
		
		[ORKEditorInfo(separator=true, labelText="Maximum Range")]
		public AIFloat maximum = new AIFloat();
		
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		public ChanceAINextNode()
		{
			
		}
		
		public bool Contains(float chance, Combatant user, Combatant target)
		{
			return this.minimum.GetValue(user, target) <= chance && 
				chance <= this.maximum.GetValue(user, target);
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return this.minimum.GetInfoText() + " - " + this.maximum.GetInfoText();
		}
	}
}
