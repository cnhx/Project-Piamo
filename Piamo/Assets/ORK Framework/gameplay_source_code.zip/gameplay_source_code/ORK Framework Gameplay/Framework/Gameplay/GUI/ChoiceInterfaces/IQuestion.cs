
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IQuestion
	{
		void QuestionClosed(bool accepted);
	}
}
