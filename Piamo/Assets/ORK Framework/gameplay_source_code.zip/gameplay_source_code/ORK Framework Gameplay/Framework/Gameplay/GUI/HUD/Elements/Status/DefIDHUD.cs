
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DefIDHUD : BaseData
	{
		[ORKEditorHelp("List Attributes", "All applied defence attributes of the combatant will be displayed.\n" +
			"If disabled, only the selected applied attribute of the selected group will be displayed.", "")]
		public bool list = true;
		
		[ORKEditorHelp("Offset", "The offset of each listed attribute.", "")]
		[ORKEditorLayout("list", true)]
		public Vector2 off = new Vector2(0, 30);
		
		[ORKEditorHelp("Set Size", "Set the size of the individual defence attribute manually.\n" +
			"If disabled, the size defined by the bounds is used.", "")]
		public bool setSize = false;
		
		[ORKEditorHelp("Size", "The width (X) and height (Y) of each defence attribute.", "")]
		[ORKEditorLayout("setSize", true, endCheckGroup=true)]
		public Vector2 size = new Vector2(100, 20);
		
		
		// attribute group
		[ORKEditorHelp("Attribute Group", "Select the defence attribute group that will be displayed.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		
		// data origin
		[ORKEditorHelp("Value Origin", "Select where the displayed value will come from:\n" +
			"- Current: The current value of the defence attributes.\n" +
			"- Preview: The preview value of the defence attributes. If no preview is available, the current value is used instead.\n" +
			"- Preview Hide: The preview value of the defence attributes. Hidden if no preview is available.\n" +
			"- Preview Hide No Change: The preview value of the defence attributes. Only hides values if there is no change to the current value." +
			"A preview value displays how the defence attributes will change if a selected equipment would be equipped. " +
			"Preview values are only available for player group members.", "")]
		public HUDStatusOrigin origin = HUDStatusOrigin.Current;
		
		[ORKEditorInfo("Change Text Format", "Define the appearance of the text for changed defence attributes, " +
			"e.g. color, shadow, font size.", "", endFoldout=true)]
		[ORKEditorLayout("origin", HUDStatusOrigin.Current, elseCheckGroup=true, endCheckGroup=true)]
		public TextFormat previewFormat = TextFormat.Default;
		
		
		// text
		[ORKEditorInfo(separator=true, label=new string[] {
			"%n = sub-attribute name, %d = sub-attribute description, %i = sub-attribute icon", 
			"%an = attribute name, %ad = attribute description, %ai = attribute icon"
		})]
		public StatusTextHUD text = new StatusTextHUD();
		
		public DefIDHUD()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, GUIStyle textStyle, Combatant combatant, Rect bounds)
		{
			label = new List<BaseLabel>();
			
			if(this.list)
			{
				for(int i=0; i<ORK.DefenceAttributes.Count; i++)
				{
					this.CreateID(ref label, combatant.Status.GetDefenceAttributeID(i), combatant.Status.PreviewAvailable, 
						new Rect(this.off.x * i, this.off.y * i, 
							this.setSize ? this.size.x : bounds.width, 
							this.setSize ? this.size.y : bounds.height), 
						textStyle);
				}
			}
			else
			{
				this.CreateID(ref label, combatant.Status.GetDefenceAttributeID(this.id), combatant.Status.PreviewAvailable, bounds, textStyle);
			}
		}
		
		private void CreateID(ref List<BaseLabel> label, DefAttrID defAttr, bool previewAvailable, Rect bounds, GUIStyle textStyle)
		{
			int value = 0;
			
			if(HUDStatusOrigin.Current.Equals(this.origin))
			{
				value = defAttr.GetID();
			}
			else if(HUDStatusOrigin.Preview.Equals(this.origin))
			{
				if(previewAvailable)
				{
					value = defAttr.GetPreviewID();
				}
				else
				{
					value = defAttr.GetID();
				}
			}
			else if(HUDStatusOrigin.PreviewHide.Equals(this.origin))
			{
				if(previewAvailable)
				{
					value = defAttr.GetPreviewID();
				}
				else
				{
					return;
				}
			}
			else if(HUDStatusOrigin.PreviewHideNoChange.Equals(this.origin))
			{
				if(previewAvailable)
				{
					value = defAttr.GetPreviewID();
					
					if(value == defAttr.GetID())
					{
						return;
					}
				}
				else
				{
					return;
				}
			}
			
			label.AddRange(new MultiContent(
				TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
					Replace("%an", ORK.DefenceAttributes.GetName(defAttr.RealID)).
					Replace("%ad", ORK.DefenceAttributes.GetDescription(defAttr.RealID)).
					Replace("%ai", TextCode.DefenceAttributeIcon + defAttr.RealID + "#").
					Replace("%n", ORK.DefenceAttributes.GetName(defAttr.RealID, value)).
					Replace("%d", ORK.DefenceAttributes.GetDescription(defAttr.RealID, value)).
					Replace("%i", TextCode.DefenceAttributeSubIcon + defAttr.RealID + "#" + value + "#")), 
				null, null, textStyle, bounds, this.text.lineSpacing, this.text.alignment, 
				this.text.vAlignment, BoxHeightAdjustment.Auto, false, 
				value != defAttr.GetID() ? this.previewFormat : this.text.textFormat).label);
		}
	}
}
