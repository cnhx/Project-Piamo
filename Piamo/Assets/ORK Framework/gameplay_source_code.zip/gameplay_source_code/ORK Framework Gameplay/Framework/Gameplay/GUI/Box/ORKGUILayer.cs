
namespace ORKFramework
{
	public class ORKGUILayer : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the GUI layer.\n" +
			"GUI layers are used to organize the order of GUI box displays " +
			"and to allow filtering GUI boxes in lists.", "")]
		[ORKEditorInfo("GUI Layer Settings", "GUI layers are used to organize the order of GUI box displays " +
			"and to allow filtering GUI boxes in lists.", "", expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Screen Fader", "The screen fader will be displayed " +
			"after this GUI layer (and before the next).\n" +
			"If no GUI layer is set to display the screen fader, " +
			"it will be displayed after the last GUI layer.", "")]
		[ORKEditorInfo(endFoldout=true, callbackAfter="check:screenfader")]
		public bool isScreenFader = false;
		
		public ORKGUILayer()
		{
			
		}
		
		public ORKGUILayer(string n)
		{
			this.name = n;
		}
	}
}
