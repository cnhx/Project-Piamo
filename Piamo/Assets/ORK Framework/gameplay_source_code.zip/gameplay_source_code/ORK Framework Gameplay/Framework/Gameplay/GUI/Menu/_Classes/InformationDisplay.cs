
using UnityEngine;
using System.Collections.Generic;
using ORKFramework;

namespace ORKFramework.Menu
{
	public class InformationDisplay : BaseData
	{
		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the information.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		
		// page keys
		[ORKEditorHelp("Use Change Keys", "The page can be changed by keys.\n" +
			"Changing pages is only possible if more than one page is available.", "")]
		[ORKEditorInfo(separator=true, labelText="Page Change Keys")]
		public bool usePageKeys = false;
		
		[ORKEditorHelp("Next Page", "Select the key used to select the next page.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("usePageKeys", true)]
		public int nextPageKey = 0;
		
		[ORKEditorHelp("Previous Page", "Select the key used to select the previous page.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int prevPageKey = 0;
		
		
		// pages
		[ORKEditorArray(false, "Add Page", "Adds an information page.", "", 
			"Remove", "Removes this information page.", "", isMove=true, isCopy=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {"Information Page", 
			"Set the title and content of this information page.", ""})]
		public InformationPage[] page = new InformationPage[] {new InformationPage()};
		
		public InformationDisplay()
		{
			
		}
	}
}
