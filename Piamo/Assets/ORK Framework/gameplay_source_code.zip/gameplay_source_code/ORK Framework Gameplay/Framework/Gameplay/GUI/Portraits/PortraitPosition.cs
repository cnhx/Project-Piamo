
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class PortraitPosition : BaseData
	{
		// position
		[ORKEditorHelp("Position", "Set the X and Y position of the portrait.", "")]
		[ORKEditorInfo(labelText="Portrait Position")]
		public Vector2 position = Vector2.zero;
		
		[ORKEditorHelp("Anchor", "Select the anchor of the portrait position.\n" +
			"E.g. 'Upper Left' will place the upper left corner of the image at the defined position, " +
			"'Lower Right' will place the lower right corner of the image at the defind position.", "")]
		public TextAnchor anchor = TextAnchor.UpperLeft;
		
		[ORKEditorHelp("Box Position", "Select where to display the portrait:\n" +
			"- Behind: The portrait is displayed behind the GUI box.\n" +
			"- Within: The portrait is displayed within the GUI box (i.e. behind the text and cut off outside the box).\n" +
			"- In Front: The portrait is displayed in front of the GUI box.", "")]
		public PortraitBoxPosition boxPosition = PortraitBoxPosition.Behind;
		
		// relative
		[ORKEditorHelp("Relative Position", "The portrait's position is relative to the GUI box.\n" +
			"If disabled, the position is absolute.", "")]
		[ORKEditorLayout("boxPosition", PortraitBoxPosition.Within, elseCheckGroup=true, endCheckGroup=true, 
			setDefault=true, defaultValue=false)]
		public bool isRelative = false;
		
		[ORKEditorHelp("Relative To", "Select the the corner of the GUI box the portrait's position will be relative to.", "")]
		[ORKEditorLayout(new string[] {"isRelative", "boxPosition"}, 
			new System.Object[] {true, PortraitBoxPosition.Within}, needed=Needed.One, endCheckGroup=true)]
		public TextAnchor relativeTo = TextAnchor.UpperLeft;
		
		
		// size
		[ORKEditorHelp("Vertical Scale", "The portrait will be scaled using the screen height.\n" +
			"If disabled, the screen width will be used to scale.", "")]
		[ORKEditorInfo(separator=true, labelText="Portrait Size")]
		public bool verticalScale = false;
		
		[ORKEditorHelp("Set Size", "Set the size of the portrait.\n" +
		 	"If disabled, the width and height of the portrait image are used.\n" +
		 	"Please note, that the image can be distorted if you set the size.", "")]
		public bool setSize = false;
		
		[ORKEditorHelp("Size", "Set the width (X) and height (Y) of the portrait.", "")]
		[ORKEditorLayout("setSize", true, endCheckGroup=true)]
		public Vector2 imageSize = new Vector2(100, 100);
		
		public PortraitPosition()
		{
			
		}
		
		public void Show(Portrait portrait, Rect boxBounds)
		{
			if(portrait.image != null)
			{
				Vector2 ratio = new Vector2(Screen.width / ORK.GameSettings.defaultScreen.x, 
					Screen.height / ORK.GameSettings.defaultScreen.y);
				
				Rect bounds = new Rect(this.position.x, this.position.y, 
					((this.setSize ? this.imageSize.x : portrait.image.width) / ratio.x) * (this.verticalScale ? ratio.x : ratio.y), 
					((this.setSize ? this.imageSize.y : portrait.image.height) / ratio.y) * (this.verticalScale ? ratio.x : ratio.y));
				
				if(PortraitBoxPosition.Within.Equals(this.boxPosition))
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(boxBounds, this.relativeTo);
					bounds.x += (tmp.x - boxBounds.x);
					bounds.y += (tmp.y - boxBounds.y);
				}
				else if(this.isRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(boxBounds, this.relativeTo);
					bounds.x += tmp.x;
					bounds.y += tmp.y;
				}
				
				GUIHelper.GetRectAnchor(ref bounds, -bounds.width, -bounds.height, this.anchor);
				
				if(portrait.useAlphaMask)
				{
					if(Event.current.type == EventType.repaint)
					{
						Graphics.DrawTexture(bounds, portrait.image, portrait.GetMaterial());
					}
				}
				else
				{
					GUI.DrawTexture(bounds, portrait.image, ScaleMode.StretchToFill);
				}
			}
		}
	}
}
