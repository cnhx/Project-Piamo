
using UnityEngine;
using ORKFramework;

namespace ORKFramework.Menu
{
	public class QuantityCall : BaseData
	{
		[ORKEditorHelp("Quantity Type", "Select the type of the quantity determination:\n" +
			"- Default: The default quantity selection setting is used.\n" +
			"- One: 1 item.\n" +
			"- All: All available items.\n" +
			"- Select: Select the quantity using a quantity selection.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public QuantityType type = QuantityType.Default;
		
		[ORKEditorLayout("type", QuantityType.Select, endCheckGroup=true, autoInit=true)]
		public QuantityDefault selection;
		
		public QuantityCall()
		{
			
		}
		
		public void Call(QuantityData data)
		{
			if(QuantityType.Default.Equals(this.type))
			{
				if(QuantitySelectionMode.Remove.Equals(data.mode))
				{
					ORK.MenuSettings.quantityRemove.Call(data);
				}
				else if(QuantitySelectionMode.Drop.Equals(data.mode))
				{
					ORK.MenuSettings.quantityDrop.Call(data);
				}
				else if(QuantitySelectionMode.Give.Equals(data.mode))
				{
					ORK.MenuSettings.quantityGive.Call(data);
				}
				else if(QuantitySelectionMode.Buy.Equals(data.mode))
				{
					ORK.MenuSettings.quantityBuy.Call(data);
				}
				else if(QuantitySelectionMode.Sell.Equals(data.mode))
				{
					ORK.MenuSettings.quantitySell.Call(data);
				}
			}
			else if(QuantityType.One.Equals(this.type))
			{
				data.Execute(1);
			}
			else if(QuantityType.All.Equals(this.type))
			{
				data.Execute(data.shortcut.Quantity);
			}
			else if(QuantityType.Select.Equals(this.type))
			{
				this.selection.Call(data);
			}
		}
	}
}
