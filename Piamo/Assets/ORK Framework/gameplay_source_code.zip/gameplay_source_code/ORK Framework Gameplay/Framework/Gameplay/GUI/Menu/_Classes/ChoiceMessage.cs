
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu
{
	public class ChoiceMessage : BaseData
	{
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the description box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {"%n = name"})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		[ORKEditorHelp("Message Text", "The text displayed in the GUI box.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Message", 
			label=new string[] {"%n = name, %d = description"})]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		public string[] message = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		public ChoiceMessage()
		{
			
		}
		
		public string GetMessage(out string t, string name, string desc)
		{
			if(this.useTitle)
			{
				t = this.title[ORK.Game.Language].Replace("%n", name);
			}
			else
			{
				t = "";
			}
			return this.message[ORK.Game.Language].Replace("%n", name).Replace("%d", desc);
		}
	}
}
