
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Change Faction", "Changes the faction of a combatant's group.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Faction Steps")]
	public class ChangeFactionStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor who's group faction will change.\n" +
			"If the actor doesn't have a combatant, nothing happens.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Faction", "Select the faction the combatant's group will change to.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		public int id2 = 0;
		
		public ChangeFactionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<GameObject> list = baseEvent.GetActorObject(this.id);
			foreach(GameObject obj in list)
			{
				if(obj != null)
				{
					Combatant c = ComponentHelper.GetCombatant(obj);
					if(c != null && c.Group.FactionID >= 0)
					{
						c.Group.FactionID = this.id2;
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Change Faction Sympathy", "Changes the sympathy of a faction for another faction.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Faction Steps")]
	public class ChangeFactionSympathyStep : BaseEventStep
	{
		// change faction
		[ORKEditorHelp("Use Actor", "Change the sympathy of an actor's (combatant) faction.", "")]
		[ORKEditorInfo(labelText="Change Faction")]
		public bool useActor = false;
		
		[ORKEditorHelp("Actor", "Select the actor who's faction will change sympathy values.\n" +
			"If the actor doesn't have a combatant, nothing happens.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("useActor", true)]
		public int id = 0;
		
		[ORKEditorHelp("Faction", "Select the faction that will be changed.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id2 = 0;
		
		
		// sympathy change
		[ORKEditorHelp("Use Actor", "Change the sympathy for an actor's (combatant) faction.", "")]
		[ORKEditorInfo(labelText="Change Sympathy For", separator=true)]
		public bool useActor2 = false;
		
		[ORKEditorHelp("Actor", "Select the actor who's faction will be used.\n" +
			"If the actor doesn't have a combatant, nothing happens.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("useActor2", true)]
		public int id3 = 0;
		
		[ORKEditorHelp("Faction", "Select the faction that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id4 = 0;
		
		
		// change by
		[ORKEditorInfo(labelText="Change By", separator=true)]
		public EventFloat value = new EventFloat();
		
		[ORKEditorHelp("Operator", "Decides how the sympathy value will be changed.\n" +
			"- Add: The value will be added to the current sympathy value.\n" +
			"- Sub: The value will be subtracted from the current sympathy value.\n" +
			"- Set: The sympathy value will be set to the value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public SimpleOperator op = SimpleOperator.Add;
		
		public ChangeFactionSympathyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<int> factions = new List<int>();
			List<int> sympathy = new List<int>();
			
			// change factions
			if(this.useActor)
			{
				List<GameObject> list = baseEvent.GetActorObject(this.id);
				foreach(GameObject obj in list)
				{
					if(obj != null)
					{
						Combatant c = ComponentHelper.GetCombatant(obj);
						// no player allowed
						if(c != null && c.Group.FactionID >= 0 && 
							!factions.Contains(c.Group.FactionID))
						{
							factions.Add(c.Group.FactionID);
						}
					}
				}
			}
			else
			{
				factions.Add(this.id2);
			}
			// sympathy factions
			if(this.useActor2)
			{
				List<GameObject> list = baseEvent.GetActorObject(this.id3);
				foreach(GameObject obj in list)
				{
					if(obj != null)
					{
						Combatant c = ComponentHelper.GetCombatant(obj);
						if(c != null && !sympathy.Contains(c.Group.FactionID))
						{
							sympathy.Add(c.Group.FactionID);
						}
					}
				}
			}
			else
			{
				sympathy.Add(this.id4);
			}
			foreach(int i in factions)
			{
				foreach(int j in sympathy)
				{
					ORK.Game.Faction.ChangeSympathy(i, j, this.value.GetValue(baseEvent), this.op);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.op.ToString() + " " + this.value.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Check Faction", "Checks the faction of a combatant.\n" +
		"If the faction equals a defined faction, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Faction Steps", "Check Steps")]
	public class CheckFactionStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor who's faction will be checked.\n" +
			"If the actor doesn't have a combatant, the check fails.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;
		
		[ORKEditorHelp("Faction", "Select the faction that will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		public int id2 = 0;
		
		public CheckFactionStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			Combatant c = ComponentHelper.GetFirstCombatant(baseEvent.GetActorObject(this.id));
			if(c != null && c.Group.FactionID == this.id2)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Factions.GetName(this.id2);
		}
	}
	
	[ORKEditorHelp("Check Faction Sympathy", "Checks the sympathy a faction has for another faction.\n" +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Faction Steps", "Check Steps")]
	public class CheckFactionSympathyStep : BaseEventCheckStep
	{
		// change faction
		[ORKEditorHelp("Use Actor", "Checks the sympathy of an actor's (combatant) faction.", "")]
		[ORKEditorInfo(labelText="Check Faction")]
		public bool useActor = false;
		
		[ORKEditorHelp("Actor", "Select the actor who's faction will be checked.\n" +
			"If the actor doesn't have a combatant, the check fails.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("useActor", true)]
		public int id = 0;
		
		[ORKEditorHelp("Faction", "Select the faction that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id2 = 0;
		
		
		// sympathy change
		[ORKEditorHelp("Use Actor", "Check the sympathy for an actor's (combatant) faction.", "")]
		[ORKEditorInfo(labelText="Check Sympathy For", separator=true)]
		public bool useActor2 = false;
		
		[ORKEditorHelp("Actor", "Select the actor who's faction will be checked for.\n" +
			"If the actor doesn't have a combatant, the check fails.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("useActor2", true)]
		public int id3 = 0;
		
		[ORKEditorHelp("Faction", "Select the faction that will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id4 = 0;
		
		
		// check by
		[ORKEditorInfo(labelText="Check", separator=true)]
		public EventFloat value = new EventFloat();
		
		[ORKEditorHelp("Check", "Check if the sympathy value is equal, not equal, less or greater than the defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public ValueCheck check = ValueCheck.IsEqual;
		
		public CheckFactionSympathyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			// get faction ID
			int factionID = -1;
			if(this.useActor)
			{
				Combatant c = ComponentHelper.GetFirstCombatant(baseEvent.GetActorObject(this.id));
				if(c != null)
				{
					factionID = c.Group.FactionID;
				}
			}
			else
			{
				factionID = this.id2;
			}
			
			// get sympathy ID
			int factionID2 = -1;
			if(this.useActor2)
			{
				Combatant c = ComponentHelper.GetFirstCombatant(baseEvent.GetActorObject(this.id3));
				if(c != null)
				{
					factionID2 = c.Group.FactionID;
				}
			}
			else
			{
				factionID2 = this.id4;
			}
			
			// check
			if(factionID >= 0 && factionID2 >= 0)
			{
				float val = this.value.GetValue(baseEvent);
				float val2 = ORK.Game.Faction.GetSympathy(factionID, factionID2);
				
				if(ValueHelper.CheckValue(val2, val, this.check))
				{
					baseEvent.StepFinished(this.next);
				}
				else
				{
					baseEvent.StepFinished(this.nextFail);
				}
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString() + " " + this.value.GetInfoText();
		}
	}
}
