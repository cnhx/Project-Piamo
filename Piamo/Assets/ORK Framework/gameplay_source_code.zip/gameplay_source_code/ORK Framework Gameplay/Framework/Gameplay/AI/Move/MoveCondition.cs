
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveCondition : BaseData
	{
		[ORKEditorHelp("Type", "Select the type of the condition's check:\n" +
			"- Level: Checks the target's level.\n" +
			"- Class Level: Checks the target's class level.\n" +
			"- Group Size: Checks the target's group size.\n" +
			"- Status: Advanced status requirement.", "")]
		public MoveConditionType type = MoveConditionType.Level;
		
		
		// level/class level
		[ORKEditorHelp("Use Offset", "The defined level is added to the combatant's level for the check.\n" +
			"If disabled, only the defined level is used.", "")]
		[ORKEditorLayout(new string[] {"type", "type"}, new System.Object[] {MoveConditionType.Level, MoveConditionType.ClassLevel}, 
			needed=Needed.One)]
		public bool levelOffset = true;
		
		[ORKEditorHelp("Level", "Define the level that will be compared.", "")]
		public int level = 1;
		
		[ORKEditorHelp("Check Type", "Checks if the target's level is equal, not equal, less or greater than the defined level.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public ValueCheck levelCheck = ValueCheck.IsGreater;
		
		[ORKEditorHelp("Average Level", "Use the target's average group level for the check.\n" +
			"If disabled, the target's level is used.", "")]
		public bool levelAverage = false;
		
		[ORKEditorHelp("Only Battle Group", "Only the target's battle group is used for the average level.\n" +
			"If disabled, the whole group is used.", "")]
		[ORKEditorLayout("levelAverage", true, endCheckGroup=true, endGroups=2)]
		public bool levelOnlyBattle = true;
		
		
		// group size
		[ORKEditorHelp("Group Size", "Define the group size that will be compared.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("type", MoveConditionType.GroupSize)]
		public int groupSize = 1;
		
		[ORKEditorHelp("Check Type", "Checks if the target's group size is equal, not equal, less or greater than the defined size.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public ValueCheck groupSizeCheck = ValueCheck.IsGreater;
		
		[ORKEditorHelp("Only Battle Group", "Only the target's battle group is used for the size check.\n" +
			"If disabled, the whole size of the whole group is used (i.e. all available group members).", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool groupSizeOnlyBattle = true;
		
		
		// status condition
		[ORKEditorLayout("type", MoveConditionType.Status, endCheckGroup=true, autoInit=true)]
		public StatusRequirement statusRequirement;
		
		public MoveCondition()
		{
			
		}
		
		public bool IsValid(Combatant combatant, Combatant target)
		{
			if(MoveConditionType.Level.Equals(this.type))
			{
				if(this.levelAverage)
				{
					if(this.levelOnlyBattle)
					{
						return ValueHelper.CheckValue(target.Group.AverageBattleLevel, 
							this.levelOffset ? combatant.Level + this.level : this.level, this.levelCheck);
					}
					else
					{
						return ValueHelper.CheckValue(target.Group.AverageLevel, 
							this.levelOffset ? combatant.Level + this.level : this.level, this.levelCheck);
					}
				}
				else
				{
					return ValueHelper.CheckValue(target.Level, 
						this.levelOffset ? combatant.Level + this.level : this.level, this.levelCheck);
				}
			}
			else if(MoveConditionType.ClassLevel.Equals(this.type))
			{
				if(this.levelAverage)
				{
					if(this.levelOnlyBattle)
					{
						return ValueHelper.CheckValue(target.Group.AverageBattleClassLevel, 
							this.levelOffset ? combatant.ClassLevel + this.level : this.level, this.levelCheck);
					}
					else
					{
						return ValueHelper.CheckValue(target.Group.AverageClassLevel, 
							this.levelOffset ? combatant.ClassLevel + this.level : this.level, this.levelCheck);
					}
				}
				else
				{
					return ValueHelper.CheckValue(target.ClassLevel, 
						this.levelOffset ? combatant.ClassLevel + this.level : this.level, this.levelCheck);
				}
			}
			else if(MoveConditionType.GroupSize.Equals(this.type))
			{
				if(this.groupSizeOnlyBattle)
				{
					return ValueHelper.CheckValue(target.Group.BattleSize, this.groupSize, this.groupSizeCheck);
				}
				else
				{
					return ValueHelper.CheckValue(target.Group.Size, this.groupSize, this.groupSizeCheck);
				}
			}
			else if(MoveConditionType.Status.Equals(this.type))
			{
				return this.statusRequirement.CheckRequirement(target);
			}
			return false;
		}
	}
}
