
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ChoiceContent
	{
		private GUIContent content;
	
		private string info = "";
	
		private GUIContent title;
		
		private Texture2D contentIcon;
	
		public bool active = true;
	
		public bool isButton = true;
		
		public string description = "";
		
		
		// calced positions
		public MultiContent titleLabel;
	
		public MultiContent contentLabel;
	
		public MultiContent infoLabel;
		
		public List<MultiHUDContent> statusContent;
		
		public Vector2 titleSize = Vector2.zero;
		
		public Vector2 contentSize = Vector2.zero;
	
		public bool selectFirst = false;
		
		
		// button/content positions
		public Rect titleBounds = new Rect(0, 0, 0, 0);
		
		public Rect buttonBounds = new Rect(0, 0, 0, 0);
		
		public Rect tImgBounds = new Rect(0, 0, 0, 0);
		
		public Rect cImgBounds = new Rect(0, 0, 0, 0);
		
		
		// combatant for status information
		public Combatant combatant;
		
		
		// drag and drop
		public bool isDragable = false;
	
		public bool isDoubleClick = false;
	
		public bool isTooltip = false;
		
		public bool dragInactive = false;
		
		
		// auto use
		public bool useOnGroupTarget = false;
		
		public bool useOnIndividualTarget = false;
		
		public DragInfo drag;
		
		
		// portrait
		public Portrait portrait;
		
		public ChoiceContent()
		{
			
		}
		
		public ChoiceContent(Combatant combatant)
		{
			this.combatant = combatant;
			this.Content = new GUIContent();
		}
		
		public ChoiceContent(GUIContent content) : this(content, true, "", null)
		{
			
		}
		
		public ChoiceContent(GUIContent content, bool active) : this(content, active, "", null)
		{
			
		}
		
		public ChoiceContent(GUIContent content, bool active, string info) : this(content, active, info, null)
		{
			
		}
		
		public ChoiceContent(GUIContent content, bool active, string info, GUIContent title)
		{
			this.Content = content;
			this.active = active;
			this.Info = info;
			this.Title = title;
		}
		
		
		/*
		============================================================================
		Get/Set functions
		============================================================================
		*/
		public GUIContent Content
		{
			get{ return this.content;}
			set
			{
				this.content = value;
				if(this.content != null && this.content.text != null && this.content.text != "")
				{
					this.content.text = TextHelper.ReplaceSpecials(this.content.text);
				}
			}
		}
		
		public Texture2D ContentIcon
		{
			get{ return this.contentIcon;}
			set{ this.contentIcon = value;}
		}
		
		public string Info
		{
			get{ return this.info;}
			set
			{
				this.info = value;
				if(this.info != null && this.info != "")
				{
					TextHelper.ReplaceSpecials(ref this.info);
				}
			}
		}
		
		public GUIContent Title
		{
			get{ return this.title;}
			set
			{
				this.title = value;
				if(this.title != null && this.title.text != null && this.title.text != "")
				{
					this.title.text = TextHelper.ReplaceSpecials(this.title.text);
				}
			}
		}
		
		
		/*
		============================================================================
		Unity GUI functions
		============================================================================
		*/
		public void InitTitle(GUIStyle textStyle, Rect textBounds, ButtonSettings setting, float titlePadding, float titleWidth)
		{
			this.titleBounds.x = textBounds.x;
			this.titleBounds.y = textBounds.y;
			
			if(this.title != null && (this.title.text != "" || this.title.image != null))
			{
				textBounds.x = setting.padding.x;
				textBounds.y = setting.padding.y;
				if(titleWidth > 0)
				{
					textBounds.width = titleWidth;
				}
				else
				{
					textBounds.width -= (setting.padding.x + setting.padding.z);
				}
				textBounds.height -= (setting.padding.y + setting.padding.w);
				
				if(!setting.alignIcons && this.title.image != null)
				{
					Vector2 v = textStyle.CalcSize(new GUIContent(this.title.image));
					textBounds.x += v.x + setting.iconPadding;
					textBounds.width -= v.x + setting.iconPadding;
					this.tImgBounds = new Rect(setting.padding.x, setting.padding.y, v.x, v.y);
				}
				this.titleLabel = new MultiContent(this.title.text != "" ? this.title.text : " ", 
					setting.alignIcons ? this.title.image as Texture2D : null, null, 
					textStyle, textBounds, setting.lineSpacing, TextAlignment.Left, VerticalTextAlignment.Bottom, 
					BoxHeightAdjustment.Auto, setting.oneline, 
					setting.ownTitleFormat ? setting.titleFormat : setting.textFormat);
				
				this.titleSize = this.titleLabel.size;
				if(this.titleSize.x < titleWidth)
				{
					this.titleSize.x = titleWidth;
				}
				this.titleSize.x += titlePadding;
				if(this.titleSize.y < this.tImgBounds.height)
				{
					this.titleSize.y = this.tImgBounds.height;
				}
				this.titleSize.y += setting.padding.w;
				
				this.titleBounds.width = this.titleSize.x;
				this.titleBounds.height = this.titleSize.y;
			}
		}
		
		public void InitContent(GUIStyle textStyle, Rect textBounds, bool selectFirst, ButtonSettings setting, HUDStatus[] statusInformation)
		{
			this.selectFirst = selectFirst;
			
			this.buttonBounds.x = textBounds.x + this.titleBounds.width;
			this.buttonBounds.y = textBounds.y;
			
			this.contentSize = new Vector2(textBounds.width, 0);
			
			textBounds.x = setting.padding.x;
			textBounds.y = setting.padding.y;
			textBounds.width -= (setting.padding.x + setting.padding.z);
			textBounds.height -= (setting.padding.y + setting.padding.w);
			
			Rect tmp = textBounds;
			
			// content
			if(this.content != null)
			{
				if(!setting.alignIcons && this.content.image != null)
				{
					Vector2 v = textStyle.CalcSize(new GUIContent(this.content.image));
					tmp.x += v.x + setting.iconPadding;
					tmp.width -= v.x + setting.iconPadding;
					this.cImgBounds = new Rect(setting.padding.x, setting.padding.y, v.x, v.y);
				}
				this.contentLabel = new MultiContent(this.content.text != "" ? this.content.text : " ", 
					setting.alignIcons ? this.content.image as Texture2D : null, this.contentIcon, 
					textStyle, tmp, setting.lineSpacing, setting.alignment, setting.vAlignment, 
					BoxHeightAdjustment.Auto, setting.oneline, setting.textFormat);
				
				this.contentSize = this.contentLabel.size;
			}
			else
			{
				this.content = new GUIContent();
				this.contentLabel = new MultiContent(" ", null, null, textStyle, tmp, setting.lineSpacing, 
					setting.alignment, setting.vAlignment, 
					BoxHeightAdjustment.Auto, setting.oneline, setting.textFormat);
				
				this.contentSize = this.contentLabel.size;
			}
			
			// info
			if("" != this.info)
			{
				this.infoLabel = new MultiContent(this.info, null, null, textStyle, tmp, setting.lineSpacing, 
					setting.alignmentInfo, setting.vAlignmentInfo, 
					BoxHeightAdjustment.Auto, setting.oneline, 
					setting.ownInfoFormat ? setting.infoFormat : setting.textFormat);
				
				if(this.contentSize.x < this.infoLabel.size.x)
				{
					this.contentSize.x = this.infoLabel.size.x;
				}
				if(this.contentSize.y < this.infoLabel.size.y)
				{
					this.contentSize.y = this.infoLabel.size.y;
				}
			}
			
			// status information
			if(this.combatant != null && statusInformation != null)
			{
				this.statusContent = new List<MultiHUDContent>();
				
				for(int i=0; i<statusInformation.Length; i++)
				{
					MultiHUDContent mhc = new MultiHUDContent(statusInformation[i], textStyle, this.combatant);
					
					if(mhc.label != null)
					{
						if(this.contentSize.x < statusInformation[i].bounds.x + mhc.bounds.width)
						{
							this.contentSize.x = statusInformation[i].bounds.x + mhc.bounds.width;
						}
						if(this.contentSize.y < statusInformation[i].bounds.y + mhc.bounds.height)
						{
							this.contentSize.y = statusInformation[i].bounds.y + mhc.bounds.height;
						}
						
						this.statusContent.Add(mhc);
					}
				}
			}
			// drag shortcut level points
			else if(this.drag != null && this.drag.Shortcut != null && 
				this.drag.LevelPointsDisplay != null)
			{
				this.statusContent = new List<MultiHUDContent>();
				
				for(int i=0; i<this.drag.LevelPointsDisplay.Length; i++)
				{
					MultiHUDContent mhc = new MultiHUDContent(this.drag.LevelPointsDisplay[i], textStyle, this.drag.Shortcut);
					
					if(mhc.label != null)
					{
						if(this.contentSize.x < this.drag.LevelPointsDisplay[i].bounds.x + mhc.bounds.width)
						{
							this.contentSize.x = this.drag.LevelPointsDisplay[i].bounds.x + mhc.bounds.width;
						}
						if(this.contentSize.y < this.drag.LevelPointsDisplay[i].bounds.y + mhc.bounds.height)
						{
							this.contentSize.y = this.drag.LevelPointsDisplay[i].bounds.y + mhc.bounds.height;
						}
						
						this.statusContent.Add(mhc);
					}
				}
			}
			
			this.buttonBounds.width = this.contentSize.x + setting.padding.z;
			this.buttonBounds.height = this.contentSize.y + setting.padding.w;
			
			if(this.buttonBounds.width < textBounds.width + setting.padding.x + setting.padding.z)
			{
				this.buttonBounds.width = textBounds.width + setting.padding.x + setting.padding.z;
			}
			if(this.titleBounds.height < this.buttonBounds.height)
			{
				this.titleBounds.height = this.buttonBounds.height;
			}
			else if(this.buttonBounds.height < this.titleBounds.height)
			{
				this.buttonBounds.height = this.titleBounds.height;
			}
		}
		
		
		/*
		============================================================================
		Utility functions
		============================================================================
		*/
		public void SetBounds(Rect bounds)
		{
			this.buttonBounds = bounds;
			this.titleBounds = bounds;
		}
		
		public void SetPosition(Vector2 newPos)
		{
			this.titleBounds.x = newPos.x;
			this.titleBounds.y = newPos.y;
			this.buttonBounds.x = newPos.x + this.titleBounds.width;
			this.buttonBounds.y = newPos.y;
		}
		
		public void SetHeight(float height)
		{
			this.titleBounds.height = height;
			this.buttonBounds.height = height;
		}
		
		public void SetToContentSize(Vector4 padding)
		{
			this.buttonBounds.width = this.contentSize.x + padding.x + padding.z;
			this.buttonBounds.height = this.contentSize.y + padding.y + padding.w;
		}
		
		public void CheckBiggestContent(ref Vector2 size)
		{
			if(size.x < this.buttonBounds.width)
			{
				size.x = this.buttonBounds.width;
			}
			if(size.y < this.buttonBounds.height)
			{
				size.y = this.buttonBounds.height;
			}
		}
		
		public void MoveX(float add)
		{
			this.titleBounds.x += add;
			this.buttonBounds.x += add;
		}
	}
}
