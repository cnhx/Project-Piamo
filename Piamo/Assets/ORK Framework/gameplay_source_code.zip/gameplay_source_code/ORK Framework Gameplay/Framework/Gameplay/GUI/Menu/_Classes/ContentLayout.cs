
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ContentLayout : BaseData
	{
		// content
		[ORKEditorHelp("Content Type", "Select the content type:\n" +
			"- Text: Only texts will be displayed.\n" +
			"- Icon: Only icons will be displayed.\n" +
			"- Both: Text and icons will be displayed.\n" +
			"- Custom: Define the layout in a text area using text codes.", "")]
		public ContentLayoutType type = ContentLayoutType.Both;
		
		// complex content
		[ORKEditorHelp("Content Text", "The text used to display the content.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, 
			label=new string[] {
				"%n = name, %d = description, %i = icon", 
				"%tn = type name, %td = type description, %ti = type icon", 
				"%l = level up costs, % = info (e.g. quantity, use costs)"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorLayout("type", ContentLayoutType.Custom, endCheckGroup=true, 
			autoInit=true, autoLangSize=true)]
		public string[] text;
		
		
		// info
		[ORKEditorHelp("Info Type", "Select the info type:\n" +
			"- None: No info will be displayed.\n" +
			"- Info: The info (e.g. quantity, use costs, price) will be displayed.\n" +
			"- Level Up Costs: The level up costs (abilities, equipment) will be displayed.\n" +
			"- Custom: Define the info in a text area using text codes.", "")]
		public ContentLayoutInfoType infoType = ContentLayoutInfoType.Info;
		
		// complex info
		[ORKEditorHelp("Info Text", "The text used to display the info.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, 
			label=new string[] {
			"%n = name, %d = description, %i = icon", 
			"%tn = type name, %td = type description, %ti = type icon", 
			"%l = level up costs, % = info (e.g. quantity, use costs)"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorLayout("infoType", ContentLayoutInfoType.Custom, endCheckGroup=true, 
			autoInit=true, autoLangSize=true)]
		public string[] infoText;
		
		public ContentLayout()
		{
			
		}
		
		public ContentLayout(ContentLayoutType type, ContentLayoutInfoType infoType)
		{
			this.type = type;
			this.infoType = infoType;
		}
		
		
		/*
		============================================================================
		Text functions
		============================================================================
		*/
		public string GetText(string name, string desc, string icon, 
			string typeName, string typeDesc, string typeIcon, 
			string lvlInfo, string info)
		{
			if(this.text[ORK.Game.Language].Contains("%"))
			{
				return this.text[ORK.Game.Language].
					Replace("%n", name).
					Replace("%d", desc).
					Replace("%i", icon).
					Replace("%tn", typeName).
					Replace("%td", typeDesc).
					Replace("%ti", typeIcon).
					Replace("%l", lvlInfo).
					Replace("%", info);
			}
			else
			{
				return this.text[ORK.Game.Language];
			}
		}
		
		public string GetInfo(string name, string desc, string icon, 
			string typeName, string typeDesc, string typeIcon, 
			string lvlInfo, string info)
		{
			if(this.infoText[ORK.Game.Language].Contains("%"))
			{
				return this.infoText[ORK.Game.Language].
					Replace("%n", name).
					Replace("%d", desc).
					Replace("%i", icon).
					Replace("%tn", typeName).
					Replace("%td", typeDesc).
					Replace("%ti", typeIcon).
					Replace("%l", lvlInfo).
					Replace("%", info);
			}
			else
			{
				return this.infoText[ORK.Game.Language];
			}
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public ChoiceContent GetChoiceContent(LanguageInfo[] info)
		{
			ChoiceContent cc = null;
			
			// content
			if(ContentLayoutType.Text.Equals(this.type))
			{
				cc = new ChoiceContent(new GUIContent(info[ORK.Game.Language].name));
			}
			else if(ContentLayoutType.Icon.Equals(this.type))
			{
				cc = new ChoiceContent(new GUIContent(info[ORK.Game.Language].icon));
			}
			else if(ContentLayoutType.Both.Equals(this.type))
			{
				cc = new ChoiceContent(info[ORK.Game.Language].GetContent());
			}
			else if(ContentLayoutType.Custom.Equals(this.type))
			{
				LanguageInfo tmp = info[ORK.Game.Language];
				cc = new ChoiceContent(new GUIContent(
					this.GetText(
						tmp.name, tmp.description, TextCode.ContentIcon, 
						"", "", "", 
						"", "")));
				cc.ContentIcon = tmp.icon;
			}
			
			// info
			if(cc != null)
			{
				LanguageInfo tmp = info[ORK.Game.Language];
				cc.description = tmp.description;
				
				if(ContentLayoutInfoType.Custom.Equals(this.infoType))
				{
					cc.Info = this.GetInfo(
						tmp.name, tmp.description, TextCode.ContentIcon, 
						"", "", "", 
						"", "");
				}
			}
			
			return cc;
		}
		
		public ChoiceContent GetChoiceContent(IContentSimple content)
		{
			ChoiceContent cc = null;
			
			// content
			if(ContentLayoutType.Text.Equals(this.type))
			{
				cc = new ChoiceContent(new GUIContent(content.GetName()));
			}
			else if(ContentLayoutType.Icon.Equals(this.type))
			{
				cc = new ChoiceContent(new GUIContent(content.GetIcon()));
			}
			else if(ContentLayoutType.Both.Equals(this.type))
			{
				cc = new ChoiceContent(new GUIContent(content.GetContent()));
			}
			else if(ContentLayoutType.Custom.Equals(this.type))
			{
				cc = new ChoiceContent(new GUIContent(
					this.GetText(
						content.GetName(), content.GetDescription(), content.GetIconTextCode(), 
						"", "", "", 
						"", "")));
			}
			
			// info
			if(cc != null)
			{
				cc.description = content.GetDescription();
				
				if(ContentLayoutInfoType.Custom.Equals(this.infoType))
				{
					cc.Info = this.GetInfo(
						content.GetName(), content.GetDescription(), content.GetIconTextCode(), 
						"", "", "", 
						"", "");
				}
			}
			
			return cc;
		}
		
		public ChoiceContent GetChoiceContent(IContent content, Combatant combatant)
		{
			ChoiceContent cc = null;
			
			// content
			if(ContentLayoutType.Text.Equals(this.type))
			{
				cc = new ChoiceContent(new GUIContent(content.GetName()));
			}
			else if(ContentLayoutType.Icon.Equals(this.type))
			{
				cc = new ChoiceContent(new GUIContent(content.GetIcon()));
			}
			else if(ContentLayoutType.Both.Equals(this.type))
			{
				cc = new ChoiceContent(new GUIContent(content.GetContent()));
			}
			else if(ContentLayoutType.Custom.Equals(this.type))
			{
				IContentSimple typeContent = content.GetTypeContent();
				cc = new ChoiceContent(new GUIContent(
					this.GetText(
						content.GetName(), content.GetDescription(), content.GetIconTextCode(), 
						typeContent.GetName(), typeContent.GetDescription(), typeContent.GetIconTextCode(), 
						"", content.GetInfo(combatant))));
			}
			
			// info
			if(cc != null)
			{
				cc.description = content.GetDescription();
				
				if(ContentLayoutInfoType.Info.Equals(this.infoType))
				{
					cc.Info = content.GetInfo(combatant);
				}
				else if(ContentLayoutInfoType.Custom.Equals(this.infoType))
				{
					IContentSimple typeContent = content.GetTypeContent();
					cc.Info = this.GetInfo(
						content.GetName(), content.GetDescription(), content.GetIconTextCode(), 
						typeContent.GetName(), typeContent.GetDescription(), typeContent.GetIconTextCode(), 
						"", content.GetInfo(combatant));
				}
			}
			
			return cc;
		}
		
		public ChoiceContent GetChoiceContent(IShortcut content, Combatant combatant)
		{
			ChoiceContent cc = null;
			
			// content
			if(ContentLayoutType.Text.Equals(this.type))
			{
				cc = new ChoiceContent(new GUIContent(content.GetName()));
			}
			else if(ContentLayoutType.Icon.Equals(this.type))
			{
				cc = new ChoiceContent(new GUIContent(content.GetIcon()));
			}
			else if(ContentLayoutType.Both.Equals(this.type))
			{
				cc = new ChoiceContent(new GUIContent(content.GetContent()));
			}
			else if(ContentLayoutType.Custom.Equals(this.type))
			{
				IContentSimple typeContent = content.GetTypeContent();
				cc = new ChoiceContent(new GUIContent(
					this.GetText(
						content.GetName(), content.GetDescription(), content.GetIconTextCode(), 
						typeContent.GetName(), typeContent.GetDescription(), typeContent.GetIconTextCode(), 
						content.GetLevelUpCostString(), content.GetInfo(combatant))));
			}
			
			// info
			if(cc != null)
			{
				cc.description = content.GetDescription();
				
				if(ContentLayoutInfoType.Info.Equals(this.infoType))
				{
					cc.Info = content.GetInfo(combatant);
				}
				else if(ContentLayoutInfoType.LevelUpCost.Equals(this.infoType))
				{
					cc.Info = content.GetLevelUpCostString();
				}
				else if(ContentLayoutInfoType.Custom.Equals(this.infoType))
				{
					IContentSimple typeContent = content.GetTypeContent();
					cc.Info = this.GetInfo(
						content.GetName(), content.GetDescription(), content.GetIconTextCode(), 
						typeContent.GetName(), typeContent.GetDescription(), typeContent.GetIconTextCode(), 
						content.GetLevelUpCostString(), content.GetInfo(combatant));
				}
			}
			
			return cc;
		}
		
		
		/*
		============================================================================
		Info functions
		============================================================================
		*/
		public string GetInfoContent(IShortcut content, string info)
		{
			if(ContentLayoutInfoType.Info.Equals(this.infoType))
			{
				return info;
			}
			else if(ContentLayoutInfoType.LevelUpCost.Equals(this.infoType))
			{
				return content.GetLevelUpCostString();
			}
			else if(ContentLayoutInfoType.Custom.Equals(this.infoType))
			{
				IContentSimple typeContent = content.GetTypeContent();
				return this.GetInfo(
					content.GetName(), content.GetDescription(), content.GetIconTextCode(), 
					typeContent.GetName(), typeContent.GetDescription(), typeContent.GetIconTextCode(), 
					content.GetLevelUpCostString(), info);
			}
			return "";
		}
	}
}
