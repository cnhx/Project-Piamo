
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Animations
{
	public class Sound : BaseData
	{
		[ORKEditorHelp("Sound Type", "Select the sound type of this sound.", "")]
		[ORKEditorInfo(ORKDataType.SoundType)]
		public int typeID = 0;
		
		[ORKEditorHelp("Audio Clip", "Select the audio clip that will be used when playing this sound.", "")]
		public AudioClip audioClip;
		
		public Sound()
		{
			
		}
	}
}
