
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TitleContentLayout : ContentLayout
	{
		// title
		[ORKEditorHelp("Title Type", "Select the title type:\n" +
			"- Text: Only texts will be displayed.\n" +
			"- Icon: Only icons will be displayed.\n" +
			"- Both: Text and icons will be displayed.\n" +
			"- Custom: Define the layout in a text area using text codes.", "")]
		public ContentLayoutType titleType = ContentLayoutType.Both;
		
		// complex content
		[ORKEditorHelp("Title Text", "The text used to display the title.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, 
			label=new string[] {
				"%n = name, %d = description, %i = icon"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorLayout("titleType", ContentLayoutType.Custom, endCheckGroup=true, 
			autoInit=true, autoLangSize=true)]
		public string[] title;
		
		public TitleContentLayout()
		{
			
		}
		
		public TitleContentLayout(ContentLayoutType titleType, ContentLayoutType type, ContentLayoutInfoType infoType)
		{
			this.titleType = titleType;
			this.type = type;
			this.infoType = infoType;
		}
		
		
		/*
		============================================================================
		Text functions
		============================================================================
		*/
		public string GetTitle(string name, string desc, string icon)
		{
			if(this.title[ORK.Game.Language].Contains("%"))
			{
				return this.title[ORK.Game.Language].
					Replace("%n", name).
					Replace("%d", desc).
					Replace("%i", icon);
			}
			else
			{
				return this.title[ORK.Game.Language];
			}
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public GUIContent GetTitleContent(IContentSimple content)
		{
			GUIContent gc = null;
			
			if(ContentLayoutType.Text.Equals(this.titleType))
			{
				gc = new GUIContent(content.GetName());
			}
			else if(ContentLayoutType.Icon.Equals(this.titleType))
			{
				gc = new GUIContent(content.GetIcon());
			}
			else if(ContentLayoutType.Both.Equals(this.titleType))
			{
				gc = new GUIContent(content.GetContent());
			}
			else if(ContentLayoutType.Custom.Equals(this.titleType))
			{
				gc = new GUIContent(this.GetTitle(
						content.GetName(), content.GetDescription(), content.GetIconTextCode()));
			}
			
			return gc;
		}
	}
}

