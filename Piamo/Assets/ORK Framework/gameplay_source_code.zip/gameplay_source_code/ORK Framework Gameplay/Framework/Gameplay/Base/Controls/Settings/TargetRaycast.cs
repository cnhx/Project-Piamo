
using UnityEngine;

namespace ORKFramework
{
	public class TargetRaycast : BaseData
	{
		[ORKEditorInfo(labelText="Raycast settings")]
		[ORKEditorHelp("Use Target Raycast", "Use a raycast to set the target (position) for an ability or item.\n" +
			"Use this setting for 'area of effect'-spells, etc.", "")]
		public bool active = false;
		
		[ORKEditorHelp("Distance", "The distance the raycast will use.\n" +
			"If nothing is hit within this distance, no target will be found.", "")]
		[ORKEditorLayout("active", true)]
		public float distance = 100.0f;
		
		[ORKEditorHelp("Layer Mask", "Select the layer the raycast will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		public LayerMask layerMask = -1;
		
		[ORKEditorHelp("Ignore User", "The game object of the user of this ability/item will be ignored by the raycast.", "")]
		public bool ignoreUser = false;
		
		[ORKEditorHelp("Ray Origin", "The origin position of the raycast.\n" +
			"- USER: The user of the ability/item is the origin.\n" +
			"- SCREEN: The screen is the origin. If you use mouse/touch control, " +
			"the point you clicked/touched the screen is the origin, else the center of the screen.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public TargetRayOrigin rayOrigin = TargetRayOrigin.User;
		
		[ORKEditorHelp("Path to Child", "You can define a child object of the user to be the origin.\n" +
			"Leave empty if you only want the user to be the origin.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("rayOrigin", TargetRayOrigin.User, endCheckGroup=true)]
		public string pathToChild = "";
		
		[ORKEditorHelp("Offset", "The offset will be added to the origin position of the raycast.", "")]
		public Vector3 offset = Vector3.zero;
		
		[ORKEditorHelp("Direction", "The direction in local space the raycast will be sent to.\n" +
			"E.g. X=0, Y=0, Z=1 will send the raycast forward.\n" +
			"This setting is only used when no mouse/touch control is enabled.", "")]
		[ORKEditorLayout(checkCallback="check:raydirection")]
		public Vector3 rayDirection = Vector3.forward;
		
		[ORKEditorHelp("Path to Child", "If this ability/item is used by an AI controlled combatant, the raycast will " +
			"target a nearby combatant according to the target type.\n" +
			"You can define a child object of the target to be the raycast target.\n" +
			"Leave empty if you only want the target to be the raycast target.", "")]
		[ORKEditorInfo(separator=true, labelText="AI Target", expandWidth=true)]
		public string pathToTarget = "";
		
		[ORKEditorHelp("Target Offset", "Offset added to the AI target position.", "")]
		public Vector3 targetOffset = Vector3.zero;
		
		[ORKEditorLayout(endCheckGroup=true)]
		public MouseTouchControl mouseTouch = new MouseTouchControl();
		
		public TargetRaycast()
		{
			
		}
		
		
		/*
		============================================================================
		Ingame functions
		============================================================================
		*/
		public bool NeedInteraction()
		{
			return this.active && this.mouseTouch.Active();
		}
		
		public void Tick(ActiveBattleMenu menu, GameObject user)
		{
			Vector3 point = Vector3.zero;
			if(this.mouseTouch.Interacted(ref point))
			{
				if(TargetRayOrigin.User.Equals(this.rayOrigin))
				{
					point = this.ScreenRayPoint(point);
				}
				menu.SetRayPoint(this.GetRayPoint(user, point));
			}
		}
		
		public Vector3 ScreenRayPoint(Vector3 point)
		{
			Ray ray = Camera.main.ScreenPointToRay(point);
			RaycastHit hit;
			if(Physics.Raycast(ray, out hit, this.distance, this.layerMask))
			{
				point = hit.point;
			}
			return point;
		}
		
		public Vector3 GetRayPoint(GameObject user, Vector3 target)
		{
			Vector3 point = Vector3.zero;
			if(this.active && user != null)
			{
				Ray ray;
				if(TargetRayOrigin.User.Equals(this.rayOrigin))
				{
					if(this.pathToChild != "")
					{
						Transform tr = user.transform.Find(this.pathToChild);
						if(tr != null)
							user = tr.gameObject;
					}
					Vector3 origin = user.transform.position + offset;
					Vector3 dir = Vector3.zero;
					if(this.mouseTouch.Active())
						dir = VectorHelper.GetDirection(origin, target);
					else
						dir = user.transform.TransformDirection(this.rayDirection);
					ray = new Ray(origin, dir);
				}
				else
				{
					Camera cam = Camera.main;
					ray = cam.ScreenPointToRay(target + this.offset);
				}
				RaycastHit[] hit = Physics.RaycastAll(ray, this.distance, this.layerMask);
				if(hit.Length > 0)
				{
					for(int i=0; i<hit.Length; i++)
					{
						if(!this.ignoreUser || user.transform.root != hit[i].transform.root)
						{
							point = hit[i].point;
							break;
						}
					}
				}
				else
				{
					point = ray.GetPoint(this.distance);
				}
			}
			return point;
		}
		
		public Vector3 GetAIPoint(GameObject user, GameObject target)
		{
			if(this.pathToTarget != "" && target != null)
			{
				Transform t = target.transform.Find(this.pathToChild);
				if(t != null)
				{
					target = t.gameObject;
				}
			}
			Vector3 pos = target.transform.position + this.targetOffset;
			if(TargetRayOrigin.Screen.Equals(this.rayOrigin) && Camera.main != null)
			{
				pos = Camera.main.WorldToScreenPoint(pos);
			}
			return this.GetRayPoint(user, pos);
		}
	}
}
