
using UnityEngine;
using ORKFramework.Reflection;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CustomChoiceCall : BaseData
	{
		// button
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageInfo[] button = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count);
		
		// portrait
		[ORKEditorHelp("Use Portrait", "This custom choice displays a portrait when selected.", "")]
		[ORKEditorInfo(separator=true, labelText="Portrait Settings")]
		public bool usePortrait = false;
		
		[ORKEditorLayout("usePortrait", true, endCheckGroup=true, autoInit=true)]
		public Portrait portrait;
		
		
		// call information
		[ORKEditorInfo(separator=true, labelText="Call Object Settings")]
		public FindObjectSetting findObject = new FindObjectSetting();
		
		// function/component
		[ORKEditorHelp("Component Name", "The name of the component that contains the function.", "")]
		[ORKEditorInfo(separator=true, expandWidth=true, labelText="Function Settings")]
		public string name = "";
		
		public CallMethod method = new CallMethod();
		
		public CustomChoiceCall()
		{
			
		}
		
		public bool Selected()
		{
			List<GameObject> list = this.findObject.Find(null);
			
			for(int i=0; i<list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.method.Call(list[i].GetComponent(this.name)))
					{
						return true;
					}
				}
			}
			
			return false;
		}
	}
}
