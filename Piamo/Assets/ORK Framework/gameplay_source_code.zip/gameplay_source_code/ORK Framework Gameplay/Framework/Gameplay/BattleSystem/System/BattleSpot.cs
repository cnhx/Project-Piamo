
using UnityEngine;

namespace ORKFramework
{
	[System.Serializable]
	public class BattleSpot : BaseData
	{
		[ORKEditorHelp("Spot Coordinates", "The position of the spot in local space of the battle arena.\n" +
			"Defined in X, Y and Z coordinates.", "")]
		public Vector3 spot = Vector3.zero;
		
		
		// random
		[ORKEditorHelp("Add Random", "Add a random offset to the cooridnates of this spot.", "")]
		public bool addRandom = false;
		
		[ORKEditorInfo(labelText="Random Offset")]
		[ORKEditorLayout("addRandom", true, endCheckGroup=true, autoInit=true)]
		public RandomVector3 random;
		
		public BattleSpot()
		{
			
		}
		
		public Vector3 GetSpot()
		{
			if(this.addRandom)
			{
				return this.spot + this.random.GetValue();
			}
			return this.spot;
		}
	}
}
