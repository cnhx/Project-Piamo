
using UnityEngine;
using ORKFramework;
using ORKFramework.Menu.Parts;
using System.Collections.Generic;

namespace ORKFramework.Menu
{
	public class SubMenu : BaseData, IChoice
	{
		[ORKEditorHelp("Call Key", "Select the input key that will call the sub menu.\n" +
			"If the same input key as the 'Accept' key is used, the sub menu will be called instead of using the selected menu item.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int keyID = 0;
		
		[ORKEditorHelp("GUI Box", "Select the box used to display the sub menu.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		[ORKEditorHelp("Only Available", "Only available menu items will be displayed.\n" +
			"If disabled, all menu items will be displayed, menu items that can't be used will be inactive.", "")]
		[ORKEditorInfo(separator=true)]
		public bool onlyAvailable = true;
		
		// layout
		[ORKEditorInfo("Content Layout", "Define the layout of the buttons.", "", 
			endFoldout=true, separatorForce=true)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		// message
		[ORKEditorInfo("Message", "Define if and what message will be displayed in this sub menu.", "", 
			endFoldout=true)]
		public ChoiceMessage message = new ChoiceMessage();
		
		// items
		[ORKEditorArray(false, "Add Menu Item", "Adds a menu item to this sub menu.", "", 
			"Remove", "Removes this menu item.", "", noRemoveCount=1, isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {"Menu Item", "Define the action, key and button of this menu item.", ""})]
		public SubMenuItem[] item = new SubMenuItem[] {new SubMenuItem()};
		
		
		// ingame
		private GUIBox box;
		
		private ChoiceContent[] choice;
		
		private int[] action;
		
		private IShortcut shortcut;
		
		private BaseMenuPart parent;
		
		private int current = 0;
		
		public SubMenu()
		{
			
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		private void CreateChoices()
		{
			this.choice = null;
			this.action = null;
			
			List<ChoiceContent> cc = new List<ChoiceContent>();
			List<int> ca = new List<int>();
			
			for(int i=0; i<this.item.Length; i++)
			{
				ChoiceContent content = null;
				if(SubMenuAction.Use.Equals(this.item[i].type) && 
					(!this.onlyAvailable || this.shortcut.CanUse(this.parent.Screen.Combatant, false)))
				{
					if(this.shortcut is AbilityShortcut || 
						this.shortcut is ItemShortcut)
					{
						content = this.item[i].ownContent ? 
							this.contentLayout.GetChoiceContent(this.item[i].button) : 
							this.contentLayout.GetChoiceContent(ORK.MenuSettings.useButton);
						content.active = this.shortcut.CanUse(this.parent.Screen.Combatant, false);
					}
					else if(this.shortcut is EquipShortcut)
					{
						content = this.item[i].ownContent ? 
							this.contentLayout.GetChoiceContent(this.item[i].button) : 
							this.contentLayout.GetChoiceContent(ORK.MenuSettings.equipButton);
						content.active = this.shortcut.CanUse(this.parent.Screen.Combatant, false);
					}
					else if(!this.onlyAvailable)
					{
						content = this.item[i].ownContent ? 
							this.contentLayout.GetChoiceContent(this.item[i].button) : 
							this.contentLayout.GetChoiceContent(ORK.MenuSettings.useButton);
						content.active = false;
					}
				}
				else if(SubMenuAction.Give.Equals(this.item[i].type) && 
					(!this.onlyAvailable || ORK.InventorySettings.IsIndividual()))
				{
					content = this.item[i].ownContent ? 
						this.contentLayout.GetChoiceContent(this.item[i].button) : 
						this.contentLayout.GetChoiceContent(ORK.MenuSettings.giveButton);
					content.active = ORK.InventorySettings.IsIndividual();
				}
				else if(SubMenuAction.Remove.Equals(this.item[i].type) && 
					(!this.onlyAvailable || this.shortcut.IsDropable()))
				{
					content = this.item[i].ownContent ? 
						this.contentLayout.GetChoiceContent(this.item[i].button) : 
						this.contentLayout.GetChoiceContent(ORK.MenuSettings.removeButton);
					content.active = this.shortcut.IsDropable();
				}
				else if(SubMenuAction.Drop.Equals(this.item[i].type) && 
					(!this.onlyAvailable || this.shortcut.IsDropable()))
				{
					content = this.item[i].ownContent ? 
						this.contentLayout.GetChoiceContent(this.item[i].button) : 
						this.contentLayout.GetChoiceContent(ORK.MenuSettings.dropButton);
					content.active = this.shortcut.IsDropable();
				}
				else if(SubMenuAction.Back.Equals(this.item[i].type))
				{
					content = this.item[i].ownContent ? 
						this.contentLayout.GetChoiceContent(this.item[i].button) : 
						this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton);
				}
				else if(SubMenuAction.Cancel.Equals(this.item[i].type))
				{
					content = this.item[i].ownContent ? 
						this.contentLayout.GetChoiceContent(this.item[i].button) : 
						this.contentLayout.GetChoiceContent(ORK.MenuSettings.cancelButton);
				}
				else if(SubMenuAction.LevelUp.Equals(this.item[i].type))
				{
					content = this.item[i].ownContent ? 
						this.contentLayout.GetChoiceContent(this.item[i].button) : 
						this.contentLayout.GetChoiceContent(ORK.MenuSettings.levelUpButton);
					if(this.shortcut is AbilityShortcut)
					{
						content.active = ((AbilityShortcut)this.shortcut).CanLevelUpSpend(this.parent.Screen.Combatant);
					}
					else if(this.shortcut is EquipShortcut)
					{
						content.active = ((EquipShortcut)this.shortcut).CanLevelUpSpend(this.parent.Screen.Combatant);
					}
					else
					{
						content.active = false;
					}
				}
				
				if(content != null)
				{
					cc.Add(content);
					ca.Add(i);
				}
			}
			
			this.choice = cc.ToArray();
			this.action = ca.ToArray();
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public bool Show(IShortcut shortcut, BaseMenuPart parent)
		{
			this.shortcut = shortcut;
			this.parent = parent;
			this.current = 0;
			
			this.CreateChoices();
			if(this.choice != null && this.choice.Length > 0)
			{
				this.Show();
				return true;
			}
			else
			{
				return false;
			}
		}
		
		public void Show()
		{
			string tmpTitle = "";
			
			this.box = ORK.GUIBoxes.Create(this.guiBoxID);
			this.box.inPause = this.parent.Screen.pauseGame;
			this.box.Content = new DialogueContent(
				this.message.GetMessage(out tmpTitle, this.shortcut.GetName(), this.shortcut.GetDescription()), 
				tmpTitle, this.choice, this);
			this.box.InitIn();
			ORK.GUI.FocusBlocked = true;
		}

		public void FocusGained(GUIBox origin)
		{
			
		}

		public void FocusLost(GUIBox origin)
		{
			
		}

		public void Closed(GUIBox origin)
		{
			if(this.current >= 0 && this.current < this.action.Length && 
				this.item[this.action[this.current]].Use(this.shortcut, this.parent))
			{
				this.parent.SubMenuClosed(false);
			}
			else
			{
				this.parent.SubMenuClosed(true);
			}
			this.parent = null;
			this.shortcut = null;
			this.box = null;
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			this.current = index;
			this.box.InitOut();
		}

		public void SelectionChanged(int index, GUIBox origin)
		{
			this.current = index;
		}

		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.current = -1;
			this.box.InitOut();
		}
	}
}
