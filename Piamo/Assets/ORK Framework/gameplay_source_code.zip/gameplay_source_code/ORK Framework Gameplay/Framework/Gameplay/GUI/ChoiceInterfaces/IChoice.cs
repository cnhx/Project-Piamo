
namespace ORKFramework
{
	public interface IChoice : IChoiceSimple
	{
		bool ShowOKButton(GUIBox origin);
		
		bool ShowCancelButton(GUIBox origin);
		
		bool IsOKButtonActive(GUIBox origin);
		
		bool IsCancelButtonActive(GUIBox origin);
		
		bool Tick(GUIBox origin);
		
		void FocusGained(GUIBox origin);
		
		void FocusLost(GUIBox origin);
		
		void Closed(GUIBox origin);
		
		void ChoiceSelected(int index, GUIBox origin);
		
		void SelectionChanged(int index, GUIBox origin);
		
		void Canceled(GUIBox origin);
	}
}
