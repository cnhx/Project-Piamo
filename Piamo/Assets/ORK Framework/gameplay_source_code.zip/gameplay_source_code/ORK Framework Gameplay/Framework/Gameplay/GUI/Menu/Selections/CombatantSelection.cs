
using UnityEngine;
using System.Collections.Generic;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Menu.Parts;

namespace ORKFramework.Menu
{
	public class CombatantSelection : BaseIndexData, IChoice
	{
		[ORKEditorHelp("Name", "The name of this GUI box.", "")]
		[ORKEditorInfo("Base Settings", "Set the name and base settings of this combatant selection.", "", 
			expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("GUI Box", "The GUI box used to display the combatant coice.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		[ORKEditorHelp("Only Battle Group", "Only the battle group is available for selection.", "")]
		public bool onlyBattle = true;
		
		[ORKEditorHelp("Only Available", "Only valid targets are displayed.\n" +
			"If disabled, all group members are displayed, the buttons of those who can't be selected are inactive.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool onlyAvailable = false;
		
		
		// content
		[ORKEditorInfo("Content Settings", "Set the content of this combatant selection.", "", endFoldout=true)]
		public ChoiceMessage message = new ChoiceMessage();
		
		// own target choice layout
		[ORKEditorHelp("Own Layout", "Override the default combatant choice layout (Menu Settings).", "")]
		[ORKEditorInfo("Combatant Choice Layout", "A battle menu can override the " +
			"default default layout for combatant choices.", "")]
		public bool ownCombatantChoice = false;
		
		[ORKEditorInfo(endFoldout=true, separator=true)]
		[ORKEditorLayout("ownCombatantChoice", true, endCheckGroup=true, autoInit=true)]
		public CombatantChoiceLayout combatantChoice;
		
		
		// ingame
		private GUIBox box;
		
		private BaseMenuPart parent;
		
		private int current = -1;
		
		private string tmpTitle = "";
		
		
		// choice
		private List<Combatant> targets;
		
		private ChoiceContent[] choice;
		
		
		// menu item
		private MenuScreenItem menuItem;
		
		
		// shortcut
		private IShortcut shortcut;
		
		private QuantityCall giveCall;
		
		public CombatantSelection()
		{
			
		}
		
		public CombatantSelection(string name)
		{
			this.name = name;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public void Clear()
		{
			this.choice = null;
			this.tmpTitle = "";
			this.targets = null;
			this.menuItem = null;
			this.shortcut = null;
			this.giveCall = null;
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		public string Message
		{
			get
			{
				if(this.menuItem != null)
				{
					return this.message.GetMessage(out this.tmpTitle, 
						this.menuItem.button[ORK.Game.Language].GetName(), 
						this.menuItem.button[ORK.Game.Language].GetDescription());
				}
				else if(this.shortcut != null)
				{
					return this.message.GetMessage(out this.tmpTitle, 
						this.shortcut.GetName(), this.shortcut.GetDescription());
				}
				this.tmpTitle = "";
				return "";
			}
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(MenuScreenItem item, BaseMenuPart parent)
		{
			this.Clear();
			this.menuItem = item;
			this.parent = parent;
			
			this.targets = this.onlyBattle ? this.parent.Screen.Combatant.Group.GetBattle() : this.parent.Screen.Combatant.Group.GetGroup();
			this.Show();
		}
		
		public void Show(IShortcut shortcut, BaseMenuPart parent)
		{
			this.Clear();
			this.shortcut = shortcut;
			this.parent = parent;
			
			if(!this.shortcut.TargetEnemy())
			{
				this.targets = this.onlyAvailable ? 
					this.shortcut.GetPossibleTargets(this.parent.Screen.Combatant, 
						this.onlyBattle ? this.parent.Screen.Combatant.Group.GetBattle() : this.parent.Screen.Combatant.Group.GetGroup(), new List<Combatant>()) : 
					this.onlyBattle ? this.parent.Screen.Combatant.Group.GetBattle() : this.parent.Screen.Combatant.Group.GetGroup();
				
				if(this.targets.Count > 0)
				{
					this.Show();
				}
				else
				{
					this.Clear();
				}
			}
		}
		
		public void ShowGive(IShortcut shortcut, BaseMenuPart parent, QuantityCall giveCall)
		{
			this.Clear();
			this.shortcut = shortcut;
			this.parent = parent;
			this.giveCall = giveCall;
			
			if(!this.shortcut.TargetEnemy())
			{
				this.targets = new List<Combatant>(this.onlyBattle ? 
					this.parent.Screen.Combatant.Group.GetBattle() : 
					this.parent.Screen.Combatant.Group.GetGroup());
				this.targets.Remove(this.parent.Screen.Combatant);
				
				if(this.targets.Count > 0)
				{
					this.Show();
				}
				else
				{
					this.Clear();
				}
			}
		}
		
		public void Show()
		{
			this.CreateChoices();
			this.box = ORK.GUIBoxes.Create(this.guiBoxID);
			this.box.inPause = this.parent.Screen.pauseGame;
			this.box.Content = new DialogueContent(this.Message, this.tmpTitle, this.choice, this, 0, null, 
				this.ownCombatantChoice ? 
					this.combatantChoice.GetStatusElements() : 
					ORK.MenuSettings.combatantChoice.GetStatusElements());
			this.box.InitIn();
			ORK.GUI.FocusBlocked = true;
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		public void Closed(GUIBox origin)
		{
			ORK.GUI.FocusBlocked = false;
			if(this.current != -1)
			{
				// menu item > set screen combatant
				if(this.menuItem != null)
				{
					if(this.menuItem.screenID >= 0 && this.menuItem.screenID < ORK.MenuScreens.Count)
					{
						ORK.MenuScreens.Get(this.menuItem.screenID).Combatant = this.targets[this.current];
					}
				}
				// give item, equipment or money to other combatant
				else if(this.giveCall != null)
				{
					this.giveCall.Call(
						new QuantityData(null, this.shortcut, 
							this.targets[this.current].Inventory.GetAllowedQuantity(this.shortcut, -1), 
							this.targets[this.current].Inventory.GetCount(this.shortcut), 
							0, this.parent.Screen.Combatant.Inventory.GetMoney(0), this.shortcut.BuyPrice, 
							QuantitySelectionMode.Give, 
							this.targets[this.current].Inventory.Add, this.parent.Screen.Combatant.Inventory.Remove));
				}
				// use item, equipment or ability
				else if(this.shortcut != null)
				{
					if(this.shortcut.GroupTarget())
					{
						this.shortcut.Use(this.parent.Screen.Combatant, this.targets);
					}
					else
					{
						List<Combatant> tmp = new List<Combatant>();
						tmp.Add(this.targets[this.current]);
						this.shortcut.Use(this.parent.Screen.Combatant, tmp);
					}
				}
			}
			
			this.box = null;
			if(this.parent != null)
			{
				this.parent.CombatantChoiceClosed(this.current == -1);
			}
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void CreateChoices()
		{
			this.choice = null;
			
			if(this.targets != null && this.targets.Count > 0)
			{
				// menu item, give
				if(this.menuItem != null || this.giveCall != null)
				{
					this.choice = new ChoiceContent[this.targets.Count];
					for(int i=0; i<this.targets.Count; i++)
					{
						this.choice[i] = this.ownCombatantChoice ? 
							this.combatantChoice.GetChoiceContent(this.targets[i]) : 
							ORK.MenuSettings.combatantChoice.GetChoiceContent(this.targets[i]);
						
						if(this.giveCall != null)
						{
							this.choice[i].active = this.targets[i].Inventory.GetAllowedCount(this.shortcut) != 0;
						}
					}
				}
				// shortcut
				else if(this.shortcut != null)
				{
					if(this.shortcut.GroupTarget())
					{
						this.choice = new ChoiceContent[] {
							ORK.BattleTexts.GetAllCombatantsContent(
								TargetType.Ally, 
								this.ownCombatantChoice ? 
									this.combatantChoice.contentLayout : 
									ORK.MenuSettings.combatantChoice.contentLayout)
						};
					}
					else
					{
						this.choice = new ChoiceContent[this.targets.Count];
						for(int i=0; i<this.targets.Count; i++)
						{
							this.choice[i] = this.ownCombatantChoice ? 
								this.combatantChoice.GetChoiceContent(this.targets[i]) : 
								ORK.MenuSettings.combatantChoice.GetChoiceContent(this.targets[i]);
							
							if(!this.onlyAvailable)
							{
								this.choice[i].active = this.shortcut.CanTarget(this.parent.Screen.Combatant, this.targets[i]);
							}
						}
					}
				}
			}
		}
		
		public void ChoiceSelected(int index, GUIBox origin)
		{
			this.current = index;
			this.box.InitOut();
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.current = -1;
			this.box.InitOut();
		}
	}
}
