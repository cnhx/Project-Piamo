
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Display
{
	public class DisplayImage : BaseData
	{
		[ORKEditorHelp("Image Bounds", "The position (X, Y) and size (W, H) used to display the image.", "")]
		public Rect bounds = new Rect(0, 0, 1280, 800);
		
		public BaseImage image = new BaseImage();
		
		public DisplayImage()
		{
			
		}
		
		public void Show()
		{
			this.image.Show(this.bounds);
		}
		
		public void Show(float x, float y)
		{
			this.image.Show(new Rect(this.bounds.x + x, this.bounds.y + y, this.bounds.width, this.bounds.height));
		}
	}
}
