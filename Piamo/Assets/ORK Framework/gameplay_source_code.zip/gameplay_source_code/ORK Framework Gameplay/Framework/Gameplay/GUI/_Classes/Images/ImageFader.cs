
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ImageFader
	{
		private int layer = 0;
		
		private int id = 0;
		
		private BaseImage image;
		
		
		// position
		private Rect bounds;
		
		private Rect boundsDistance;
		
		private Rect boundsStart;
		
		private bool isFadingPosition = false;
		
		private float timePosition = 0;
		
		private float timePosition2 = 0;
		
		private Function interpolation;
		
		
		// color
		private Color color = new Color(1, 1, 1, 1);
		
		private Color colorStart = new Color(1, 1, 1, 1);
		
		private FadeColorSettings fadeColorSettings;
		
		private bool isFadingColor = false;
		
		private float timeColor = 0;
		
		public ImageFader(int layer, int id, BaseImage image, Rect bounds, Color color)
		{
			this.layer = layer;
			this.id = id;
			this.image = image;
			this.bounds = bounds;
			this.color = color;
			
			ORK.GUI.AddImage(this.layer, this.id, this);
		}
		
		public int Layer
		{
			get{ return this.layer;}
		}
		
		public int ID
		{
			get{ return this.id;}
		}
		
		
		/*
		============================================================================
		Position functions
		============================================================================
		*/
		public void SetPosition(Rect bounds)
		{
			this.bounds = bounds;
			this.isFadingPosition = false;
		}
		
		public void FadeToPosition(Rect targetBounds, EaseType easeType, float time)
		{
			this.boundsStart = this.bounds;
			this.interpolation = Interpolate.Ease(easeType);
			
			this.boundsDistance = new Rect(
				targetBounds.x - this.bounds.x, 
				targetBounds.y - this.bounds.y, 
				targetBounds.width - this.bounds.width, 
				targetBounds.height - this.bounds.height);
			
			this.timePosition = 0;
			this.timePosition2 = time;
			this.isFadingPosition = true;
		}
		
		
		/*
		============================================================================
		Color functions
		============================================================================
		*/
		public void SetColor(Color color)
		{
			this.color = color;
			this.isFadingColor = false;
		}
		
		public void FadeToColor(FadeColorSettings fadeColorSettings)
		{
			this.fadeColorSettings = fadeColorSettings;
			this.colorStart = this.color;
			this.fadeColorSettings.GetStart(ref this.colorStart);
			this.color = this.colorStart;
			this.timeColor = 0;
			this.isFadingColor = true;
		}
		
		
		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public void Tick(float t)
		{
			if(this.isFadingColor)
			{
				this.timeColor += t;
				if(this.fadeColorSettings.Fade(ref this.color, this.colorStart, this.timeColor))
				{
					this.isFadingColor = false;
				}
			}
			if(this.isFadingPosition)
			{
				this.timePosition += t;
				if(this.boundsDistance.x != 0)
				{
					this.bounds.x = Interpolate.Ease(this.interpolation, 
						this.boundsStart.x, this.boundsDistance.x, 
						this.timePosition, this.timePosition2);
				}
				if(this.boundsDistance.y != 0)
				{
					this.bounds.y = Interpolate.Ease(this.interpolation, 
						this.boundsStart.y, this.boundsDistance.y, 
						this.timePosition, this.timePosition2);
				}
				if(this.boundsDistance.width != 0)
				{
					this.bounds.width = Interpolate.Ease(this.interpolation, 
						this.boundsStart.width, this.boundsDistance.width, 
						this.timePosition, this.timePosition2);
				}
				if(this.boundsDistance.height != 0)
				{
					this.bounds.height = Interpolate.Ease(this.interpolation, 
						this.boundsStart.height, this.boundsDistance.height, 
						this.timePosition, this.timePosition2);
				}
				if(this.timePosition >= this.timePosition2)
				{
					this.isFadingPosition = false;
				}
			}
		}
		
		
		/*
		============================================================================
		GUI functions
		============================================================================
		*/
		public void ShowGUI()
		{
			if(this.image != null)
			{
				// set color
				Color c = GUI.color;
				GUI.color = this.color;
				
				// show image
				this.image.Show(this.bounds);
				
				// reset
				GUI.color = c;
			}
		}
	}
}
