
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Formulas
{
	public class FormulaFloat : BaseData
	{
		[ORKEditorHelp("Value Type", "Select which kind of value will be used:\n" +
			"- Value: A defined value.\n" +
			"- Game Variable: The value of a game variable (float).\n" +
			"- Player Prefs: The value of a PlayerPrefs (int or float) variable.\n" +
			"- Formula: The result of a formula (using this formula's user and target).\n" +
			"- Game Time: The current game time in seconds (time since 'New Game').\n" +
			"- Time Of Day: The current real time since midnight in seconds.\n" +
			"- Date And Time: The current real date and time in seconds (since 1-1-1970).", "")]
		public NumberValueType type = NumberValueType.Value;
		
		
		// variable and player prefs
		[ORKEditorHelp("Variable Key", "The key (name) of the game variable (float) or PlayerPrefs that contains the value.", "")]
		[ORKEditorInfo(expandWidth=true, isVariableField=true)]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {NumberValueType.GameVariable, NumberValueType.PlayerPrefs}, 
			needed=Needed.One, endCheckGroup=true)]
		public string name = "";
		
		[ORKEditorHelp("Is Int", "The value will be taken from an Integer PlayerPrefs (using GetInt).\n" +
			"If disabled, the value will be taken from a Float PlayerPrefs (using GetFloat).", "")]
		[ORKEditorLayout("type", NumberValueType.PlayerPrefs, endCheckGroup=true)]
		public bool isInt = false;
		
		// object variables
		[ORKEditorHelp("Use Object Variable", "Use an object variable of a combatant.\n" +
			"The combatant's game object must have an 'Object Variables' component attached, " +
			"else the value will be 0.", "")]
		[ORKEditorLayout("type", NumberValueType.GameVariable)]
		public bool useObjectVariable = false;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("useObjectVariable", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public FormulaStatusOrigin origin;
		
		
		// formula
		[ORKEditorHelp("Formula", "Select the formula used for calculation.", "")]
		[ORKEditorInfo(ORKDataType.Formula)]
		[ORKEditorLayout("type", NumberValueType.Formula)]
		public int id = 0;
		
		[ORKEditorHelp("Initial Value", "The initial value passed to the formula.\n" +
			"The formula will use the initial value as it's base and start the calculation with that value.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float initialValue = 0;
		
		
		// game time offset
		[ORKEditorHelp("Time Offset (s)", "The offset time in seconds that will be added to the current game time.", "")]
		[ORKEditorLayout(new string[] {"type", "type", "type"}, 
			new System.Object[] {NumberValueType.GameTime, NumberValueType.TimeOfDay, NumberValueType.DateAndTime}, 
			needed=Needed.One, endCheckGroup=true)]
		public float offset = 0;
		
		[ORKEditorHelp("Is UTC", "The date and time are in UTC format.\n" +
			"If disabled, the local date and time is used.", "")]
		[ORKEditorLayout("type", NumberValueType.DateAndTime, endCheckGroup=true)]
		public bool isUTC = false;
		
		
		// value
		[ORKEditorHelp("Value", "Define the value that will be used.", "")]
		[ORKEditorLayout("type", NumberValueType.Value, endCheckGroup=true)]
		public float value = 0;
		
		public FormulaFloat()
		{
			
		}
		
		
		/*
		============================================================================
		Value functions
		============================================================================
		*/
		public float GetValue(Combatant user, Combatant target)
		{
			if(NumberValueType.Value.Equals(this.type))
			{
				return this.value;
			}
			else if(NumberValueType.GameVariable.Equals(this.type))
			{
				if(this.useObjectVariable)
				{
					Combatant combatant = this.origin.GetCombatant(user, target);
					if(combatant != null && combatant.GameObject != null)
					{
						ObjectVariablesComponent comp = ComponentHelper.
							GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
						if(comp != null)
						{
							return comp.GetHandler().GetFloat(this.name);
						}
					}
				}
				else
				{
					return ORK.Game.Variables.GetFloat(this.name);
				}
			}
			else if(NumberValueType.PlayerPrefs.Equals(this.type))
			{
				if(this.isInt)
				{
					return PlayerPrefs.GetInt(this.name);
				}
				else
				{
					return PlayerPrefs.GetFloat(this.name);
				}
			}
			else if(NumberValueType.Formula.Equals(this.type))
			{
				return ORK.Formulas.Get(this.id).Calculate(this.initialValue, user, target);
			}
			else if(NumberValueType.GameTime.Equals(this.type))
			{
				return ORK.Game.GameTime + this.offset;
			}
			else if(NumberValueType.TimeOfDay.Equals(this.type))
			{
				return (float)(System.DateTime.Now.TimeOfDay.TotalSeconds) + this.offset;
			}
			else if(NumberValueType.DateAndTime.Equals(this.type))
			{
				return (float)((System.DateTime.Now - new System.DateTime(1970, 1, 1, 0, 0, 0)).TotalSeconds) + 
					this.offset;
			}
			return 0;
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(NumberValueType.Value.Equals(this.type))
			{
				return this.value.ToString();
			}
			else if(NumberValueType.Formula.Equals(this.type))
			{
				return ORK.Formulas.GetName(this.id);
			}
			else if(NumberValueType.GameTime.Equals(this.type))
			{
				return "Game time + " + this.offset;
			}
			else if(NumberValueType.TimeOfDay.Equals(this.type))
			{
				return "Real time since midnight + " + this.offset;
			}
			else if(NumberValueType.DateAndTime.Equals(this.type))
			{
				return "Real date/time + " + this.offset;
			}
			else
			{
				return this.name;
			}
		}
	}
}
