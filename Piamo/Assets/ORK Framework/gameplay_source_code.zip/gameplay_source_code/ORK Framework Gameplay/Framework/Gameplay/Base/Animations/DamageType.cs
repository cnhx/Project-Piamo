
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DamageType : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of this damage type.", "")]
		[ORKEditorInfo("Base Settings", "Set the name and animation types of this damage type.", "", 
			expandWidth=true)]
		public string name = "";
		
		
		// animation types
		[ORKEditorHelp("Damage", "Select the animation type used for the damage animation " +
			"(i.e. when the combatant takes damage).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType, separator=true, labelText="Animation Types")]
		public int damageAnimationTypeID = 0;
		
		[ORKEditorHelp("Critical Damage", "Select the animation type used for the critical damage animation " +
			"(i.e. when the combatant takes critical damage).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int criticalDamageAnimationTypeID = 0;
		
		[ORKEditorHelp("Evade", "Select the animation type used for the evade animation " +
			"(i.e. when the combatant evades an attack).", "")]
		[ORKEditorInfo(ORKDataType.AnimationType, endFoldout=true)]
		public int evadeAnimationTypeID = 0;

		public DamageType()
		{
			
		}
		
		public DamageType(string name)
		{
			this.name = name;
		}
		
		public DamageType(string name, int damageID, int criticalID, int evadeID)
		{
			this.name = name;
			this.damageAnimationTypeID = damageID;
			this.criticalDamageAnimationTypeID = criticalID;
			this.evadeAnimationTypeID = evadeID;
		}
	}
}
