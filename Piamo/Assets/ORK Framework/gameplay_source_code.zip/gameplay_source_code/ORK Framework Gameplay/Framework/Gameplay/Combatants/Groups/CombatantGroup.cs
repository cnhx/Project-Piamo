
namespace ORKFramework
{
	public class CombatantGroup : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the group.", "")]
		[ORKEditorInfo("Group Settings", "Set the name and base settings of this combatant group.", "", 
			expandWidth=true, endFoldout=true)]
		public string name = "";
		
		[ORKEditorInfo("Combatants", "Define the combatants that will be part of this group.\n" +
			"The first combatant in the list will be the group leader.", "", endFoldout=true)]
		[ORKEditorArray(false, "Add Combatant", "Adds a combatant to this group.", "", 
			"Remove", "Removes the combatant from the group.", "", noRemoveCount=1, isCopy=true, isMove=true, 
			removeType=ORKDataType.Combatant, removeCheckField="id", 
			foldout=true, foldoutText=new string[] {
				"Combatant", "Define the combatant that will be part of this group.", ""
		})]
		public CombatantGroupMember[] member = new CombatantGroupMember[1] {new CombatantGroupMember()};
		
		
		
		// additional gains
		[ORKEditorHelp("Money", "Money added to the victory gains if the whole group has been defeated.", "")]
		[ORKEditorInfo("Group Battle Gains", "A combatant group can have additional " +
			"victory gains beside the individual combatant's loot.", "")]
		[ORKEditorArray(ORKDataType.Currency)]
		[ORKEditorLimit(0, false)]
		public int[] money = new int[ORK.Currencies.Count];
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Item Gain", "Adds an item to this groups victory gains.\n" +
			"The items are added to the victory gains if the whole group has been defeated.", "", 
			"Remove", "Removes the item from this groups victory gains.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Item", "Define the item, equipment or money, quantity and chance.", ""
		})]
		public ItemGain[] itemDrop = new ItemGain[0];
		
		public CombatantGroup()
		{
			
		}
		
		public CombatantGroup(string n)
		{
			this.name = n;
		}
		
		
		/*
		============================================================================
		Group functions
		============================================================================
		*/
		public Group CreateGroup(int factionID)
		{
			Group group = new Group(factionID);
			this.Join(group);
			return group;
		}
		
		public void Join(Group group)
		{
			for(int i=0; i<this.member.Length; i++)
			{
				this.member[i].Create(group);
			}
			for(int i=0; i<this.money.Length; i++)
			{
				if(this.money[i] > 0)
				{
					group.Inventory.AddMoney(i, this.money[i], false, false);
				}
			}
			
			for(int i=0; i<this.itemDrop.Length; i++)
			{
				if(this.itemDrop[i].CheckChance())
				{
					group.Loot.Add(this.itemDrop[i].CreateShortcut());
				}
			}
		}
	}
}
