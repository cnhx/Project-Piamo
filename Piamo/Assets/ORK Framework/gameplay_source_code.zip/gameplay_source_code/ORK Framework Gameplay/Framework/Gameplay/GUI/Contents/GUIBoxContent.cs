
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public abstract class GUIBoxContent
	{
		public GUIBox box;
		
		public Rect windowRect = new Rect(0, 0, 100, 100);
		
		public IChoice controlInterface;
		
		
		// content
		public bool newContent = true;
		
		protected int selection = 0;
		
		
		// name
		protected string name = "";
		
		protected bool calcName = false;
		
		protected MultiContent nameContent;
		
		
		// ok/cancel buttons
		protected GUIBoxButtons okCancelSettings;
		
		protected ChoiceContent ok;
		
		protected ChoiceContent cancel;
		
		
		/*
		============================================================================
		Functions
		============================================================================
		*/
		public virtual void Clear()
		{
			
		}
		
		public abstract void Tick();
		
		public abstract void Closed();
		
		public abstract void Init(GUIBox box);
		
		public abstract void ShowBefore();
		
		public abstract void ShowAfter();
		
		public abstract void ShowWindow();
		
		public virtual void SetTabs(ChoiceContent[] tabs)
		{
			
		}
		
		
		/*
		============================================================================
		OK/cancel functions
		============================================================================
		*/
		public virtual void OkPressed()
		{
			
		}
		
		public virtual void CancelPressed()
		{
			
		}
		
		protected void CalculateButtons()
		{
			if(this.controlInterface != null && this.box != null)
			{
				this.okCancelSettings = this.box.Settings.ownButtons ? this.box.Settings.buttons : ORK.MenuSettings.okCancel;
				
				if(this.okCancelSettings.useOk && this.controlInterface.ShowOKButton(this.box))
				{
					GUIStyle textStyle = new GUIStyle(GUI.skin.label);
					textStyle.wordWrap = false;
					this.ok = this.okCancelSettings.ok.GetButton(textStyle, this.box.bounds);
				}
				if(this.okCancelSettings.useCancel && this.controlInterface.ShowCancelButton(this.box))
				{
					GUIStyle textStyle = new GUIStyle(GUI.skin.label);
					textStyle.wordWrap = false;
					this.cancel = this.okCancelSettings.cancel.GetButton(textStyle, this.box.bounds);
				}
			}
		}
		
		public void ShowButtons()
		{
			if(this.controlInterface != null && this.box != null)
			{
				if(this.box.Skins.okSkin && 
					((this.ok != null && this.ok.isButton) || 
					(this.cancel != null && this.cancel.isButton)))
				{
					GUI.skin = this.box.Skins.okSkin;
				}
				
				// ok button
				if(this.ok != null)
				{
					this.ok.active = this.controlInterface.IsOKButtonActive(this.box);
					
					if(!this.ok.active && GUI.color.a > this.okCancelSettings.inactiveAlpha)
					{
						Color c = GUI.color;
						c.a = this.okCancelSettings.inactiveAlpha;
						GUI.color = c;
					}
					
					this.ok.buttonBounds.x += this.windowRect.x;
					this.ok.buttonBounds.y += this.windowRect.y;
					
					if(this.ok.isButton)
					{
						if(this.box.Button(this.ok.buttonBounds, this.okCancelSettings.ok.settings.showButton) && 
							(this.box.inPause || !ORK.Game.Paused))
						{
							if(this.ok.active)
							{
								this.OkPressed();
							}
							else
							{
								this.box.Audio.PlayFail();
							}
						}
					}
					
					GUI.BeginGroup(this.ok.buttonBounds);
					
					GUIStyle textStyle = new GUIStyle(GUI.skin.label);
					textStyle.wordWrap = false;
					
					// content
					if(!this.box.Settings.buttonSettings.alignIcons && this.ok.Content.image != null)
					{
						textStyle.alignment = TextAnchor.MiddleLeft;
						GUI.Label(this.ok.cImgBounds, new GUIContent(this.ok.Content.image), textStyle);
						textStyle.alignment = TextAnchor.UpperLeft;
					}
					if(this.ok.contentLabel != null && this.ok.contentLabel.label.Count > 0)
					{
						for(int j=0; j<this.ok.contentLabel.label.Count; j++)
						{
							this.ok.contentLabel.label[j].Show(textStyle);
						}
					}
					GUI.EndGroup();
					
					this.ok.buttonBounds.x -= this.windowRect.x;
					this.ok.buttonBounds.y -= this.windowRect.y;
					
					// reset alpha
					GUI.color = this.box.color;
				}
				// cancel button
				if(this.cancel != null)
				{
					this.cancel.active = this.controlInterface.IsCancelButtonActive(this.box);
					
					if(!this.cancel.active && GUI.color.a > this.okCancelSettings.inactiveAlpha)
					{
						Color c = GUI.color;
						c.a = this.okCancelSettings.inactiveAlpha;
						GUI.color = c;
					}
					
					this.cancel.buttonBounds.x += this.windowRect.x;
					this.cancel.buttonBounds.y += this.windowRect.y;
					
					if(this.cancel.isButton)
					{
						if(this.box.Button(this.cancel.buttonBounds, this.okCancelSettings.cancel.settings.showButton) && 
							(this.box.inPause || !ORK.Game.Paused))
						{
							if(this.cancel.active)
							{
								this.CancelPressed();
							}
							else
							{
								this.box.Audio.PlayFail();
							}
						}
					}
					
					GUI.BeginGroup(this.cancel.buttonBounds);
					
					GUIStyle textStyle = new GUIStyle(GUI.skin.label);
					textStyle.wordWrap = false;
					
					// content
					if(!this.box.Settings.buttonSettings.alignIcons && this.cancel.Content.image != null)
					{
						textStyle.alignment = TextAnchor.MiddleLeft;
						GUI.Label(this.cancel.cImgBounds, new GUIContent(this.cancel.Content.image), textStyle);
						textStyle.alignment = TextAnchor.UpperLeft;
					}
					if(this.cancel.contentLabel != null && this.cancel.contentLabel.label.Count > 0)
					{
						for(int j=0; j<this.cancel.contentLabel.label.Count; j++)
						{
							this.cancel.contentLabel.label[j].Show(textStyle);
						}
					}
					GUI.EndGroup();
					
					this.cancel.buttonBounds.x -= this.windowRect.x;
					this.cancel.buttonBounds.y -= this.windowRect.y;
					
					// reset alpha
					GUI.color = this.box.color;
				}
				
				if(this.box.Skins.skin)
				{
					GUI.skin = this.box.Skins.skin;
				}
			}
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		protected void DrawChoiceIcon(Rect choiceRect)
		{
			if(this.box != null)
			{
				this.box.ChoiceIcon.Show(choiceRect);
			}
		}
		
		public virtual int Selection
		{
			get{ return this.selection;}
			set{ this.selection = value;}
		}
		
		public virtual void ShowSelectionIcon()
		{
			
		}
		
		
		/*
		============================================================================
		Focus functions
		============================================================================
		*/
		public void FocusGained()
		{
			if(this.controlInterface != null && this.box != null)
			{
				this.controlInterface.FocusGained(this.box);
			}
		}
		
		public void FocusLost()
		{
			if(this.controlInterface != null && this.box != null)
			{
				this.controlInterface.FocusLost(this.box);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public void SetName(string newName)
		{
			if(this.name != newName)
			{
				this.name = newName;
				this.calcName = true;
			}
		}
		
		public void ShowName()
		{
			if(this.box != null && this.name != "")
			{
				if(this.box.Skins.nameSkin)
				{
					GUI.skin = this.box.Skins.nameSkin;
				}
				
				GUIStyle textStyle = new GUIStyle(GUI.skin.label);
				textStyle.wordWrap = false;
				
				// calculate new name
				if(this.calcName)
				{
					// set text style
					textStyle.fontSize = this.box.Settings.nameTextFormat.fontSize;
					textStyle.fontStyle = this.box.Settings.nameTextFormat.fontStyle;
					
					this.box.nameBounds = this.box.Settings.nameBounds;
					if(this.box.Settings.nameRelative)
					{
						Vector2 tmp = GUIHelper.GetRectAnchor(this.box.bounds, this.box.Settings.nameRelativeTo);
						this.box.nameBounds.x += tmp.x;
						this.box.nameBounds.y += tmp.y;
					}
					Vector2 size = textStyle.CalcSize(new GUIContent(this.name));
					
					Rect bounds = new Rect(this.box.Settings.namePadding.x, this.box.Settings.namePadding.y, 
						this.box.Settings.nameAdjWidth ? size.x : this.box.Settings.nameBounds.width, 
						this.box.Settings.nameAdjHeight ? size.y : this.box.Settings.nameBounds.height);
					this.box.nameOffset.x = this.box.nameBounds.x - this.box.bounds.x;
					this.box.nameOffset.y = this.box.nameBounds.y - this.box.bounds.y;
					
					this.nameContent = new MultiContent(this.name, null, null, textStyle, bounds, 
						this.box.Settings.nameLineSpacing, this.box.Settings.alignmentName, this.box.Settings.vAlignmentName, 
						BoxHeightAdjustment.Auto, false, this.box.Settings.nameTextFormat);
					
					if(!this.box.forceSize)
					{
						if(this.box.Settings.nameAdjWidth)
						{
							this.box.nameBounds.width = bounds.width + this.box.Settings.namePadding.x + this.box.Settings.namePadding.z;
						}
						if(this.box.Settings.nameAdjHeight)
						{
							this.box.nameBounds.height = bounds.height + this.box.Settings.namePadding.y + this.box.Settings.namePadding.w;
						}
					}
					
					this.calcName = false;
				}
				
				GUIHelper.GetRectAnchor(ref this.box.nameBounds, -this.box.nameBounds.width, -this.box.nameBounds.height, this.box.Settings.nameAnchor);
				
				if(this.box.Settings.showNameBox)
				{
					GUI.Box(this.box.nameBounds, "");
				}
				
				GUI.BeginGroup(this.box.nameBounds);
				
				for(int i=0; i<this.nameContent.label.Count; i++)
				{
					this.nameContent.label[i].Show(textStyle);
				}
				
				GUI.EndGroup();
				
				
				if(this.box.Skins.skin)
				{
					GUI.skin = this.box.Skins.skin;
				}
			}
		}
		
		
		/*
		============================================================================
		Drag and drop functions
		============================================================================
		*/
		public bool CheckDragWindow(Vector2 position)
		{
			if(this.box != null && this.box.Settings.dragable && 
				this.box.Focused && GUIHelper.InGUIRect(position, this.windowRect))
			{
				position.x -= this.windowRect.x;
				position.y -= this.windowRect.y;
				return GUIHelper.InGUIRect(position, this.box.Settings.dragBounds);
			}
			return false;
		}
		
		public virtual ChoiceContent GetDragOnPosition(Vector2 position)
		{
			return null;
		}
		
		public virtual bool CheckDrop(DragInfo drag, Vector2 position)
		{
			return this.box != null && this.controlInterface != null && 
				GUIHelper.InGUIRect(position, this.windowRect);
		}
		
		public virtual IContent GetTooltip(Vector2 position)
		{
			return null;
		}
		
		public virtual void MouseOverSelection(Vector2 position)
		{
			
		}
	}
}
