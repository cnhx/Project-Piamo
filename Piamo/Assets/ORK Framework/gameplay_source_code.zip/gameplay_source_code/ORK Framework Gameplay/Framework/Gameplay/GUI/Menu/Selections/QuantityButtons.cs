
using UnityEngine;
using ORKFramework;

namespace ORKFramework.Menu
{
	public class QuantityButtons : BaseData
	{
		[ORKEditorHelp("Change", "Define by which amount the quantity will change when using this buttons.", "")]
		public int change = 1;
		
		[ORKEditorHelp("Loop", "The quantity will loop when reaching the ends (i.e. 1 or the maximum).", "")]
		public bool loop = false;
		
		[ORKEditorHelp("Hide Buttons", "The buttons are not displayed, " +
			"but you can still change the quantity using the input keys.", "")]
		public bool hideButtons = false;
		
		[ORKEditorHelp("As Buttons", "The increase/decrease buttons are displayed using buttons.\n" +
			"If disabled, the increase/decrease buttons are displayed as labels.", "")]
		[ORKEditorLayout("hideButtons", false)]
		public bool isButton = true;
		
		[ORKEditorInfo(separator=true, labelText="Increase Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		public LanguageContent[] increase = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"+"});
		
		[ORKEditorInfo(separator=true, labelText="Decrease Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public LanguageContent[] decrease = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"-"});
		
		public QuantityButtons()
		{
			
		}
	}
}
