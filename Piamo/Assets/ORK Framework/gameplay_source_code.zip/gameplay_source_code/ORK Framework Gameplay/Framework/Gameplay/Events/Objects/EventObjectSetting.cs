
using ORKFramework;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class EventObjectSetting : BaseData
	{
		[ORKEditorHelp("Object", "Select the type of object that will be used:\n" +
			"- Actor: An actor will be used.\n" +
			"- Waypoint: A waypoint will be used.\n" +
			"- Prefab: A prefab spawned by the event will be used.\n" +
			"- Found Objects: Objects found by the 'Search Objects' step.", "")]
		public StepObjectType type = StepObjectType.Actor;
		
		[ORKEditorHelp("Actor", "Select the actor that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("type", StepObjectType.Actor, endCheckGroup=true)]
		public int aID = 0;
		
		[ORKEditorHelp("Waypoint", "Select the waypoint that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=1)]
		[ORKEditorLayout("type", StepObjectType.Waypoint, endCheckGroup=true)]
		public int wID = 0;
		
		[ORKEditorHelp("Prefab", "Select the prefab that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=2)]
		[ORKEditorLayout("type", StepObjectType.Prefab)]
		public int pID = 0;
		
		[ORKEditorHelp("Spawned Prefab ID", "Set the id of the spawned prefab.\n" +
			"Each prefab keeps track of it's spawned instances - " +
			"the first spawned instance will have ID 0, the second ID 1, etc.\n" +
			"Use -1 for all spawned instances of the selected prefab.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorLimit(-1, false)]
		public int pID2 = -1;
		
		
		// child object
		[ORKEditorHelp("Child Object", "A child object of the selected object will be used (e.g. Path/to/Child).\n" +
			"Leave empty if you don't want to use a child object.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string childName = "";
		
		public EventObjectSetting()
		{
			
		}
		
		public List<GameObject> GetObject(BaseEvent baseEvent)
		{
			List<GameObject> list = null;
			if(StepObjectType.Actor.Equals(this.type))
			{
				list = ArrayHelper.RemoveAllNull(baseEvent.GetActorObject(this.aID));
			}
			else if(StepObjectType.Waypoint.Equals(this.type))
			{
				list = ArrayHelper.RemoveAllNull(baseEvent.GetWaypoint(this.wID));
			}
			else if(StepObjectType.Prefab.Equals(this.type))
			{
				list = ArrayHelper.RemoveAllNull(baseEvent.GetSpawnedPrefab(this.pID, pID2));
			}
			else if(StepObjectType.FoundObjects.Equals(this.type))
			{
				list = ArrayHelper.RemoveAllNull(baseEvent.GetFoundObjects());
			}
			
			if(list == null)
			{
				list = new List<GameObject>();
			}
			
			if(this.childName != "")
			{
				for(int i=0; i<list.Count; i++)
				{
					list[i] = TransformHelper.GetChildObject(this.childName, list[i]);
				}
			}
			
			return list;
		}
	}
}
