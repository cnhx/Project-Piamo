
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class CheckGameVariable : CheckVariableBase
	{
		[ORKEditorInfo(labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		public CheckGameVariable()
		{
			
		}
		
		public bool Check(VariableHandler handler)
		{
			return base.Check(this.key.GetValue(), handler);
		}
	}
}
