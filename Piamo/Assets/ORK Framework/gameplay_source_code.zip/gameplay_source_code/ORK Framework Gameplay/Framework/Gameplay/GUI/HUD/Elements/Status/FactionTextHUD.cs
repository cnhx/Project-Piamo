
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class FactionTextHUD : BaseData
	{
		[ORKEditorHelp("Faction Benefit", "Display name and description of the current faction benefit.\n" +
			"If disabled, name and description of the faction are displayed.", "")]
		public bool factBen = false;
		
		[ORKEditorInfo(separator=true, label=new string[] {"%n = name, %d = description, %i = icon, % = sympathy value"})]
		public StatusTextHUD text = new StatusTextHUD();
		
		public FactionTextHUD()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, GUIStyle textStyle, Combatant combatant, Rect bounds)
		{
			label = null;
			int id = combatant.Group.FactionID;
			
			if(this.factBen)
			{
				id = ORK.Game.Faction.GetCurrentBenefit(id, ORK.Game.ActiveGroup.FactionID);
				if(id >= 0)
				{
					label = new MultiContent(
						TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
							Replace("%n", ORK.FactionBenefits.GetName(id)).
							Replace("%d", ORK.FactionBenefits.GetDescription(id)).
							Replace("%i", TextCode.FactionBenefitIcon + id + "#").
							Replace("%", ORK.Game.Faction.GetSympathy(id, ORK.Game.ActiveGroup.FactionID).ToString())), 
						null, null, textStyle, bounds, 
						this.text.lineSpacing, this.text.alignment, this.text.vAlignment, 
						BoxHeightAdjustment.Auto, false, this.text.textFormat).label;
				}
			}
			else
			{
				label = new MultiContent(
					TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%n", ORK.Factions.GetName(id)).
						Replace("%d", ORK.Factions.GetDescription(id)).
						Replace("%i", TextCode.FactionIcon + id + "#").
						Replace("%", ORK.Game.Faction.GetSympathy(id, ORK.Game.ActiveGroup.FactionID).ToString())), 
					null, null, textStyle, bounds, 
					this.text.lineSpacing, this.text.alignment, this.text.vAlignment, 
					BoxHeightAdjustment.Auto, false, this.text.textFormat).label;
			}
		}
	}
}
