
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class NavigationHUDContent : GUIBoxContent
	{
		private HUDSetting hudSetting;
		
		public List<KeyValuePair<Vector2, MultiNavigationHUDContent>> content;
		
		
		// scroll
		private Vector2 scroll = Vector2.zero;
		
		private Rect contentBounds;
		
		private Rect scrollRect;
		
		public NavigationHUDContent(HUDSetting setting)
		{
			this.hudSetting = setting;
		}

		public override void Tick()
		{
			if(this.box != null)
			{
				this.newContent = true;
				
				// interface tick
				if(this.box.Controlable && this.controlInterface != null && this.box.Focused)
				{
					this.controlInterface.Tick(this.box);
				}
			}
		}
		
		public override void Closed()
		{
			if(this.controlInterface != null)
			{
				this.controlInterface.Closed(this.box);
			}
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public override void Init(GUIBox box)
		{
			if(this.newContent || this.box == null)
			{
				this.box = box;
				this.newContent = false;
				
				this.CalculateContent(this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), false);
			}
		}
		
		private void CalculateContent(float baseWidth, bool recalced)
		{
			this.content = new List<KeyValuePair<Vector2, MultiNavigationHUDContent>>();
			
			GUIStyle textStyle = new GUIStyle(GUI.skin.label);
			textStyle.wordWrap = false;
			
			float contentHeight = 0;
			
			if(this.hudSetting.navigationElement != null && 
				ORK.Game.ActiveGroup.Leader != null && 
				ORK.Game.ActiveGroup.Leader.GameObject != null)
			{
				Transform transform = null;
				float forwardAngle = this.hudSetting.navForwardOffset;
				float rightEnd = this.hudSetting.navDisplayRange / 2;
				float leftEnd = -rightEnd;
				
				if(this.hudSetting.navFromPlayer)
				{
					forwardAngle += ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles.y;
					transform = ORK.Game.ActiveGroup.Leader.GameObject.transform;
				}
				else if(Camera.main != null)
				{
					forwardAngle += Camera.main.transform.eulerAngles.y;
					transform = Camera.main.transform;
				}
				rightEnd += forwardAngle;
				leftEnd += forwardAngle;
				
				float halfWidth = baseWidth / 2;
				float degreeWidth = baseWidth / this.hudSetting.navDisplayRange;
				
				for(int i=0; i<this.hudSetting.navigationElement.Length; i++)
				{
					this.hudSetting.navigationElement[i].Create(
						ref this.content, transform, this.hudSetting.navLineY, halfWidth, degreeWidth, 
						this.hudSetting.navNorthOffset, this.hudSetting.navForwardOffset, forwardAngle, 
						leftEnd, rightEnd, textStyle, this);
				}
			}
			// editor
			else if(!Application.isPlaying)
			{
				float rightEnd = this.hudSetting.navDisplayRange / 2;
				float leftEnd = -rightEnd;
				float halfWidth = baseWidth / 2;
				float degreeWidth = baseWidth / this.hudSetting.navDisplayRange;
				
				for(int i=0; i<this.hudSetting.navigationElement.Length; i++)
				{
					this.hudSetting.navigationElement[i].CreateEditor(
						ref this.content, this.hudSetting.navLineY, halfWidth, degreeWidth, 
						this.hudSetting.navNorthOffset, this.hudSetting.navForwardOffset, 0, leftEnd, rightEnd, textStyle);
				}
			}
			
			for(int i=0; i<this.content.Count; i++)
			{
				if(contentHeight < this.content[i].Key.y + this.content[i].Value.bounds.y + this.content[i].Value.bounds.height)
				{
					contentHeight = this.content[i].Key.y + this.content[i].Value.bounds.y + this.content[i].Value.bounds.height;
				}
			}
			
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
				!this.box.forceSize)
			{
				this.box.bounds.height = contentHeight + this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
			}
			else if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				this.scrollRect = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
					baseWidth, contentHeight);
			}
			
			this.contentBounds = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
				this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
		}
		
		
		/*
		============================================================================
		Show GUI functions
		============================================================================
		*/
		public override void ShowBefore()
		{
			// background image
			if(this.hudSetting != null && 
				this.hudSetting.showBackground && this.hudSetting.bgImage != null)
			{
				if(this.hudSetting.bgRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.windowRect, this.hudSetting.bgRelativeTo);
					this.hudSetting.bgImage.Show(tmp.x, tmp.y);
				}
				else
				{
					this.hudSetting.bgImage.Show();
				}
			}
		}
		
		public override void ShowAfter()
		{
			// foreground image
			if(this.hudSetting != null && 
				this.hudSetting.showForeground && this.hudSetting.fgImage != null)
			{
				if(this.hudSetting.fgRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.windowRect, this.hudSetting.fgRelativeTo);
					this.hudSetting.fgImage.Show(tmp.x, tmp.y);
				}
				else
				{
					this.hudSetting.fgImage.Show();
				}
			}
		}

		public override void ShowWindow()
		{
			if(this.box.doFlash)
			{
				GUI.color = this.box.flashColor;
			}
			else
			{
				GUI.color = this.box.color;
			}
			
			GUIStyle textStyle = new GUIStyle(GUI.skin.label);
			textStyle.wordWrap = false;
			
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.skin.horizontalScrollbar = GUIStyle.none;
				this.scroll = GUI.BeginScrollView(this.contentBounds, this.scroll, this.scrollRect);
				GUI.BeginGroup(this.scrollRect);
			}
			else
			{
				GUI.BeginGroup(this.contentBounds);
			}
			
			// display content
			for(int i=0; i<this.content.Count; i++)
			{
				// no flash > reset color
				this.box.SetGUIColor(this.content[i].Value.setting.noFlash);
				
				// show
				this.content[i].Value.ShowAt(this.content[i].Key, textStyle);
				this.box.SetGUIColor(false);
			}
			
			GUI.EndGroup();
			if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				GUI.EndScrollView();
			}
		}
	}
}
