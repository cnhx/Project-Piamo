
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Display
{
	public class ShortcutSlotText : BaseData
	{
		[ORKEditorHelp("Position", "Set the X and Y position of the info label within a shortcut's bounds.", "")]
		public Vector2 position = Vector2.zero;
		
		[ORKEditorHelp("Anchor", "Select the anchor of the info label.\n" +
			"E.g. 'Upper Left' will place the upper left corner of the info label at the defined position, " +
			"'Lower Right' will place the lower right corner of the image at the defind position.", "")]
		public TextAnchor anchor = TextAnchor.UpperLeft;
		
		[ORKEditorHelp("Relative To", "Select the the corner of the shortcut's bounds the info label will be relative to.", "")]
		public TextAnchor relativeTo = TextAnchor.UpperLeft;
		
		[ORKEditorInfo(separator=true, 
			label=new string[] {"%n = name, %d = description, %i = icon, % = info (quantity, use costs), %s = slot index"})]
		public StatusTextHUD text = new StatusTextHUD();
		
		public ShortcutSlotText()
		{
			
		}
		
		public void Create(ref List<BaseLabel> label, Combatant combatant, IShortcut shortcut, Rect bounds, GUIStyle textStyle, int index)
		{
			MultiContent mc = new MultiContent(
				TextHelper.ReplaceSpecials(this.GetText(combatant, shortcut, 
					this.text.text[ORK.Game.Language], index)), 
				null, null, textStyle, bounds, this.text.lineSpacing, this.text.alignment, 
				this.text.vAlignment, BoxHeightAdjustment.Auto, false, this.text.textFormat);
			
			// move to anchor positions
			Rect tmpBounds = new Rect(this.position.x, this.position.y, mc.size.x - bounds.x, mc.size.y - bounds.y);
			Vector2 tmp = GUIHelper.GetRectAnchor(bounds, this.relativeTo);
			tmpBounds.x += (tmp.x - bounds.x);
			tmpBounds.y += (tmp.y - bounds.y);
			GUIHelper.GetRectAnchor(ref tmpBounds, -tmpBounds.width, -tmpBounds.height, this.anchor);
			mc.ChangePosition(tmpBounds.x, tmpBounds.y);
			
			label.AddRange(mc.label);
		}
		
		private string GetText(Combatant combatant, IShortcut shortcut, string text, int index)
		{
			return shortcut != null ? 
				text.Replace("%n", shortcut.GetName()).
					Replace("%d", shortcut.GetDescription()).
					Replace("%i", shortcut.GetIconTextCode()).
					Replace("%s", index.ToString()).
					Replace("%", shortcut.GetInfo(combatant)) : 
				text.Replace("%n", "").
					Replace("%d", "").
					Replace("%i", "").
					Replace("%s", index.ToString()).
					Replace("%", "");
		}
	}
}
