
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Learn Log Text", "The player will learn a new log text.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Log Steps")]
	public class LearnLogTextStep : BaseEventStep
	{
		[ORKEditorHelp("Complete Log", "Learn all log texts of a log.\n" +
			"If disabled, only a selected log text will be learned.", "")]
		public bool completeLog = false;
		
		[ORKEditorHelp("Log Text", "Select the log text the player will learn.", "")]
		[ORKEditorInfo(ORKDataType.LogText)]
		[ORKEditorLayout("completeLog", false)]
		public int id = 0;
		
		[ORKEditorHelp("Log", "Select the log the player will learn completely.", "")]
		[ORKEditorInfo(ORKDataType.Log)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id2 = 0;
		
		[ORKEditorHelp("Show Console", "Show the log's learning/update text in the console.", "")]
		public bool showConsole = true;
		
		public LearnLogTextStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.completeLog)
			{
				ORK.Game.Logs.Learn(this.id2, this.showConsole);
			}
			else
			{
				ORK.Game.Logs.LearnText(this.id, this.showConsole);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.completeLog ? 
				"Complete: "+ ORK.Logs.GetName(this.id2) : 
				ORK.LogTexts.GetName(this.id);
		}
	}
	
	[ORKEditorHelp("Forget Log Text", "The player will forget a log text.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Log Steps")]
	public class ForgetLogTextStep : BaseEventStep
	{
		[ORKEditorHelp("Forget All", "All log texts will be forgotten.\n" +
			"If disabled, only a selected log text will be forgotten.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Complete Log", "Forget all log texts of a log.\n" +
			"If disabled, only a selected log text will be forgotten.", "")]
		[ORKEditorLayout("all", false)]
		public bool completeLog = false;
		
		[ORKEditorHelp("Log Text", "Select the log text the player will forget.", "")]
		[ORKEditorInfo(ORKDataType.LogText)]
		[ORKEditorLayout("completeLog", false)]
		public int id = 0;
		
		[ORKEditorHelp("Log", "Select the log the player will forget completely.", "")]
		[ORKEditorInfo(ORKDataType.Log)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public int id2 = 0;
		
		[ORKEditorHelp("Show Console", "Show the log's forgetting/update text in the console.", "")]
		public bool showConsole = true;
		
		public ForgetLogTextStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				ORK.Game.Logs.ForgetAllTexts();
			}
			else
			{
				if(this.completeLog)
				{
					ORK.Game.Logs.Forget(this.id2, this.showConsole);
				}
				else
				{
					ORK.Game.Logs.ForgetText(this.id, this.showConsole);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? "All Log Texts" : 
				(this.completeLog ? 
					"Complete: "+ ORK.Logs.GetName(this.id2) : 
					ORK.LogTexts.GetName(this.id));
		}
	}
	
	[ORKEditorHelp("Knows Log Text", "Checks if the player knows a log text.\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Log Steps", "Check Steps")]
	public class KnowsLogTextStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Any Log Text", "Checks if the player knows any log text at all.\n" +
			"If disabled, a defined log text will be checked.", "")]
		public bool any = false;
		
		[ORKEditorHelp("Complete Log", "Check if the player knows a all log texts of a log.\n" +
			"If disabled, only a selected log text will be checked for.", "")]
		[ORKEditorLayout("any", false)]
		public bool completeLog = false;
		
		[ORKEditorHelp("Log Text", "Select the log text that will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.LogText)]
		[ORKEditorLayout("completeLog", false)]
		public int id = 0;
		
		[ORKEditorHelp("Log", "Select the log that will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.Log)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public int id2 = 0;
		
		public KnowsLogTextStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if((this.any && ORK.Game.Logs.HasTexts()) || 
				(!this.any && 
					(this.completeLog ? 
						ORK.Game.Logs.Knows(this.id2) : 
						ORK.Game.Logs.KnowsText(this.id))))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.any ? "Any Log Texts" : 
				(this.completeLog ? 
					"Complete: "+ ORK.Logs.GetName(this.id2) : 
					ORK.LogTexts.GetName(this.id));
		}
	}
}
