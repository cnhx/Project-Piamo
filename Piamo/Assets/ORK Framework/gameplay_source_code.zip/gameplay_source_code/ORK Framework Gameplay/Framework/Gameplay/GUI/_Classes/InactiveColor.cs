
using UnityEngine;

namespace ORKFramework
{
	public class InactiveColor : BaseData
	{
		[ORKEditorHelp("Set Background Color", "Set the background tinting color.\n" +
			"This will affect only backgrounds (e.g. box, window, button).", "")]
		public bool setBC = false;
		
		[ORKEditorHelp("Background Color", "Select the background tinting color.", "")]
		[ORKEditorLayout("setBC", true, endCheckGroup=true)]
		public Color bColor = Color.grey;
		
		[ORKEditorHelp("Set Content Color", "Set the content tinting color.\n" +
			"This will affect only text and icon colors.", "")]
		public bool setCC = false;
		
		[ORKEditorHelp("Content Color", "Select the content tinting color.", "")]
		[ORKEditorLayout("setCC", true, endCheckGroup=true)]
		public Color cColor = Color.grey;
		
		public InactiveColor()
		{
			
		}
		
		public void SetColors()
		{
			if(this.setBC)
			{
				GUI.backgroundColor = this.bColor;
			}
			if(this.setCC)
			{
				GUI.contentColor = this.cColor;
			}
		}
	}
}

