
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Display
{
	public class IntValueInput : BaseValueInput
	{
		public int value = 0;
		
		public int min = 0;
		
		public int max = 0;
		
		private Rect valueRect;
		
		private int change = 1;
		
		public IntValueInput(int value, int minValue, int maxValue, string fieldName)
		{
			this.value = value;
			this.min = minValue;
			this.max = maxValue;
			this.fieldName = fieldName;
			
			if(this.value < this.min)
			{
				this.value = this.min;
			}
			else if(this.value > this.max)
			{
				this.value = this.max;
			}
			
			this.change = (this.max - this.min) / 10;
			if(this.change < 1)
			{
				this.change = 1;
			}
		}
		
		public override void CreateField(GUIBox box, GUIStyle textStyle, 
			ref Rect textBounds, ref float contentHeight, ref float maxXPos)
		{
			if(contentHeight > 0)
			{
				contentHeight += box.Settings.lineSpacing;
			}
			textBounds.y = contentHeight;
			
			this.bounds = new Rect(0, contentHeight, textBounds.width, 0);
			
			if(this.fieldName != "")
			{
				this.fieldNameContent = new MultiContent(TextHelper.ReplaceSpecials(this.fieldName), null, null, 
					textStyle, textBounds, box.Settings.lineSpacing, 
					box.Settings.alignment, box.Settings.vAlignment, 
					box.Settings.heightAdjustment, box.Settings.oneline, 
					box.Settings.textFormat, box.Settings.textColumns, 
					box.Settings.textColumnSpacing);
				
				Vector2 tmpSize = textStyle.CalcSize(
					new GUIContent(this.max.ToString("0.0")));
				this.valueRect = new Rect(textBounds.width - tmpSize.x, 
					contentHeight, tmpSize.x, tmpSize.y);
				this.fieldRect = new Rect(
					this.fieldNameContent.size.x + box.Settings.inputFieldSpacing, 
					contentHeight, 
					textBounds.width - this.fieldNameContent.size.x - box.Settings.inputFieldSpacing - tmpSize.x, 
					tmpSize.y);
				contentHeight += Mathf.Max(this.fieldRect.height, this.fieldNameContent.size.y - textBounds.y);
			}
			else
			{
				Vector2 tmpSize = textStyle.CalcSize(
					new GUIContent(this.max.ToString("0.0")));
				this.valueRect = new Rect(textBounds.width - tmpSize.x, 
					contentHeight, tmpSize.x, tmpSize.y);
				this.fieldRect = new Rect(0, contentHeight, 
					textBounds.width - tmpSize.x, tmpSize.y);
				contentHeight += this.fieldRect.height;
			}
			this.bounds.height = this.fieldRect.height;
			
			if(maxXPos < this.fieldRect.x)
			{
				maxXPos = this.fieldRect.x;
			}
		}
		
		public override bool ShowField(GUIBox box, int index, bool selected, GUIStyle textStyle)
		{
			base.ShowField(box, index, selected, textStyle);
			
			GUIStyle tmpTextStyle = new GUIStyle(textStyle);
			tmpTextStyle.alignment = TextAnchor.UpperRight;
			
			int tmpValue = this.value;
			this.value = (int)GUI.HorizontalSlider(this.fieldRect, this.value, this.min, this.max);
			GUI.Label(this.valueRect, this.value.ToString(), tmpTextStyle);
			return tmpValue != this.value;
		}
		
		
		/*
		============================================================================
		Control functions
		============================================================================
		*/
		public override bool HorizontalChange(int add)
		{
			this.value += add * this.change;
			
			if(this.value < this.min)
			{
				this.value = this.min;
			}
			else if(this.value > this.max)
			{
				this.value = this.max;
			}
			return true;
		}
	}
}
