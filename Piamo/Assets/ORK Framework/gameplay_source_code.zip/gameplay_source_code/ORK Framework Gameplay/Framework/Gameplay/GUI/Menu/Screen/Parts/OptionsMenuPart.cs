
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework.Menu.Parts
{
	[ORKEditorHelp("Options", "Displays list of game options.", "")]
	public class OptionsMenuPart : BaseMenuPart, IChoice, IValueInputChoice
	{
		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the options.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox, separator=true)]
		public int guiBoxID = 0;
		
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the options menu.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		// message
		[ORKEditorHelp("Options Message", "The text displayed in the options menu.\n" +
			"Leave empty if no additional text should be displayed.", "")]
		[ORKEditorInfo("Options Message", "The text displayed in the options menu.\n" +
			"Leave empty if no additional text should be displayed.", "", 
			endFoldout=true, isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] message = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// items
		[ORKEditorArray(false, "Add Option", "Adds an option.", "", 
			"Remove", "Removes this option.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Option", "Define the option that will be displayed", ""
		})]
		public GameOption[] gameOptions = new GameOption[0];
		
		
		// ingame
		private GUIBox box;
		
		private List<BaseValueInput> valueInputs;
		
		private bool accepted = false;
		
		public OptionsMenuPart()
		{
			
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return true;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return true;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public override bool Controlable
		{
			get{ return this.IsOpened;}
		}
		
		
		/*
		============================================================================
		Menu button functions
		============================================================================
		*/
		public override bool IsOpened
		{
			get{ return this.box == null || this.box.FadedIn;}
		}
		
		public override bool IsClosed
		{
			get{ return this.box == null;}
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		public override bool FocusFirst()
		{
			if(this.box != null)
			{
				this.box.SetFocus();
				return true;
			}
			return false;
		}
		
		public override bool IsFocused()
		{
			return this.box != null && this.box.Focused;
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void Refresh()
		{
			this.Show();
		}
		
		public override void Show(MenuScreen s)
		{
			this.screen = s;
			this.accepted = false;
			this.Show();
		}
		
		public void Show()
		{
			// init box
			if(this.box == null || this.box.FadingOut || this.box.FadedOut)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID);
				this.box.inPause = this.screen.pauseGame;
				this.box.InitIn();
			}
			
			// init content
			this.valueInputs = new List<BaseValueInput>();
			for(int i=0; i<this.gameOptions.Length; i++)
			{
				this.valueInputs.Add(this.gameOptions[i].GetValueInput(ORK.Game.Variables));
			}
			this.box.Content = new ValueInputContent(
				this.message[ORK.Game.Language], 
				this.useTitle ? this.title[ORK.Game.Language] : "", 
				this.valueInputs, this, null);
		}
		
		public override void ChangeCombatant(Combatant old)
		{
			
		}
		
		public override void CloseImmediate()
		{
			if(this.box != null)
			{
				this.box.SetOutDone();
				this.box = null;
				this.valueInputs = null;
			}
		}
		
		public override void Close()
		{
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.InitOut();
			}
		}

		public void Closed(GUIBox origin)
		{
			if(this.valueInputs != null)
			{
				if(this.accepted)
				{
					for(int i=0; i<this.valueInputs.Count; i++)
					{
						this.gameOptions[i].SetNewValue(ORK.Game.Variables, this.valueInputs[i]);
					}
				}
				else
				{
					for(int i=0; i<this.valueInputs.Count; i++)
					{
						this.gameOptions[i].ResetValue(ORK.Game.Variables);
					}
				}
			}
			this.accepted = false;
			this.valueInputs = null;
			this.box = null;
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			this.accepted = true;
			this.screen.Close();
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}
		
		public void ValueInputChanged(int index, GUIBox origin)
		{
			if(this.valueInputs != null && 
				index >= 0 && index < this.gameOptions.Length)
			{
				this.gameOptions[index].SetNewValue(ORK.Game.Variables, this.valueInputs[index]);
			}
		}

		public void Canceled(GUIBox origin)
		{
			if(this.valueInputs != null)
			{
				for(int i=0; i<this.valueInputs.Count; i++)
				{
					this.gameOptions[i].ResetValue(ORK.Game.Variables);
				}
				this.valueInputs = null;
			}
			origin.Audio.PlayCancel();
			this.accepted = false;
			this.screen.Close();
		}
		
		
		/*
		============================================================================
		Unused choice interface functions
		============================================================================
		*/
		public void FocusGained(GUIBox origin)
		{
			
		}

		public void FocusLost(GUIBox origin)
		{
			
		}
	}
}
