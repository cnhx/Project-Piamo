
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu
{
	public class CombatantChoiceLayout : BaseData
	{
		[ORKEditorHelp("Complex HUD Display", "The combatants are represented by more complex choices using HUD elements.\n" +
			"If disabled, only the combatant's name and icon will be used.", "")]
		public bool complex = false;
		
		[ORKEditorLayout("complex", false)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		
		// status elements
		[ORKEditorHelp("Use HUD", "Use the status elements defined in a HUD.\n" +
			"Only the status elements of the HUD will be used, the rest of the HUD's settings are ignored.", "")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public bool useHUD = false;
		
		[ORKEditorHelp("HUD", "Select the HUD that will be used.\n" +
			"Only 'Combatant' type HUDs are allowed. Using any other HUD or a " +
			"'Combatant' type HUD without status elements result in an empty box.", "")]
		[ORKEditorInfo(ORKDataType.HUD, "type", HUDType.Combatant, true)]
		[ORKEditorLayout("useHUD", true)]
		public int hudID = 0;
		
		[ORKEditorArray(false, "Add Status Element", "Adds a status element to the combatant choice.\n" +
			"Status elements display information about the combatants - each combatant is represented by a button, " +
			"each button displays the status elements defined here.", "", 
			"Remove", "Removes this status element.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Status Element", 
				"Set the position, size, content and background image of this element.\n" +
				"The coordinates X=0, Y=0 are located at the upper left corner of the button representing a combatant.", ""})]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true, endGroups=2)]
		public HUDStatus[] informationElement;
		
		public CombatantChoiceLayout()
		{
			
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public void CheckBars()
		{
			if(this.informationElement != null)
			{
				for(int i=0; i<this.informationElement.Length; i++)
				{
					if(HUDStatusType.StatusValue.Equals(this.informationElement[i].type))
					{
						if(this.informationElement[i].status.bar != null)
						{
							this.informationElement[i].status.bar.CheckImages();
						}
					}
					else if(HUDStatusType.Timebar.Equals(this.informationElement[i].type))
					{
						if(this.informationElement[i].timebar.bar != null)
						{
							this.informationElement[i].timebar.bar.CheckImages();
						}
					}
					else if(HUDStatusType.CastTime.Equals(this.informationElement[i].type))
					{
						if(this.informationElement[i].castTime.bar != null)
						{
							this.informationElement[i].castTime.bar.CheckImages();
						}
					}
					else if(HUDStatusType.InventorySpace.Equals(this.informationElement[i].type))
					{
						if(this.informationElement[i].invSpace.bar != null)
						{
							this.informationElement[i].invSpace.bar.CheckImages();
						}
					}
				}
			}
		}
		
		
		/*
		============================================================================
		GUI functions
		============================================================================
		*/
		public HUDStatus[] GetStatusElements()
		{
			if(this.complex)
			{
				if(this.useHUD)
				{
					return ORK.HUDs.Get(this.hudID).combatantElement;
				}
				else
				{
					return this.informationElement;
				}
			}
			return null;
		}
		
		public ChoiceContent GetChoiceContent(Combatant combatant)
		{
			ChoiceContent content = null;
			if(this.complex)
			{
				content = new ChoiceContent(combatant);
				content.description = combatant.GetDescription();
				return content;
			}
			else
			{
				content = this.contentLayout.GetChoiceContent(combatant);
				content.combatant = combatant;
			}
			return content;
		}
	}
}
