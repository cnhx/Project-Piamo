
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu.Parts
{
	[ORKEditorHelp("Description", "Displays the description of selected menu items.", "")]
	public class DescriptionMenuPart : BaseMenuPart, IChoice
	{
		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the description of a selected menu item.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		[ORKEditorHelp("Always Visible", "The description box will always be visible, even if no description is available.\n" +
			"If disabled, the description box will only be displayed if the selected menu item has a description.", "")]
		public bool always = false;
		
		[ORKEditorHelp("Content Fallback", "If no content is available (e.g. on 'Back' buttons), " +
			"the content text codes will fall back to the choice text codes " +
			"(i.e. '%cn' > '%n', '%cd' > '%d').", "")]
		[ORKEditorLayout(new string[] {"useTitle", "useCustomText"}, 
			new System.Object[] {true, true}, needed=Needed.One, endCheckGroup=true)]
		public bool contentFallback = true;
		
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the description box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = text of the selected choice, %d = description of the selected choice", 
			"%cn = content name, %cd = content description, %ci = content icon", 
			"'content' is what the choice represents, e.g. an item, equipment or ability"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		// text
		[ORKEditorHelp("Use Custom Text", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useCustomText = false;
		
		[ORKEditorHelp("Custom Text", "The text of the description box.", "")]
		[ORKEditorInfo(isTextArea=true, label=new string[] {
			"%n = text of the selected choice, %d = description of the selected choice", 
			"%cn = content name, %cd = content description, %ci = content icon", 
			"'content' is what the choice represents, e.g. an item, equipment or ability"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorLayout("useCustomText", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] text;
		
		
		// ingame
		private GUIBox box;
		
		public DescriptionMenuPart()
		{
			
		}
		
		public override bool IsFocused()
		{
			return this.box != null && this.box.Focused;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsOpened
		{
			get{ return this.box == null || this.box.FadedIn;}
		}
		
		public override bool IsClosed
		{
			get{ return this.box == null;}
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void Refresh()
		{
			
		}
		
		public override void Show(MenuScreen s)
		{
			this.screen = s;
			this.Show("", "", null);
		}
		
		public override void ChangeCombatant(Combatant old)
		{
			this.Refresh();
		}
		
		private string GetText(string text, string name, string desc, IContentSimple content)
		{
			if(content != null)
			{
				return text.
					Replace("%n", name).
					Replace("%d", desc).
					Replace("%cn", content.GetName()).
					Replace("%cd", content.GetDescription()).
					Replace("%ci", content.GetIconTextCode());
			}
			else
			{
				return text.
					Replace("%n", name).
					Replace("%d", desc).
					Replace("%cn", this.contentFallback ? name : "").
					Replace("%cd", this.contentFallback ? desc : "").
					Replace("%ci", "");
			}
		}
		
		public void Show(string desc, string name, IContentSimple content)
		{
			// hide description box
			if(this.box != null && desc == "" && !this.always)
			{
				this.box.InitOut();
			}
			// show/change description box
			else if(desc != "" || this.always)
			{
				if(this.box == null || this.box.FadingOut || this.box.FadedOut)
				{
					this.box = ORK.GUIBoxes.Create(this.guiBoxID);
					this.box.controlable = false;
					this.box.InitIn();
				}
				
				this.box.inPause = this.screen != null ? this.screen.pauseGame : false;
				this.box.Content = new DialogueContent(
					this.useCustomText ? 
						this.GetText(this.text[ORK.Game.Language], name, desc, content) : desc, 
					this.useTitle ? 
						this.GetText(this.title[ORK.Game.Language], name, desc, content) : "", 
					null, this);
			}
		}
		
		public override void CloseImmediate()
		{
			if(this.box != null)
			{
				this.box.SetOutDone();
				this.box = null;
			}
		}
		
		public override void Close()
		{
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.InitOut();
			}
		}

		public void Closed(GUIBox origin)
		{
			if(this.box == origin)
			{
				this.box = null;
			}
		}
		
		
		/*
		============================================================================
		Unused choice interface functions
		============================================================================
		*/
		public void Show()
		{
			
		}

		public void FocusGained(GUIBox origin)
		{
			
		}

		public void FocusLost(GUIBox origin)
		{
			
		}

		public void ChoiceSelected(int index, GUIBox origin)
		{
			
		}

		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}

		public void Canceled(GUIBox origin)
		{
			
		}
	}
}
