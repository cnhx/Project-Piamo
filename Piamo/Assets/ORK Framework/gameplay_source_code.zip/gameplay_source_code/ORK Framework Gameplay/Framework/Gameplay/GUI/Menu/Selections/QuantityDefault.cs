
using UnityEngine;
using ORKFramework;

namespace ORKFramework.Menu
{
	public class QuantityDefault : BaseData
	{
		[ORKEditorHelp("Quantity Selection", "Select the quantity selection that will be used.", "")]
		[ORKEditorInfo(ORKDataType.QuantitySelection)]
		public int id = 0;
		
		[ORKEditorHelp("Minimum Quantity", "At least this quantity must be available to call the quantity selection.\n" +
			"If the quantity is below this number, only 1 item will be removed (or dropped, bought, etc.)", "")]
		[ORKEditorLimit(1, false)]
		public int minimum = 1;
		
		public QuantityDefault()
		{
			
		}
		
		public void Call(QuantityData data)
		{
			if(data.shortcut.Quantity >= 1 && data.shortcut.Quantity < this.minimum)
			{
				data.Execute(1);
			}
			else
			{
				ORK.QuantitySelections.Get(this.id).Show(data);
			}
		}
	}
}
