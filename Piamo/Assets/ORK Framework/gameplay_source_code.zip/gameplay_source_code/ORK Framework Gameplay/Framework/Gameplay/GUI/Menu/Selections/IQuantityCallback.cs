
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public interface IQuantityCallback
	{
		void QuantityCallback(IShortcut shortcut, int quantity, QuantitySelectionMode mode);
	}
}
