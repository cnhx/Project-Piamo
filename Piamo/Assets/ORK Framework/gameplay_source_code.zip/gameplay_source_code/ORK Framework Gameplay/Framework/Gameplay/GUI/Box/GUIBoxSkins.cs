
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GUIBoxSkins : BaseData
	{
		// skins
		[ORKEditorHelp("Base Skin", "The GUISkin used to display a GUI box.\n" +
			"Uses the box, label, button and scrollbar style of the skin.", "")]
		public GUISkin skin;
		
		[ORKEditorHelp("Selected Choice", "The GUISkin used to display a selected choice.\n" +
			"Uses the label and button style of the skin. If no skin is selected, the base skin is used.", "")]
		public GUISkin selectSkin;
		
		[ORKEditorHelp("Ok/Cancel Button", "The GUISkin used to display the 'Ok' and 'Cancel' buttons.\n" +
			"Uses the label and button style of the skin. If no skin is selected, the base skin is used.", "")]
		public GUISkin okSkin;
		
		[ORKEditorHelp("Name Box", "The GUISkin used to display the name box.\n" +
			"Uses the label and box style of the skin. If no skin is selected, the base skin is used.", "")]
		public GUISkin nameSkin;
		
		[ORKEditorHelp("Tabs Choice", "The GUISkin used to display tab buttons.\n" +
			"Uses the label and button style of the skin. If no skin is selected, the base skin is used.", "")]
		public GUISkin tabsSkin;
		
		[ORKEditorHelp("Tabs Selected Choice", "The GUISkin used to display selected tab buttons.\n" +
			"Uses the label and button style of the skin. If no skin is selected, the selected skin or the base skin is used.", "")]
		public GUISkin tabsSelectSkin;
		
		public GUIBoxSkins()
		{
			
		}
	}
}
