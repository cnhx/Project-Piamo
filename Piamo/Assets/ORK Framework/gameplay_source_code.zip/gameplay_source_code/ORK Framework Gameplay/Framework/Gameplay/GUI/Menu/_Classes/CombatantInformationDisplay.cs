
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu
{
	public class CombatantInformationDisplay : BaseData
	{
		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the combatant information.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		[ORKEditorHelp("Combatant Scope", "Select the scope of the combatant info:\n" +
			"- Current: The currently active combatant.\n" +
			"- Battle: The members of the battle group.\n" +
			"- Group: All members of the group.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public MenuCombatantScope scope = MenuCombatantScope.Current;
		
		[ORKEditorHelp("Show As Button", "Each combatant's information is displayed as a button.\n" +
			"Note that every combatant is displayed using the GUI box choice settings, " +
			"regardless of whether it is displayed as a button or not.", "")]
		public bool isButton = false;
		
		
		// page keys
		[ORKEditorHelp("Use Change Keys", "The page can be changed by keys.\n" +
			"Changing pages is only possible if more than one page is available.", "")]
		[ORKEditorInfo(separator=true, labelText="Page Change Keys")]
		public bool usePageKeys = false;
		
		[ORKEditorHelp("Next Page", "Select the key used to select the next page.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("usePageKeys", true)]
		public int nextPageKey = 0;
		
		[ORKEditorHelp("Previous Page", "Select the key used to select the previous page.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int prevPageKey = 0;
		
		
		// pages
		[ORKEditorArray(false, "Add Page", "Adds a combatant information page.", "", 
			"Remove", "Removes this combatant information page.", "", isMove=true, isCopy=true, noRemoveCount=1, 
			foldout=true, foldoutText=new string[] {"Combatant Page", 
			"Set the title and content of this combatant information page.", ""})]
		public CombatantPage[] page = new CombatantPage[] {new CombatantPage()};
		
		public CombatantInformationDisplay()
		{
			
		}
		
		public GUIBoxContent GetPage(IChoice parent, Combatant combatant, int pageIndex)
		{
			return this.page[pageIndex].GetContent(parent, combatant, this.scope, this.isButton);
		}
	}
}
