
using UnityEngine;
using ORKFramework;
using ORKFramework.Menu.Parts;
using System.Collections.Generic;

namespace ORKFramework.Menu
{
	public class SubMenuItem : BaseData
	{
		[ORKEditorHelp("Sub Menu Item", "Select the type of the sub menu item:\n" +
			"- Use: Uses an item/ability ('Use' button), equips an equipment ('Equip' button).\n" +
			"- Give: Gives an item/equipment to another group member (only possible if 'Individual' inventory is used).\n" +
			"- Remove: Removes an item/equipment.\n" +
			"- Drop: Drops an item/equipment into the game world (which will remove it from the inventory).\n" +
			"- Back: Closes the sub menu without doing anything ('Back' button).\n" +
			"- Cancel: Closes the sub menu without doing anything ('Cancel' button).\n" +
			"- Level Up: Increases the level of abilities/equipment with level up type 'Spend' (if enough experience is available).", "")]
		public SubMenuAction type = SubMenuAction.Use;
		
		[ORKEditorHelp("Use Key", "Use an input key to call the action of this sub menu item (e.g. drop an item).\n" +
			"The key is used to use this menu item's action without opening the sub menu, " +
			"i.e. the key can be used in the same menu as the sub menu call key.", "")]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {SubMenuAction.Back, SubMenuAction.Cancel}, needed=Needed.One, 
			elseCheckGroup=true, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool useKey = false;
		
		[ORKEditorHelp("Call Key", "Select the input key to use this sub menu item.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useKey", true, endCheckGroup=true)]
		public int keyID = 0;
		
		[ORKEditorLayout(new string[] {"type", "type", "type"}, 
			new System.Object[] {SubMenuAction.Give, SubMenuAction.Remove, SubMenuAction.Drop}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public QuantityCall quantity;
		
		
		// menu combatant selection
		[ORKEditorHelp("Own Com. Selection", "Define a combatant selection that will be used.\n" +
			"If disabled, the default combatant selection (menu user) will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Give Target Selection")]
		[ORKEditorLayout("type", SubMenuAction.Give)]
		public bool ownSelection = false;
		
		[ORKEditorHelp("Combatant Selection", "Select the combatant selection that will be used.", "")]
		[ORKEditorInfo(ORKDataType.CombatantSelection)]
		[ORKEditorLayout("ownSelection", true, endCheckGroup=true, endGroups=2)]
		public int selectionID = 0;
		
		
		// own content
		[ORKEditorHelp("Own Button Content", "Override the button's default name, description and icon.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ownContent = false;
		
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		[ORKEditorLayout("ownContent", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public LanguageInfo[] button;
		
		public SubMenuItem()
		{
			
		}
		
		public static SubMenuItem Create(SubMenuAction type)
		{
			SubMenuItem item = new SubMenuItem();
			item.type = type;
			item.useKey = false;
			item.ownSelection = false;
			item.ownContent = false;
			
			if(SubMenuAction.Give.Equals(item.type) || 
				SubMenuAction.Remove.Equals(item.type) || 
				SubMenuAction.Drop.Equals(item.type))
			{
				item.quantity = new QuantityCall();
				item.quantity.type =  QuantityType.Default;
			}
			
			return item;
		}
		
		public bool CanUse(IShortcut shortcut, BaseMenuPart parent)
		{
			if(SubMenuAction.Use.Equals(this.type))
			{
				return shortcut.CanUse(parent.Screen.Combatant, false);
			}
			else if(SubMenuAction.Give.Equals(this.type) && 
				ORK.InventorySettings.IsIndividual() && 
				(shortcut is ItemShortcut || shortcut is EquipShortcut || shortcut is MoneyShortcut))
			{
				return true;
			}
			else if(SubMenuAction.Remove.Equals(this.type) || 
				SubMenuAction.Drop.Equals(this.type))
			{
				return shortcut.IsDropable();
			}
			else if(SubMenuAction.LevelUp.Equals(this.type))
			{
				if(shortcut is AbilityShortcut)
				{
					AbilityShortcut ability = shortcut as AbilityShortcut;
					return ability.CanLevelUpSpend(parent.Screen.Combatant);
				}
				else if(shortcut is EquipShortcut)
				{
					EquipShortcut equip = shortcut as EquipShortcut;
					return equip.CanLevelUpSpend(parent.Screen.Combatant);
				}
			}
			return false;
		}
		
		public bool Use(IShortcut shortcut, BaseMenuPart parent)
		{
			if(SubMenuAction.Use.Equals(this.type) && 
				shortcut.CanUse(parent.Screen.Combatant, false))
			{
				if(parent.OnScreenCombatant || shortcut.OnScreenCombatant)
				{
					if(shortcut.GroupTarget())
					{
						shortcut.Use(parent.Screen.Combatant, parent.Screen.Combatant.Group.GetBattle());
					}
					else
					{
						List<Combatant> tmp = new List<Combatant>();
						tmp.Add(parent.Screen.Combatant);
						shortcut.Use(parent.Screen.Combatant, tmp);
					}
				}
				else
				{
					shortcut.CallCombatantSelection(parent);
				}
				return true;
			}
			else if(SubMenuAction.Give.Equals(this.type) && 
				ORK.InventorySettings.IsIndividual() && 
				(shortcut is ItemShortcut || shortcut is EquipShortcut || shortcut is MoneyShortcut))
			{
				if(this.ownSelection)
				{
					ORK.CombatantSelections.Get(this.selectionID).ShowGive(shortcut, parent, this.quantity);
				}
				else
				{
					ORK.CombatantSelections.Get(ORK.MenuSettings.comGiveID).ShowGive(shortcut, parent, this.quantity);
				}
			}
			else if(SubMenuAction.Remove.Equals(this.type) && shortcut.IsDropable())
			{
				this.quantity.Call(
					new QuantityData(null, shortcut, shortcut.Quantity, 
						parent.Screen.Combatant.Inventory.GetCount(shortcut), 
						0, parent.Screen.Combatant.Inventory.GetMoney(0), shortcut.BuyPrice, 
						QuantitySelectionMode.Remove, null, parent.Screen.Combatant.Inventory.Remove));
			}
			else if(SubMenuAction.Drop.Equals(this.type) && shortcut.IsDropable())
			{
				this.quantity.Call(
					new QuantityData(null, shortcut, shortcut.Quantity, 
						parent.Screen.Combatant.Inventory.GetCount(shortcut), 
						0, parent.Screen.Combatant.Inventory.GetMoney(0), shortcut.BuyPrice, 
						QuantitySelectionMode.Drop, null, parent.Screen.Combatant.Inventory.Drop));
			}
			else if(SubMenuAction.LevelUp.Equals(this.type))
			{
				if(shortcut is AbilityShortcut)
				{
					AbilityShortcut ability = shortcut as AbilityShortcut;
					if(ability.CanLevelUpSpend(parent.Screen.Combatant))
					{
						ability.SpendExperience(parent.Screen.Combatant);
					}
				}
				else if(shortcut is EquipShortcut)
				{
					EquipShortcut equip = shortcut as EquipShortcut;
					EquipShortcut newEquip = null;
					
					// only update one equipment
					if(equip.Quantity > 1)
					{
						newEquip = equip.GetCopy(1) as EquipShortcut;
						equip.Quantity -= 1;
					}
					else
					{
						parent.Screen.Combatant.Inventory.Remove(equip, false, false);
						newEquip = equip;
					}
					
					if(equip.CanLevelUpSpend(parent.Screen.Combatant))
					{
						equip.SpendExperience(parent.Screen.Combatant);
					}
					
					if(newEquip != null)
					{
						parent.Screen.Combatant.Inventory.Add(newEquip, false, false);
					}
				}
				return true;
			}
			return false;
		}
	}
}
