
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleTextStatusEffect : BaseData
	{
		[ORKEditorHelp("Console Type", "Select the console type this text will be displayed in.", "")]
		[ORKEditorInfo(ORKDataType.ConsoleType)]
		public int typeID = 0;
		
		[ORKEditorHelp("Text", "The text used to display applying/removing a status effect.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, 
			label=new string[] {"%un = user name, %n = status effect name, %i = status effect icon"})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		public ConsoleTextStatusEffect()
		{
			
		}
		
		public ConsoleTextStatusEffect(string text)
		{
			this.text = ArrayHelper.CreateArray(ORK.Languages.Count, text);
		}
		
		public void Print(Combatant user, IContentSimple content)
		{
			if(ORK.ConsoleSettings.statusRange.InRange(user))
			{
				ORK.Game.Console.AddLine(
					this.text[ORK.Game.Language].
						Replace("%un", user.GetName()).
						Replace("%n", content != null ? content.GetName() : "").
						Replace("%i", content != null ? content.GetIconTextCode() : ""), 
					this.typeID);
			}
		}
	}
}
