
using UnityEngine;
using System.Collections.Generic;
using ORKFramework;

namespace ORKFramework.Menu.Parts
{
	[ORKEditorHelp("Combatant", "Displays status information of the currently active menu combatant or the whole group.", "")]
	public class CombatantMenuPart : BaseMenuPart, IChoice
	{
		public CombatantInformationDisplay infoDisplay = new CombatantInformationDisplay();
		
		
		// ingame
		private GUIBox box;
		
		private int current = 0;
		
		public CombatantMenuPart()
		{
			
		}
		
		public override bool IsFocused()
		{
			return this.box != null && this.box.Focused;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsOpened
		{
			get{ return this.box == null || this.box.FadedIn;}
		}
		
		public override bool IsClosed
		{
			get{ return this.box == null;}
		}
		
		public bool Tick(GUIBox origin)
		{
			if(this.infoDisplay.usePageKeys && this.infoDisplay.page.Length > 1)
			{
				if(ORK.InputKeys.Get(this.infoDisplay.nextPageKey).GetButton())
				{
					this.ChangePage(1);
					return true;
				}
				else if(ORK.InputKeys.Get(this.infoDisplay.prevPageKey).GetButton())
				{
					this.ChangePage(-1);
					return true;
				}
			}
			return false;
		}
		
		private void ChangePage(int change)
		{
			this.box.Audio.PlayAccept();
			this.current += change;
			if(this.current < 0)
			{
				this.current = this.infoDisplay.page.Length - 1;
			}
			else if(this.current >= this.infoDisplay.page.Length)
			{
				this.current = 0;
			}
			this.Show();
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void Refresh()
		{
			this.Show();
		}
		
		public override void Show(MenuScreen s)
		{
			this.screen = s;
			this.current = 0;
			this.Show();
		}
		
		public void Show()
		{
			// init box
			if(this.box == null || this.box.FadingOut || this.box.FadedOut)
			{
				this.box = ORK.GUIBoxes.Create(this.infoDisplay.guiBoxID);
				this.box.inPause = this.screen.pauseGame;
				this.box.controlable = this.infoDisplay.page.Length > 1;
				this.box.disableChoice = true;
				this.box.InitIn();
			}
			
			// init content
			this.box.Content = this.infoDisplay.GetPage(this, this.screen.Combatant, this.current);
		}
		
		public override void ChangeCombatant(Combatant old)
		{
			this.Refresh();
		}
		
		public override void CloseImmediate()
		{
			if(this.box != null)
			{
				this.box.SetOutDone();
				this.box = null;
			}
		}
		
		public override void Close()
		{
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.InitOut();
			}
		}

		public void Closed(GUIBox origin)
		{
			if(this.box == origin)
			{
				this.box = null;
			}
		}
		
		
		/*
		============================================================================
		Unused choice interface functions
		============================================================================
		*/
		public void FocusGained(GUIBox origin)
		{
			
		}

		public void FocusLost(GUIBox origin)
		{
			
		}

		public void ChoiceSelected(int index, GUIBox origin)
		{
			
		}

		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}

		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.screen.Close();
		}
	}
}
