
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class Portrait : BaseData
	{
		[ORKEditorHelp("Portrait Image", "Select the image that will be displayed.", "")]
		public Texture2D image;
		
		
		// alpha mask
		[ORKEditorHelp("Use Alpha Mask", "Use a texture as alpha mask to hide parts of the image.", "")]
		public bool useAlphaMask = false;
		
		[ORKEditorHelp("Use Material", "Use a material with shader and alpha mask texture assigned.\n" +
			"If disabled, a default mask shader will be used and you can define the used alpha mask texture here.", "")]
		[ORKEditorLayout("useAlphaMask", true)]
		public bool useMaterial = false;
		
		[ORKEditorHelp("Mask Material", "Select the material that will be used.", "")]
		[ORKEditorLayout("useMaterial", true, setDefault=true, defaultValue=null)]
		public Material maskMaterial;
		
		[ORKEditorHelp("Alpha Mask Texture", "Select the image that will be used as alpha mask texture.", "")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2, setDefault=true, defaultValue=null)]
		public Texture2D alphaMaskTexture;
		
		
		// own portrait position
		[ORKEditorHelp("Own Position", "This portrait overrides the default and GUI box portrait position settings.", "")]
		public bool ownPortraitPosition = false;
		
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("ownPortraitPosition", true, endCheckGroup=true, autoInit=true)]
		public PortraitPosition portraitPosition;
		
		
		// in-game
		private Material material;
		
		public Portrait()
		{
			
		}
		
		public Material GetMaterial()
		{
			if(this.material == null)
			{
				if(this.useMaterial)
				{
					this.material = this.maskMaterial;
				}
				else
				{
					this.material = new Material(ORK.ALPHA_MASK_SHADER);
					this.material.SetTexture("_Mask", this.alphaMaskTexture);
				}
			}
			return this.material;
		}
	}
}
