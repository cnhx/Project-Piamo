
using System.Collections.Generic;

namespace ORKFramework
{
	public class TypeBMItem : BMItem
	{
		private BMItemType type = BMItemType.Ability;
		
		private int typeID = -1;
		
		private BattleMenuItem parent;
		
		private bool isSubMenu = false;
		
		public TypeBMItem(ChoiceContent content, BMItemType type, int typeID, BattleMenuItem parent, bool isSubMenu)
		{
			this.content = content;
			this.type = type;
			this.typeID = typeID;
			this.parent = parent;
			this.isSubMenu = isSubMenu;
		}
		
		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.active;
			if(BMItemType.Ability.Equals(this.type))
			{
				this.content.active = !owner.Status.BlockAbilities && 
					!owner.Status.IsAbilityTypeBlocked(this.typeID) && 
					owner.Abilities.GetByType(this.typeID, UseableIn.Battle).Count > 0;
			}
			else if(BMItemType.Item.Equals(this.type))
			{
				this.content.active = !owner.Status.BlockItems && 
					!owner.Status.IsItemTypeBlocked(this.typeID) && 
					owner.Inventory.GetUseableItemsByType(this.typeID, UseableIn.Battle).Count > 0;
			}
			return tmp != this.content.active;
		}

		public override void Selected(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				BattleMenuMode mode = BattleMenuMode.List;
				List<BMItem> list = new List<BMItem>();
				
				if(owner.BattleMenu.Settings.addBack && 
					owner.BattleMenu.Settings.backFirst)
				{
					list.Add(new BackBMItem(
						owner.BattleMenu.Settings.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton)));
				}
				
				// sub menu
				if(this.parent.subMenu && !this.isSubMenu)
				{
					if(BMItemType.Ability.Equals(this.type))
					{
						mode = BattleMenuMode.AbilityType;
						List<int> types = owner.Abilities.GetTypes(UseableIn.Battle);
						this.parent.typeSorter.Sort(ref types, ORKDataType.AbilityType);
						for(int i=0; i<types.Count; i++)
						{
							list.Add(new TypeBMItem(
								owner.BattleMenu.Settings.contentLayout.GetChoiceContent(ORK.AbilityTypes.Get(types[i])), 
								this.type, types[i], this.parent, true));
						}
					}
					else if(BMItemType.Item.Equals(this.type))
					{
						mode = BattleMenuMode.ItemType;
						List<int> types = owner.Inventory.GetUseableItemTypes(UseableIn.Battle);
						this.parent.typeSorter.Sort(ref types, ORKDataType.ItemType);
						for(int i=0; i<types.Count; i++)
						{
							list.Add(new TypeBMItem(
								owner.BattleMenu.Settings.contentLayout.GetChoiceContent(ORK.ItemTypes.Get(types[i])), 
								this.type, types[i], this.parent, true));
						}
					}
				}
				// list abilities/items
				else
				{
					if(BMItemType.Ability.Equals(this.type))
					{
						mode = BattleMenuMode.Ability;
						List<AbilityShortcut> abilities = owner.Abilities.GetByType(this.typeID, UseableIn.Battle);
						this.parent.contentSorter.Sort(ref abilities);
						for(int i=0; i<abilities.Count; i++)
						{
							list.Add(new AbilityBMItem(abilities[i], 
								owner.BattleMenu.Settings.contentLayout.GetChoiceContent(abilities[i], owner)));
						}
					}
					else if(BMItemType.Item.Equals(this.type))
					{
						mode = BattleMenuMode.Item;
						List<IShortcut> items = owner.Inventory.GetUseableItemsByType(this.typeID, UseableIn.Battle);
						this.parent.contentSorter.Sort(ref items);
						for(int i=0; i<items.Count; i++)
						{
							if(items[i] is ItemShortcut)
							{
								list.Add(new ItemBMItem(items[i] as ItemShortcut, 
									owner.BattleMenu.Settings.contentLayout.GetChoiceContent(items[i], owner)));
							}
						}
					}
				}
				
				if(owner.BattleMenu.Settings.addBack && 
					!owner.BattleMenu.Settings.backFirst)
				{
					list.Add(new BackBMItem(
						owner.BattleMenu.Settings.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton)));
				}
				
				owner.BattleMenu.Show(list, 0, mode);
			}
		}
	}
}
