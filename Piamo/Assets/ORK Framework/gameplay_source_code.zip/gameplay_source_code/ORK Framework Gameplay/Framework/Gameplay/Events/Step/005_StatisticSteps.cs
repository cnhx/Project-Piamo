
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Custom Statistic", "Adds a value to a custom statistic.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Statistic Steps")]
	public class CustomStatisticStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Statistic Index")]
		public EventInteger index = new EventInteger();
		
		[ORKEditorInfo(separator=true, labelText="Statistic Index", label=new string[] {"Only values >= 0 are allowed!"})]
		public EventInteger add = new EventInteger();
		
		public CustomStatisticStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Statistic.CustomChanged(this.index.GetValue(baseEvent), this.add.GetValue(baseEvent));
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Clear Statistic", "Resets all or a selected game statistics to 0.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Statistic Steps")]
	public class ClearStatisticStep : BaseEventStep
	{
		[ORKEditorHelp("Clear All", "All game statistics will be set to 0.\n" +
			"If disabled, only a selected statistic value will be set to 0.", "")]
		public bool all = true;
		
		
		// type selection
		[ORKEditorLayout("all", false, endCheckGroup=true, autoInit=true)]
		public StatisticSelection selection;
		
		public ClearStatisticStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				ORK.Statistic.Clear();
			}
			else
			{
				this.selection.Clear(baseEvent);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? "All" : this.selection.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Check Statistic", "Checks a statistic value with a defined value." +
		"If the check is valid, 'Success' is executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Statistic Steps", "Check Steps")]
	public class CheckStatisticStep : BaseEventCheckStep
	{
		// type selection
		public StatisticSelection selection = new StatisticSelection();
		
		
		// check
		[ORKEditorHelp("Check Type", "The check is valid if the current statistic value " +
			"is equal, not equal, less or greater than the defined value.", "")]
		[ORKEditorInfo(separator=true, labelText="Check Settings")]
		public ValueCheck check = ValueCheck.IsEqual;
		
		public EventInteger value = new EventInteger();
		
		public CheckStatisticStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ValueHelper.CheckValue(this.selection.Get(baseEvent), 
				this.value.GetValue(baseEvent), this.check))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.selection.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Statistic To Variable", "Stores a selected statistic value into a float game variable.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Statistic Steps", "Variable Steps")]
	public class StatisticToVariableStep : BaseEventStep
	{
		// type selection
		public StatisticSelection selection = new StatisticSelection();
		
		
		// variable settings
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Settings")]
		public VariableOrigin origin = VariableOrigin.Global;
		
		
		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;
		
		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;
		
		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";
		
		
		// variable key
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		public FormulaOperator floatOperator = FormulaOperator.Add;
		
		public StatisticToVariableStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int tmpVal = this.selection.Get(baseEvent);
			
			if(VariableOrigin.Local.Equals(this.origin))
			{
				baseEvent.Variables.ChangeFloat(this.key.GetValue(), 
					tmpVal, this.floatOperator);
			}
			else if(VariableOrigin.Global.Equals(this.origin))
			{
				ORK.Game.Variables.ChangeFloat(this.key.GetValue(), 
					tmpVal, this.floatOperator);
			}
			else if(VariableOrigin.Object.Equals(this.origin))
			{
				if(this.useObject)
				{
					List<GameObject> list = this.fromObject.GetObject(baseEvent);
					for(int i=0; i<list.Count; i++)
					{
						if(list[i] != null)
						{
							ObjectVariablesComponent[] comps = list[i].
								GetComponentsInChildren<ObjectVariablesComponent>();
							for(int j=0; j<comps.Length; j++)
							{
								comps[j].GetHandler().ChangeFloat(
									this.key.GetValue(), tmpVal, this.floatOperator);
							}
						}
					}
				}
				else
				{
					ORK.Game.Scene.GetObjectVariables(this.objectID).ChangeFloat(
						this.key.GetValue(), tmpVal, this.floatOperator);
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.origin.ToString() + ": " + this.selection.GetInfoText();
		}
	}
}
