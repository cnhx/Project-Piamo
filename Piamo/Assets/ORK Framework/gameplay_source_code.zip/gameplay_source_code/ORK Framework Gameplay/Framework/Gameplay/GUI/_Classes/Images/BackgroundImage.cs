
using UnityEngine;

namespace ORKFramework
{
	public class BackgroundImage : BaseData
	{
		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the image.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int boxID = 0;
		
		public BaseImage image = new BaseImage();
		
		public BackgroundImage()
		{
			
		}
		
		public GUIBox Init()
		{
			GUIBox box = ORK.GUIBoxes.Create(this.boxID);
			box.inPause = true;
			box.controlable = false;
			box.Content = new ImageContent(this.image);
			box.InitIn();
			return box;
		}
	}
}
