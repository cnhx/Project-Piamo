
using ORKFramework;
using UnityEngine;

namespace ORKFramework
{
	public class StatusRequirement : BaseData
	{
		[ORKEditorHelp("Status Needed", "Which type of status will be checked.\n" +
			"- Status Value: The selected status value will be compared to a defined value.\n" +
			"- Status Effect: The selected status effect must or mustn't be applied to the combatant.\n" +
			"- Attack Attribute: The selected attack attribute will be compared to a defined value.\n" +
			"- Defence Attribute: The combatant must have the selected defence attribute, or compares it to a defined value.\n" +
			"- Level: The combatants level (or class level) will be compared to a defined value.\n" +
			"- Ability: The combatant must have this ability.\n" +
			"- Class: The combatant must be of the selected class.\n" +
			"- Death: The combatant must be dead/alive.", "")]
		public StatusNeeded statusNeeded = StatusNeeded.StatusValue;
		
		[ORKEditorHelp("Selection", "Select the needed status value, attack/defence attribute, ability or class.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="statusNeeded")]
		[ORKEditorLayout(new string[] {"statusNeeded", "statusNeeded"}, 
			new System.Object[] {StatusNeeded.Level, StatusNeeded.Death}, needed=Needed.One, 
			elseCheckGroup=true, endCheckGroup=true)]
		public int selectionID = 0;
		
		[ORKEditorHelp("Attribute", "Select the needed attribute.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="statusNeeded", idFieldName="selectionID")]
		[ORKEditorLayout(new string[] {"statusNeeded", "statusNeeded"}, 
			new System.Object[] {StatusNeeded.AttackAttribute, StatusNeeded.DefenceAttribute}, 
			needed=Needed.One, endCheckGroup=true)]
		public int selectionID2 = 0;
		
		[ORKEditorHelp("Check Value", "Check the current value of the selected defence attribute.\n" +
			"If disabled, the combatant's current defence attribute is checked.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.DefenceAttribute, endCheckGroup=true, 
			setDefault=true, defaultValue=false)]
		public bool checkDefAttrVal = false;
		
		
		// comparison
		[ORKEditorHelp("Comparison", "The selected status value, attack attribute or " +
			"level is equal, not equal, less or greater than the defined value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(new string[] {"statusNeeded", "statusNeeded", "statusNeeded", "checkDefAttrVal"}, 
			new System.Object[] {StatusNeeded.StatusValue, StatusNeeded.AttackAttribute, StatusNeeded.Level, true}, 
			needed=Needed.One)]
		public ValueCheck comparison = ValueCheck.IsEqual;
		
		[ORKEditorHelp("Compare With Other", "Compares the selected status value with the current value of another status value.\n" +
			"If disabled, the status value is compared with a defined value.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.StatusValue, setDefault=true, defaultValue=false)]
		public bool compareWithOther = false;
		
		[ORKEditorHelp("Other Status Value", "Select the status value that will be used for the comparison.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue)]
		[ORKEditorLayout("compareWithOther", true, endCheckGroup=true, endGroups=2)]
		public int otherStatusValueID = 0;
		
		[ORKEditorHelp("Value", "The value that will be used for the comparison.", "")]
		[ORKEditorLayout("compareWithOther", false, endCheckGroup=true, endGroups=2)]
		public float value = 0;
		
		[ORKEditorHelp("Check In", "The value is either in percent of the maximum status value or an absolute value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(new string[] {"compareWithOther", "statusNeeded"}, 
			new System.Object[] {false, StatusNeeded.StatusValue}, endCheckGroup=true, 
			setDefault=true, defaultValue=ValueSetter.Value)]
		public ValueSetter setter = ValueSetter.Value;
		
		[ORKEditorHelp("Class Level", "If enabled, the combatants class level will be used instead of the base level.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.Level, endCheckGroup=true)]
		public bool classLevel = false;
		
		
		// ability
		[ORKEditorHelp("Level", "The level of the ability that will be checked for.\n" +
			"The combatant must have at least the defined ability level.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.Ability)]
		[ORKEditorLimit(1, false)]
		public int level = 1;
		
		[ORKEditorHelp("Knows Ability", "The combatant must know the ability (i.e. learned or temporary).\n" +
			"If disabled, the combatant mustn't know the ability.", "")]
		public bool knowsAbility = true;
		
		[ORKEditorHelp("Learned", "The ability has to be learned by the combatant (i.e. not an equipment ability).\n" +
			"If disabled, all abilities of the combatant are valid.", "")]
		[ORKEditorLayout("knowsAbility", true, endCheckGroup=true, endGroups=2)]
		public bool learned = false;
		
		
		// status effect
		[ORKEditorHelp("Is Applied", "The selected status effect must be applied.\n" +
			"If disabled, the effect mustn't be applied.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.StatusEffect, endCheckGroup=true)]
		public bool applied = false;
		
		
		// death
		[ORKEditorHelp("Is Dead", "The combatant must be dead.\n" +
			"If disabled, the combatant must be alive.", "")]
		[ORKEditorLayout("statusNeeded", StatusNeeded.Death, endCheckGroup=true)]
		public bool isDead = false;
		
		public StatusRequirement()
		{
			
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return this.statusNeeded.ToString();
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CheckRequirement(Combatant c)
		{
			if(StatusNeeded.StatusValue.Equals(this.statusNeeded))
			{
				return c.Status[this.selectionID].CompareTo(
					this.compareWithOther ? c.Status[this.otherStatusValueID].GetValue() : (int)this.value, 
					this.comparison, this.setter, c);
			}
			else if(StatusNeeded.StatusEffect.Equals(this.statusNeeded))
			{
				return this.applied == c.Status.IsEffectSet(this.selectionID);
			}
			else if(StatusNeeded.AttackAttribute.Equals(this.statusNeeded))
			{
				return ValueHelper.CheckValue(
					c.Status.GetAttackAttribute(this.selectionID).GetValue(this.selectionID2), 
					this.value, this.comparison);
			}
			else if(StatusNeeded.DefenceAttribute.Equals(this.statusNeeded))
			{
				if(this.checkDefAttrVal)
				{
					return ValueHelper.CheckValue(
						c.Status.GetDefenceAttribute(this.selectionID).GetValue(this.selectionID2), 
						this.value, this.comparison);
				}
				else
				{
					return c.Status.GetDefenceAttributeID(this.selectionID).GetID() == this.selectionID2;
				}
			}
			else if(StatusNeeded.Ability.Equals(this.statusNeeded))
			{
				return (this.knowsAbility && 
						((this.learned && c.Abilities.HasLearned(this.selectionID, this.level)) ||
						(!this.learned && c.Abilities.Has(this.selectionID, this.level)))) ||
					(!this.knowsAbility && !c.Abilities.Has(this.selectionID, this.level));
			}
			else if(StatusNeeded.Level.Equals(this.statusNeeded))
			{
				return ValueHelper.CheckValue(
					this.classLevel ? c.ClassLevel : c.Level, 
					this.value, this.comparison);
			}
			else if(StatusNeeded.Class.Equals(this.statusNeeded))
			{
				return c.ClassID == this.selectionID;
			}
			else if(StatusNeeded.Death.Equals(this.statusNeeded))
			{
				return c.Dead == this.isDead;
			}
			return false;
		}
		
		public bool CheckRequirementPreview(Combatant c)
		{
			if(StatusNeeded.StatusValue.Equals(this.statusNeeded))
			{
				return c.Status[this.selectionID].CompareToPreview(
					this.compareWithOther ? 
						c.Status[this.otherStatusValueID].GetPreviewValue(false) : 
						(int)this.value, 
					this.comparison, this.setter, c);
			}
			else if(StatusNeeded.StatusEffect.Equals(this.statusNeeded))
			{
				return this.applied == c.Status.IsEffectSet(this.selectionID);
			}
			else if(StatusNeeded.AttackAttribute.Equals(this.statusNeeded))
			{
				return ValueHelper.CheckValue(
					c.Status.GetAttackAttribute(this.selectionID).GetPreviewValue(this.selectionID2), 
					this.value, this.comparison);
			}
			else if(StatusNeeded.DefenceAttribute.Equals(this.statusNeeded))
			{
				if(this.checkDefAttrVal)
				{
					return ValueHelper.CheckValue(
						c.Status.GetDefenceAttribute(this.selectionID).GetPreviewValue(this.selectionID2), 
						this.value, this.comparison);
				}
				else
				{
					return c.Status.GetDefenceAttributeID(this.selectionID).GetID() == this.selectionID2;
				}
			}
			else if(StatusNeeded.Ability.Equals(this.statusNeeded))
			{
				return (this.knowsAbility && 
						((this.learned && c.Abilities.HasLearned(this.selectionID, this.level)) ||
						(!this.learned && c.Abilities.Has(this.selectionID, this.level)))) ||
					(!this.knowsAbility && !c.Abilities.Has(this.selectionID, this.level));
			}
			else if(StatusNeeded.Level.Equals(this.statusNeeded))
			{
				return ValueHelper.CheckValue(
					this.classLevel ? c.ClassLevel : c.Level, 
					this.value, this.comparison);
			}
			else if(StatusNeeded.Class.Equals(this.statusNeeded))
			{
				return c.ClassID == this.selectionID;
			}
			else if(StatusNeeded.Death.Equals(this.statusNeeded))
			{
				return c.Dead == this.isDead;
			}
			return false;
		}
		
		public static bool Check(Combatant combatant, StatusRequirement[] req, Needed needed)
		{
			if(req.Length > 0)
			{
				for(int i=0; i<req.Length; i++)
				{
					if(req[i].CheckRequirement(combatant))
					{
						if(Needed.One.Equals(needed))
						{
							return true;
						}
					}
					else if(Needed.All.Equals(needed))
					{
						return false;
					}
				}
				if(Needed.All.Equals(needed))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}
		
		public static bool CheckPreview(Combatant combatant, StatusRequirement[] req, Needed needed)
		{
			if(req.Length > 0)
			{
				for(int i=0; i<req.Length; i++)
				{
					if(req[i].CheckRequirementPreview(combatant))
					{
						if(Needed.One.Equals(needed))
						{
							return true;
						}
					}
					else if(Needed.All.Equals(needed))
					{
						return false;
					}
				}
				if(Needed.All.Equals(needed))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return true;
			}
		}
		
		
		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public bool RegisterStatusChanges(Combatant c, IStatusChanged notify)
		{
			if(StatusNeeded.StatusValue.Equals(this.statusNeeded))
			{
				StatusValue sv = c.Status[this.selectionID];
				sv.Changed += notify.StatusValueChanged;
				if(sv.IsConsumable())
				{
					c.Status[sv.Setting.maxStatusID].Changed += notify.StatusValueChanged;
				}
				return true;
			}
			else if(StatusNeeded.StatusEffect.Equals(this.statusNeeded))
			{
				c.Status.StatusEffectChanged += notify.StatusEffectChanged;
				return true;
			}
			else if(StatusNeeded.AttackAttribute.Equals(this.statusNeeded))
			{
				c.Status.GetAttackAttribute(this.selectionID).Changed += notify.AttackAttributeChanged;
				return true;
			}
			else if(StatusNeeded.DefenceAttribute.Equals(this.statusNeeded))
			{
				if(this.checkDefAttrVal)
				{
					c.Status.GetDefenceAttribute(this.selectionID).Changed += notify.DefenceAttributeChanged;
				}
				else
				{
					c.Status.GetDefenceAttributeID(this.selectionID).Changed += notify.DefenceAttributeIDChanged;
				}
				return true;
			}
			else if(StatusNeeded.Ability.Equals(this.statusNeeded))
			{
				c.Abilities.AbilitiesChanged += notify.AbilitiesChanged;
				return true;
			}
			else if(StatusNeeded.Level.Equals(this.statusNeeded))
			{
				if(this.classLevel)
				{
					c.ClassLevelChanged += notify.ClassLevelChanged;
				}
				else
				{
					c.LevelChanged += notify.LevelChanged;
				}
				return true;
			}
			else if(StatusNeeded.Class.Equals(this.statusNeeded))
			{
				c.ClassChanged += notify.ClassChanged;
				return true;
			}
			return false;
		}
		
		public bool UnregisterStatusChanges(Combatant c, IStatusChanged notify)
		{
			if(StatusNeeded.StatusValue.Equals(this.statusNeeded))
			{
				StatusValue sv = c.Status[this.selectionID];
				sv.Changed -= notify.StatusValueChanged;
				if(sv.IsConsumable())
				{
					c.Status[sv.Setting.maxStatusID].Changed -= notify.StatusValueChanged;
				}
				return true;
			}
			else if(StatusNeeded.StatusEffect.Equals(this.statusNeeded))
			{
				c.Status.StatusEffectChanged -= notify.StatusEffectChanged;
				return true;
			}
			else if(StatusNeeded.AttackAttribute.Equals(this.statusNeeded))
			{
				c.Status.GetAttackAttribute(this.selectionID).Changed -= notify.AttackAttributeChanged;
				return true;
			}
			else if(StatusNeeded.DefenceAttribute.Equals(this.statusNeeded))
			{
				if(this.checkDefAttrVal)
				{
					c.Status.GetDefenceAttribute(this.selectionID).Changed -= notify.DefenceAttributeChanged;
				}
				else
				{
					c.Status.GetDefenceAttributeID(this.selectionID).Changed -= notify.DefenceAttributeIDChanged;
				}
				return true;
			}
			else if(StatusNeeded.Ability.Equals(this.statusNeeded))
			{
				c.Abilities.AbilitiesChanged -= notify.AbilitiesChanged;
				return true;
			}
			else if(StatusNeeded.Level.Equals(this.statusNeeded))
			{
				if(this.classLevel)
				{
					c.ClassLevelChanged -= notify.ClassLevelChanged;
				}
				else
				{
					c.LevelChanged -= notify.LevelChanged;
				}
				return true;
			}
			else if(StatusNeeded.Class.Equals(this.statusNeeded))
			{
				c.ClassChanged -= notify.ClassChanged;
				return true;
			}
			return false;
		}
	}
}
