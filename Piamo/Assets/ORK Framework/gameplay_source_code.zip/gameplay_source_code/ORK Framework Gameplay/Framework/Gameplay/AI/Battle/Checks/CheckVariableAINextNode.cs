
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	[System.Serializable]
	public class CheckVariableAINextNode : CheckVariableBase
	{
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		public CheckVariableAINextNode()
		{
			
		}
	}
}
