
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ChangeMemberAction : BaseAction
	{
		private Combatant newUser = null;
		
		private bool membersChanged = false;
		
		public ChangeMemberAction(Combatant user, Combatant newUser)
		{
			this.user = user;
			this.newUser = newUser;
			this.target = new List<Combatant>();
			this.target.Add(user);
			
			if(ORK.BattleSystem.activeTime.changeEndTurn)
			{
				this.timeUse = ORK.BattleSystem.activeTime.actionBorder;
			}
			else
			{
				this.timeUse = ORK.BattleSystem.activeTime.changeTimebarUse;
			}
		}
		
		public override bool IsType(ActionType t)
		{
			return ActionType.ChangeMember.Equals(t);
		}
		
		
		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		protected override bool PerformCheck()
		{
			return this.user != null && !this.user.Dead && 
				!this.user.Status.StopMove && 
				this.newUser != null && !this.newUser.Dead && 
				!this.newUser.Status.StopMove;
		}
		
		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.changeMemberInfo.Show(this.user, this.newUser.GetName());
			}
			
			if(ORK.ConsoleSettings.displayActions)
			{
				List<Combatant> tmp = new List<Combatant>();
				tmp.Add(this.newUser);
				if(this.user.Setting.ownConsoleChangeMember)
				{
					this.user.Setting.consoleChangeMember.Print(this.user, tmp, null);
				}
				else
				{
					ORK.ConsoleSettings.actionChangeMember.Print(this.user, tmp, null);
				}
			}
			
			this.newUser.StartBattle();
			
			this.user.GetRetreatEvent(ref this.events);
			this.newUser.GetEnterBattleEvent(ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			if(!this.membersChanged && this.newUser != null)
			{
				if(ORK.Battle.BattleArena != null)
				{
					ORK.Battle.BattleArena.SetSpot(this.user, this.newUser);
				}
				this.newUser.BattleSpot = this.user.BattleSpot;
				this.newUser.TimeBar = this.user.TimeBar;
				this.newUser.UsedTimeBar = this.user.UsedTimeBar;
				this.newUser.TurnValue = this.user.TurnValue;
				this.newUser.TurnValueDummy = this.user.TurnValueDummy;
				
				this.user.Group.ChangeBattle(this.user, this.newUser);
				this.user.EndBattle();
				
				// notify battle
				ORK.Battle.CombatantChanged(this.user, this.newUser);
				
				this.membersChanged = true;
				
				Combatant tmp = this.user;
				this.user = this.newUser;
				this.newUser = tmp;
			}
		}

		protected override void ActionEndSetup()
		{
			
		}
	}
}
