
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu
{
	public delegate bool AddQuantity(IShortcut shortcut, bool showNotification, bool showConsole);
	
	public delegate void RemoveQuantity(IShortcut shortcut, int quantity, bool showNotification, bool showConsole);
	
	public delegate void MoneyQuantity(int currencyID, int quantity, bool showNotification, bool showConsole);
	
	public class QuantityData
	{
		public IQuantityCallback callback;
		
		public IShortcut shortcut;
		
		public int maxQuantity = -1;
		
		public int availableQuantity = 0;
		
		public int currencyID = 0;
		
		public int availableCurrency = 0;
		
		public int price = 1;
		
		public QuantitySelectionMode mode;
		
		
		// delegate functions
		public AddQuantity add;
		
		public RemoveQuantity remove;
		
		public MoneyQuantity addMoney;
		
		public MoneyQuantity removeMoney;
		
		public QuantityData(IQuantityCallback callback, IShortcut shortcut, int maxQuantity, int availableQuantity, 
			int currencyID, int availableCurrency, int price, QuantitySelectionMode mode, AddQuantity add) : 
			this(callback, shortcut, maxQuantity, availableQuantity, currencyID, availableCurrency, price, mode, add, null, null, null)
		{
			
		}
		
		public QuantityData(IQuantityCallback callback, IShortcut shortcut, int maxQuantity, int availableQuantity, 
			int currencyID, int availableCurrency, int price, QuantitySelectionMode mode, AddQuantity add, RemoveQuantity remove) : 
			this(callback, shortcut, maxQuantity, availableQuantity, currencyID, availableCurrency, price, mode, add, remove, null, null)
		{
			
		}
		
		public QuantityData(IQuantityCallback callback, IShortcut shortcut, int maxQuantity, int availableQuantity, 
			int currencyID, int availableCurrency, int price, QuantitySelectionMode mode, 
			AddQuantity add, RemoveQuantity remove, MoneyQuantity addMoney, MoneyQuantity removeMoney)
		{
			this.callback = callback;
			this.shortcut = shortcut;
			this.maxQuantity = maxQuantity;
			this.availableQuantity = availableQuantity;
			this.currencyID = currencyID;
			this.availableCurrency = availableCurrency;
			this.price = price;
			this.mode = mode;
			this.add = add;
			this.remove = remove;
			this.addMoney = addMoney;
			this.removeMoney = removeMoney;
		}
		
		public void Execute(int quantity)
		{
			if(quantity > 0)
			{
				bool added = true;
				if(this.add != null)
				{
					added = this.add(this.shortcut.GetCopy(quantity), true, true);
					if(!added)
					{
						quantity = 0;
					}
				}
				if(this.remove != null && added)
				{
					this.remove(this.shortcut, quantity, true, true);
				}
				
				if(added && (QuantitySelectionMode.Buy.Equals(this.mode) || 
					QuantitySelectionMode.Sell.Equals(this.mode)))
				{
					if(this.addMoney != null)
					{
						this.addMoney(this.currencyID, this.price * quantity, true, true);
					}
					if(this.removeMoney != null)
					{
						this.removeMoney(this.currencyID, this.price * quantity, true, true);
					}
				}
			}
			
			if(this.callback != null)
			{
				this.callback.QuantityCallback(this.shortcut, quantity, this.mode);
			}
		}
		
		public void Cancel()
		{
			if(this.callback != null)
			{
				this.callback.QuantityCallback(this.shortcut, -1, this.mode);
			}
		}
	}
}
