
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework
{
	public class PortraitType : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of this portrait type.", "")]
		[ORKEditorInfo("Base Settings", "Set the name of this portrait type.", "", 
			expandWidth=true, endFoldout=true)]
		public string name = "";

		public PortraitType()
		{
			
		}
		
		public PortraitType(string name)
		{
			this.name = name;
		}
	}
}
