
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class GlobalEvent : BaseIndexData, IEventStarter
	{
		[ORKEditorHelp("Name", "The name of the global event.", "")]
		[ORKEditorInfo("Event Settings", "The actual global event that will be executed is a normal game event.\n" +
			"Note that global events don't support actors, waypoints, prefabs and audio clips that would be added " +
			"to the event interaction in a scene.", "", expandWidth=true)]
		public string name = "";
		
		// event data
		[ORKEditorHelp("Event Asset", "Select the ORK game event asset this global event will use.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public ORKGameEvent eventAsset;
		
		
		// execution data
		[ORKEditorHelp("Event Type", "The type of the global event decides how it will start:\n" +
			"- Call: The event has to be called by other events to execute.\n" +
			"- Auto: The event runs automatically on certain condition. It will be checked frequently.\n" +
			"- Key: The event runs if a key is pressed (only when the player can be controlled).\n" +
			"- Scene: The event runs when changing the scene.\n" +
			"Note that all events can be called from other events.", "")]
		[ORKEditorInfo("Event Execution", "The event execution and condition settings.", "", 
			labelText="Execution Settings", isEnumToolbar=true, toolbarWidth=75)]
		public GlobalEventType type = GlobalEventType.Call;
		
		// auto events
		[ORKEditorHelp("Check Timeout (s)", "The time in seconds between two checks of the execution conditions.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", GlobalEventType.Auto, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float timeout = 1;
		
		// key
		[ORKEditorHelp("Call Key", "Select the key used to call this global event.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, separator=true)]
		[ORKEditorLayout("type", GlobalEventType.Key, endCheckGroup=true)]
		public int keyID = 0;
		
		// scene change
		[ORKEditorHelp("In Old Scene", "The event runs in the old scene.\n" +
			"If disabled, the event will run in the new scene.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", GlobalEventType.Scene)]
		public bool inOldScene = false;
		
		[ORKEditorHelp("Before Fade", "The event runs before fading, " +
			"i.e. either before fading out when using 'In Old Scene' or before fading in in the new scene.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool beforeFade = false;
		
		// game state
		[ORKEditorInfo(separator=true, labelText="Required Game State")]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {GlobalEventType.Auto, GlobalEventType.Key}, 
			needed=Needed.One, endCheckGroup=true)]
		public GameState gameState = new GameState();
		
		// variable conditions
		[ORKEditorInfo(separator=true, labelText="Variable Conditions", endFoldout=true)]
		[ORKEditorLayout("type", GlobalEventType.Call, elseCheckGroup=true, endCheckGroup=true)]
		public VariableCondition variables = new VariableCondition();
		
		
		// ingame
		private GameEvent gameEvent;
		
		private float timer = 0;

		private bool eventStarted = false;

		private bool eventFinished = false;
		
		public GlobalEvent()
		{
			
		}
		
		public GlobalEvent(string n)
		{
			this.name = n;
		}
		
		public bool LoadEvent()
		{
			this.gameEvent = null;
			if(this.eventAsset != null)
			{
				this.gameEvent = new GameEvent();
				this.gameEvent.SetData(this.eventAsset.GetData().ToDataObject());
				if(this.gameEvent != null)
				{
					return true;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Event execution functions
		============================================================================
		*/
		public bool IsCallType()
		{
			return GlobalEventType.Call.Equals(this.type);
		}
		
		public bool IsAutoType()
		{
			return GlobalEventType.Auto.Equals(this.type);
		}
		
		public bool IsKeyType()
		{
			return GlobalEventType.Key.Equals(this.type);
		}
		
		public bool IsSceneType()
		{
			return GlobalEventType.Scene.Equals(this.type);
		}
		
		public bool IsFinished()
		{
			return this.eventFinished;
		}
		
		public void Tick(float delta)
		{
			if(this.eventStarted)
			{
				this.gameEvent.Tick(delta);
			}
			else
			{
				if(this.IsAutoType())
				{
					this.timer += delta;
					
					if(this.timer >= this.timeout)
					{
						// try starting event
						if(this.gameState.Check() && this.variables.CheckVariables())
						{
							this.LoadEvent();
							if(this.gameEvent != null)
							{
								this.eventStarted = true;
								this.gameEvent.StartEvent(this, ORK.Game.GetPlayer());
							}
						}
						this.timer = 0;
					}
				}
				else if(this.IsKeyType() && 
					ORK.InputKeys.Get(this.keyID).GetButton() && 
					this.gameState.Check() && this.variables.CheckVariables())
				{
					this.LoadEvent();
					if(this.gameEvent != null)
					{
						this.eventStarted = true;
						this.gameEvent.StartEvent(this, ORK.Game.GetPlayer());
					}
				}
			}
		}
		
		public bool Call()
		{
			this.LoadEvent();
			if(this.gameEvent != null && !this.eventStarted)
			{
				this.eventStarted = true;
				this.gameEvent.StartEvent(this, ORK.Game.GetPlayer());
				return true;
			}
			return false;
		}
		
		public void EventEnded()
		{
			this.eventStarted = false;
			this.eventFinished = true;
		}
		
		public void DontDestroy()
		{
			
		}
		
		public GameObject GameObject
		{
			get{ return null;}
		}
	}
}
