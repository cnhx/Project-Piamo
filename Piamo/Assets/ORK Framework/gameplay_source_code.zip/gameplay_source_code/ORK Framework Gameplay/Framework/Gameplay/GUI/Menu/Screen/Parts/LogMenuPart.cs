
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu.Parts
{
	[ORKEditorHelp("Log", "Displays know logs.\n" +
			"The logs can be separated by log type.", "")]
	public class LogMenuPart : BaseMenuPart, IChoice, ITabChoice
	{
		// type settings
		// available types
		[ORKEditorHelp("All Log Types", "All log types will be available.\n" +
			"If disabled, you have to select the log types that will be available.", "")]
		[ORKEditorInfo("Available Log Types", "Define what log types will be displayed in this menu screen.", "")]
		public bool allTypes = true;
		
		public TypeSorter typeSorter = new TypeSorter();
		
		[ORKEditorHelp("Log Type", "Select the log type that will be available.", "")]
		[ORKEditorInfo(ORKDataType.LogType, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Log Type", "Adds a log type that will be available.", "", 
			"Remove", "Removes this log type.", "", noRemoveCount=1, isHorizontal=true)]
		[ORKEditorLayout("allTypes", false, endCheckGroup=true, autoInit=true, autoSize=1)]
		public int[] availableTypeID;
		
		
		
		// type box settings
		[ORKEditorHelp("Show Type Box", "A type selection box is displayed.\n" +
			"If disabled, no type selection box is displayed, " +
			"but you can change the type using the change type keys.", "")]
		[ORKEditorInfo("Type Box Settings", "Define the content and layout of the log type box.", "")]
		public bool showTypeBox = true;
		
		[ORKEditorHelp("Show Empty Types", "Empty log types (without any known logs) will be displayed (with inactive buttons).\n" +
			"If disabled, only the log types with known logs will be displayed.", "")]
		public bool showEmptyTypes = false;
		
		[ORKEditorHelp("Merge Types", "Merge all log types into a single display.\n" +
			"If disabled, only a single log type will be displayed at a time - " +
			"you can use the type change keys to circle through available types.", "")]
		[ORKEditorLayout("showTypeBox", false, setDefault=true, defaultValue=false)]
		public bool mergeTypes = false;
		
		[ORKEditorHelp("Type Tabs", "Show the log types as tabs in the log box.", "")]
		[ORKEditorLayout("mergeTypes", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool typeTabs = false;
		
		[ORKEditorHelp("Display Type>Log", "Select the box display mode (Type to Log):\n" +
			"- Same: Types and logs use the same GUI box.\n" +
			"- One: Only one box will be displayed at a time. Types and logs use different GUI boxes.\n" +
			"- Multi: Multiple boxes are displayed at the same time. Types and logs use different GUI boxes.\n" +
			"- Sequence: Same as 'Multi', but the logs will only be displayed when a type was selected.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75)]
		[ORKEditorLayout(elseCheckGroup=true, setDefault=true, defaultValue=MenuBoxDisplay.Multi)]
		public MenuBoxDisplay display = MenuBoxDisplay.Multi;
		
		[ORKEditorHelp("Type Box", "Select the GUI box used to display the log types.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("display", MenuBoxDisplay.Same, elseCheckGroup=true, endCheckGroup=true)]
		public int guiBoxID = 0;
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the log type list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBackType = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the log type list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBackType", true, endCheckGroup=true)]
		public bool backFirstType = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used type GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		[ORKEditorLayout(setDefault=true, defaultValue=false)]
		public bool useTypeTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTypeTitle", true, endCheckGroup=true, endGroups=2, autoInit=true, autoLangSize=true)]
		public string[] typeTitle;
		
		// layout
		[ORKEditorInfo("Type Content Layout", "Define the layout of the log type buttons.", "", 
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(new string[] {"showTypeBox", "typeTabs"}, new System.Object[] {true, true}, 
			needed=Needed.One, endCheckGroup=true)]
		public ContentLayout typeContentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		
		
		// log box settings
		[ORKEditorHelp("Display Log>Text", "Select the box display mode (Log to Text):\n" +
			"- Same: Logs and texts use the same GUI box.\n" +
			"- One: Only one box will be displayed at a time. Logs and texts use different GUI boxes.\n" +
			"- Multi: Multiple boxes are displayed at the same time. Logs and texts use different GUI boxes.\n" +
			"- Sequence: Same as 'Multi', but the texts will only be displayed when a log was selected.", "")]
		[ORKEditorInfo("Log Box Settings", "Define the content and layout of the log box.", "", 
			isEnumToolbar=true, toolbarWidth=75)]
		public MenuBoxDisplay displayText = MenuBoxDisplay.Multi;
		
		[ORKEditorHelp("Log Box", "Select the GUI box used to display the logs.\n" +
			"If 'Same' box display is selected, this box will also display the log types.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("displayText", MenuBoxDisplay.Same, elseCheckGroup=true, endCheckGroup=true)]
		public int guiBoxID2 = 0;
		
		[ORKEditorInfo(separator=true)]
		public ContentSorter contentSorter = new ContentSorter();
		
		// back button
		[ORKEditorHelp("Add Back", "A back button will be added to the log list.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addBack = false;
		
		[ORKEditorHelp("First Element", "The back button will be the first element in the log list.\n" +
			"If disabled, the back button will be the last element.", "")]
		[ORKEditorLayout("addBack", true, endCheckGroup=true)]
		public bool backFirst = false;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used log GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the description box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {
			"%n = type name (only if 'Merge Types' isn't selected)"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		// layout
		[ORKEditorInfo("Log Content Layout", "Define the layout of the log buttons.", "", 
			endFoldout=true, endFolds=2)]
		public ContentLayout contentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.None);
		
		
		
		// text box settings
		[ORKEditorHelp("Text Box", "Select the GUI box used to display the a selected log's text.\n" +
			"If 'Same' box display is selected, this box will also display the logs.", "")]
		[ORKEditorInfo("Text Box Settings", "Define the content and layout of the text box.", "", 
			isPopup=true, popupType=ORKDataType.GUIBox)]
		public int guiBoxID3 = 0;
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used log GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Title Settings")]
		public bool useTextTitle = false;
		
		[ORKEditorHelp("Title", "The title of the description box.", "")]
		[ORKEditorInfo(expandWidth=true, endFoldout=true, label=new string[] {"%n = log name"})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTextTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] textTitle;
		
		
		
		// switch type keys
		[ORKEditorHelp("Use Change Keys", "The log type can be changed by input keys.", "")]
		[ORKEditorInfo("Type Change Keys", "The log type can be changed by input keys.", "")]
		[ORKEditorLayout("mergeTypes", false, setDefault=true, defaultValue=false)]
		public bool useTypeKeys = false;
		
		[ORKEditorHelp("Next Type", "Select the key used to select the next log type.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useTypeKeys", true)]
		public int nextTypeKey = 0;
		
		[ORKEditorHelp("Previous Type", "Select the key used to select the previous log type.", "")]
		[ORKEditorInfo(ORKDataType.InputKey, endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public int prevTypeKey = 0;
		
		
		// ingame
		private GUIBox box;
		
		private GUIBox box2;
		
		private GUIBox box3;
		
		private int tmpTypeID = 0;
		
		private int current = 0;
		
		private int current2 = 0;
		
		private bool exitFlag = false;
		
		private int nextBox = 0;
		
		
		// log types
		private ChoiceContent[] typeChoice;
		
		private int[] typeAction;
		
		private List<int> logTypes;
		
		
		// logs
		private ChoiceContent[] logChoice;
		
		private List<Log> logs;
		
		
		// texts
		private string logTextTitle = "";
		
		private string logTextContent = "";
		
		public LogMenuPart()
		{
			
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return this.box3 == origin;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return this.box3 == origin;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public override bool Controlable
		{
			get{ return this.IsOpened;}
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsOpened
		{
			get
			{
				return (this.box == null || this.box.FadedIn) && 
					(this.box2 == null || this.box2.FadedIn) && 
						(this.box3 == null || this.box3.FadedIn);
			}
		}
		
		public override bool IsClosed
		{
			get{ return this.box == null && this.box2 == null && this.box3 == null;}
		}
		
		public bool Tick(GUIBox origin)
		{
			if(this.useTypeKeys)
			{
				if(ORK.InputKeys.Get(this.nextTypeKey).GetButton())
				{
					this.ChangeTypeKey(1, origin);
					return true;
				}
				else if(ORK.InputKeys.Get(this.prevTypeKey).GetButton())
				{
					this.ChangeTypeKey(-1, origin);
					return true;
				}
				
			}
			return false;
		}
		
		private void ChangeTypeKey(int change, GUIBox origin)
		{
			origin.Audio.PlayCursorMove();
			if(this.showTypeBox)
			{
				int index = this.current + change;
				if(index < 0)
				{
					index = this.typeChoice.Length - 1;
				}
				else if(index >= this.typeChoice.Length)
				{
					index = 0;
				}
				
				if(this.box != null)
				{
					this.box.Content.Selection = index;
				}
				if(this.box2 == origin)
				{
					this.ShowLogs();
					this.SelectionChanged(this.current2, this.box2);
				}
			}
			else if(this.box2 == origin)
			{
				this.CreateTypeList();
				
				int index = 0;
				for(int i=0; i<this.logTypes.Count; i++)
				{
					if(this.logTypes[i] == this.tmpTypeID)
					{
						index = i;
						break;
					}
				}
				index += change;
				if(index < 0)
				{
					index = this.logTypes.Count - 1;
				}
				else if(index >= this.logTypes.Count)
				{
					index = 0;
				}
				this.tmpTypeID = this.logTypes[index];
				this.ShowLogs();
				this.SelectionChanged(this.current2, this.box2);
			}
		}
		
		
		/*
		============================================================================
		Choice creation functions
		============================================================================
		*/
		private void CreateTypeList()
		{
			if(this.allTypes)
			{
				if(this.showEmptyTypes)
				{
					this.logTypes = new List<int>();
					for(int i=0; i<ORK.LogTypes.Count; i++)
					{
						this.logTypes.Add(i);
					}
				}
				else
				{
					this.logTypes = ORK.Game.Logs.GetTypes();
				}
			}
			else
			{
				if(this.showEmptyTypes)
				{
					this.logTypes = new List<int>(this.availableTypeID);
				}
				else
				{
					this.logTypes = new List<int>();
					for(int i=0; i<this.availableTypeID.Length; i++)
					{
						if(ORK.Game.Logs.HasType(this.availableTypeID[i]))
						{
							this.logTypes.Add(this.availableTypeID[i]);
						}
					}
				}
			}
			this.typeSorter.Sort(ref this.logTypes, ORKDataType.LogType);
		}
		
		private void CreateTypeChoices()
		{
			this.typeChoice = null;
			this.typeAction = null;
			
			this.CreateTypeList();
			
			List<ChoiceContent> cc = new List<ChoiceContent>();
			List<int> ca = new List<int>();
			
			// back first
			if(this.addBackType && this.backFirstType)
			{
				cc.Add(this.typeContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
				ca.Add(-1);
			}
			
			// types
			for(int i=0; i<this.logTypes.Count; i++)
			{
				ChoiceContent content = this.typeContentLayout.GetChoiceContent(ORK.LogTypes.Get(this.logTypes[i]));
				if(this.showEmptyTypes)
				{
					content.active = ORK.Game.Logs.HasType(this.logTypes[i]);
				}
				cc.Add(content);
				ca.Add(this.logTypes[i]);
			}
			
			// back last
			if(this.addBackType && !this.backFirstType)
			{
				cc.Add(this.typeContentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
				ca.Add(-1);
			}
			
			this.typeChoice = cc.ToArray();
			this.typeAction = ca.ToArray();
		}
		
		private void CreateLogChoices()
		{
			this.logs = null;
			this.logChoice = null;
			
			if(!this.showTypeBox && !this.mergeTypes && this.typeTabs)
			{
				this.CreateTypeChoices();
			}
			
			// logs
			if((this.showTypeBox || (!this.mergeTypes && this.typeTabs)) && 
				this.current >= 0 && this.current < this.typeAction.Length && 
				this.typeAction[this.current] != -1)
			{
				this.logs = ORK.Game.Logs.GetLogsByType(this.typeAction[this.current]);
			}
			else if(!this.showTypeBox && this.mergeTypes)
			{
				this.logs = ORK.Game.Logs.GetLogsByType(-1);
			}
			else
			{
				this.logs = ORK.Game.Logs.GetLogsByType(this.tmpTypeID);
			}
			
			if(this.logs != null)
			{
				this.contentSorter.Sort(ref this.logs);
				
				List<ChoiceContent> cc = new List<ChoiceContent>();
				
				// back first
				if(this.addBack && this.backFirst)
				{
					cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
					this.logs.Insert(0, null);
				}
				
				// logs
				for(int i=0; i<this.logs.Count; i++)
				{
					if(this.logs[i] != null)
					{
						cc.Add(this.contentLayout.GetChoiceContent(this.logs[i]));
					}
				}
				
				// back last
				if(this.addBack && !this.backFirst)
				{
					cc.Add(this.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton));
					this.logs.Add(null);
				}
				
				this.logChoice = cc.ToArray();
			}
		}
		
		private void CreateText()
		{
			this.logTextTitle = "";
			this.logTextContent = "";
			
			if(this.logs != null && 
				this.current2 >= 0 && this.current2 < this.logs.Count && 
				this.logs[this.current2] != null)
			{
				ORK.Game.Logs.GetLogContent(this.logs[this.current2].ID, ref this.logTextTitle, ref this.logTextContent);
			}
		}
		
		
		/*
		============================================================================
		Screen functions
		============================================================================
		*/
		public override bool ShowFirstDescription()
		{
			if(this.box != null && this.typeChoice != null && 
				this.current >= 0 && this.current < this.typeChoice.Length)
			{
				this.screen.ShowDescription(
					this.typeChoice[this.current].description, 
					this.typeChoice[this.current].Content.text, 
					this.typeAction[this.current] != -1 ? 
						ORK.LogTypes.Get(this.typeAction[this.current]) : null);
				return true;
			}
			if(this.box2 != null && this.logChoice != null && 
				this.current2 >= 0 && this.current2 < this.logChoice.Length)
			{
				this.screen.ShowDescription(
					this.logChoice[this.current2].description, 
					this.logChoice[this.current2].Content.text, 
					this.logs[this.current2]);
				return true;
			}
			return false;
		}
		
		public override bool FocusFirst()
		{
			if(this.box != null)
			{
				this.box.SetFocus();
				return true;
			}
			else if(this.box2 != null)
			{
				this.box2.SetFocus();
				return true;
			}
			else if(this.box3 != null)
			{
				this.box3.SetFocus();
				return true;
			}
			return false;
		}
		
		public override bool IsFocused()
		{
			return (this.box != null && this.box.Focused) || 
				(this.box2 != null && this.box2.Focused) || 
				(this.box3 != null && this.box3.Focused);
		}
		
		public override void Refresh()
		{
			if(this.box != null)
			{
				this.ShowTypes();
			}
			if(this.box2 != null)
			{
				this.ShowLogs();
			}
			if(this.box3 != null)
			{
				this.ShowTexts();
			}
		}
		
		public override void Show(MenuScreen s)
		{
			this.nextBox = 0;
			this.screen = s;
			this.CreateTypeList();
			this.tmpTypeID = this.logTypes.Count > 0 ? this.logTypes[0] : 0;
			
			// logs and text share the same box
			if(MenuBoxDisplay.Same.Equals(this.displayText))
			{
				this.guiBoxID2 = this.guiBoxID3;
			}
			// types and logs share the same box
			if(this.showTypeBox && 
				MenuBoxDisplay.Same.Equals(this.display))
			{
				this.guiBoxID = this.guiBoxID2;
			}
			
			this.Show();
		}
		
		public override void ChangeCombatant(Combatant old)
		{
			
		}
		
		public override void CloseImmediate()
		{
			if(this.box != null)
			{
				this.box.SetOutDone();
				this.box = null;
			}
			if(this.box2 != null)
			{
				this.box2.SetOutDone();
				this.box2 = null;
			}
			if(this.box3 != null)
			{
				this.box3.SetOutDone();
				this.box3 = null;
			}
		}
		
		public override void Close()
		{
			this.exitFlag = true;
			if(this.box != null && !this.box.FadingOut && !this.box.FadedOut)
			{
				this.box.InitOut();
			}
			if(this.box2 != null && !this.box2.FadingOut && !this.box2.FadedOut)
			{
				this.box2.InitOut();
			}
			if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
			{
				this.box3.InitOut();
			}
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show()
		{
			if(!this.screen.RememberSelection)
			{
				this.current = 0;
				this.current2 = 0;
			}
			
			// type choice and logs
			if(this.showTypeBox)
			{
				this.ShowTypes();
				
				if(MenuBoxDisplay.Multi.Equals(this.display))
				{
					this.ShowLogs();
				}
				
				this.box.SetFocus();
				this.SelectionChanged(this.current, this.box);
			}
			// only logs
			else
			{
				this.ShowLogs();
				this.box2.SetFocus();
				this.SelectionChanged(this.current2, this.box2);
			}
		}
		
		public void FocusGained(GUIBox origin)
		{
			if(this.box == origin && 
				!this.box.FadingOut && !this.box.FadedOut)
			{
				if(MenuBoxDisplay.Sequence.Equals(this.display))
				{
					if(this.box2 != null && !this.box2.FadingOut && !this.box2.FadedOut)
					{
						this.box2.InitOut();
					}
					if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
					{
						this.box3.InitOut();
					}
				}
				
				// text box
				if(MenuBoxDisplay.Same.Equals(this.displayText) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.box2 = this.box3;
					this.box3 = null;
					this.ShowLogs();
				}
				else if(MenuBoxDisplay.Sequence.Equals(this.displayText) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.box3.InitOut();
				}
				else if(MenuBoxDisplay.One.Equals(this.displayText) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.nextBox = 4;
					this.box3.InitOut();
				}
				
				if(!this.box.FadingOut && this.typeChoice != null && 
					this.current >= 0 && this.current < this.typeChoice.Length)
				{
					this.screen.ShowDescription(
						this.typeChoice[this.current].description, 
						this.typeChoice[this.current].Content.text, 
						this.typeAction[this.current] != -1 ? 
							ORK.LogTypes.Get(this.typeAction[this.current]) : null);
				}
			}
			else if(this.box2 == origin && 
				!this.box2.FadingOut && !this.box2.FadedOut)
			{
				if(MenuBoxDisplay.Sequence.Equals(this.displayText) && 
					this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
				{
					this.box3.InitOut();
				}
				
				if(!this.box2.FadingOut && this.logChoice != null && 
					this.current2 >= 0 && this.current2 < this.logChoice.Length)
				{
					this.screen.ShowDescription(
						this.logChoice[this.current2].description, 
						this.logChoice[this.current2].Content.text, 
						this.logs[this.current2]);
				}
			}
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		private void ShowTypes()
		{
			this.CreateTypeChoices();
			
			if(this.box == null || this.box.FadingOut || this.box.FadedOut)
			{
				this.box = ORK.GUIBoxes.Create(this.guiBoxID);
				this.box.inPause = this.screen.pauseGame;
				this.box.InitIn();
			}
			
			ValueHelper.Limit(ref this.current, 0, this.typeChoice.Length - 1);
			
			if(this.box.Content == null)
			{
				this.box.Content = new DialogueContent("", 
					this.useTypeTitle ? this.typeTitle[ORK.Game.Language] : "", 
					this.typeChoice, this, this.current);
			}
			else
			{
				((DialogueContent)this.box.Content).Update("", 
					this.useTypeTitle ? this.typeTitle[ORK.Game.Language] : "", 
					this.typeChoice, this.current, null, null);
			}
			if(this.box.Focused)
			{
				this.SelectionChanged(this.current, this.box);
			}
		}
		
		private void ShowLogs()
		{
			this.CreateLogChoices();
			
			if(this.box2 == null || this.box2.FadingOut || this.box2.FadedOut)
			{
				this.box2 = ORK.GUIBoxes.Create(this.guiBoxID2);
				this.box2.inPause = this.screen.pauseGame;
				this.box2.InitIn();
			}
			
			if(this.logChoice == null)
			{
				this.current2 = 0;
			}
			else
			{
				ValueHelper.Limit(ref this.current2, 0, this.logChoice.Length - 1);
			}
			
			if(this.box2.Content == null)
			{
				this.box2.Content = new DialogueContent("", this.GetTitle(), 
					this.logChoice, this, this.current2);
			}
			else
			{
				((DialogueContent)this.box2.Content).Update("", this.GetTitle(), 
					this.logChoice, this.current2, null, null);
			}
			
			if(!this.showTypeBox && !this.mergeTypes && this.typeTabs)
			{
				this.box2.Content.SetTabs(this.typeChoice);
			}
			
			if(MenuBoxDisplay.Multi.Equals(this.displayText))
			{
				this.ShowTexts();
			}
			if(this.box2.Focused)
			{
				this.SelectionChanged(this.current2, this.box2);
			}
		}
		
		private void ShowTexts()
		{
			this.CreateText();
			
			if(this.box3 == null || this.box3.FadingOut || this.box3.FadedOut)
			{
				this.box3 = ORK.GUIBoxes.Create(this.guiBoxID3);
				this.box3.inPause = this.screen.pauseGame;
				this.box3.InitIn();
			}
			
			if(this.box3.Content == null)
			{
				this.box3.Content = new DialogueContent(this.logTextContent, this.GetTextTitle(), null, this);
			}
			else
			{
				((DialogueContent)this.box3.Content).Update(this.logTextContent, this.GetTextTitle(), 
					null, this.box3.Content.Selection, null, null);
			}
		}
		
		private string GetTitle()
		{
			if(this.useTitle)
			{
				if(this.showTypeBox && this.typeChoice != null && 
					this.current >= 0 && this.current < this.typeChoice.Length && 
					this.typeAction[this.current] != -1)
				{
					return this.title[ORK.Game.Language].Replace("%n", this.typeChoice[this.current].Content.text);
				}
				else if(!this.showTypeBox && !this.mergeTypes)
				{
					return this.title[ORK.Game.Language].Replace("%n", ORK.LogTypes.GetName(this.tmpTypeID));
				}
				else
				{
					return this.title[ORK.Game.Language].Replace("%n", "");
				}
			}
			return "";
		}
		
		private string GetTextTitle()
		{
			if(this.useTextTitle)
			{
				return this.textTitle[ORK.Game.Language].Replace("%n", this.logTextTitle);
			}
			return "";
		}
		
		public void Closed(GUIBox origin)
		{
			if(this.exitFlag)
			{
				if(this.box == origin)
				{
					this.box = null;
				}
				else if(this.box2 == origin)
				{
					this.box2 = null;
				}
				else if(this.box3 == origin)
				{
					this.box3 = null;
				}
				if(this.box == null && this.box2 == null && this.box3 == null)
				{
					this.exitFlag = false;
				}
			}
			else
			{
				// type switch to logs
				if(this.box == origin)
				{
					this.box = null;
					if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.ShowLogs();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
				}
				// log
				else if(this.box2 == origin)
				{
					this.box2 = null;
					if(this.nextBox == 3 && MenuBoxDisplay.One.Equals(this.displayText))
					{
						this.ShowTexts();
					}
					else if(this.nextBox != 3 && this.showTypeBox && 
						MenuBoxDisplay.One.Equals(this.display))
					{
						this.ShowTypes();
					}
				}
				// text
				else if(this.box3 == origin)
				{
					this.box3 = null;
					if(this.nextBox == 2 && 
						MenuBoxDisplay.One.Equals(this.displayText))
					{
						this.ShowLogs();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
					else if(this.nextBox == 4 && 
						MenuBoxDisplay.One.Equals(this.displayText))
					{
						this.ShowLogs();
						if(this.box != null)
						{
							this.box.SetFocus();
						}
					}
				}
			}
		}
		
		public override void CombatantChoiceClosed(bool canceled)
		{
			
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			// type
			if(this.box == origin && this.typeChoice != null && 
				index >= 0 && index < this.typeChoice.Length)
			{
				if(this.current != index)
				{
					this.SelectionChanged(index, origin);
				}
				
				this.current = index;
				
				if(this.typeAction[this.current] == -1)
				{
					this.Cancel(this.box);
				}
				else
				{
					this.nextBox = 2;
					if(MenuBoxDisplay.Same.Equals(this.display))
					{
						this.box2 = this.box;
						this.box = null;
						this.ShowLogs();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
					else if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.box.InitOut();
					}
					else if(MenuBoxDisplay.Multi.Equals(this.display))
					{
						this.box2.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.display))
					{
						this.ShowLogs();
						this.box2.SetFocus();
						this.SelectionChanged(this.current2, this.box2);
					}
				}
			}
			// log
			else if(this.box2 == origin && this.logChoice != null && 
				index >= 0 && index < this.logChoice.Length)
			{
				this.current2 = index;
				if(this.logs[this.current2] == null)
				{
					this.Cancel(this.box2);
				}
				else
				{
					this.nextBox = 3;
					if(MenuBoxDisplay.Same.Equals(this.displayText))
					{
						this.box3 = this.box2;
						this.box2 = null;
						this.ShowTexts();
					}
					else if(MenuBoxDisplay.One.Equals(this.displayText))
					{
						this.box2.InitOut();
					}
					else if(MenuBoxDisplay.Multi.Equals(this.displayText))
					{
						this.box3.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.displayText))
					{
						this.ShowTexts();
					}
				}
			}
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			// type
			if(this.box == origin)
			{
				if(this.typeChoice != null && 
					index >= 0 && index < this.typeChoice.Length)
				{
					this.screen.ShowDescription(
						this.typeChoice[index].description, 
						this.typeChoice[index].Content.text, 
						this.typeAction[index] != -1 ? 
							ORK.LogTypes.Get(this.typeAction[index]) : null);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				
				this.current = index;
				if(MenuBoxDisplay.Multi.Equals(this.display))
				{
					this.ShowLogs();
				}
			}
			// log
			else if(this.box2 == origin)
			{
				if(this.logChoice != null && 
					index >= 0 && index < this.logChoice.Length)
				{
					this.screen.ShowDescription(
						this.logChoice[index].description, 
						this.logChoice[index].Content.text, 
						this.logs[index]);
				}
				else
				{
					this.screen.ShowDescription("", "", null);
				}
				this.current2 = index;
				if(MenuBoxDisplay.Multi.Equals(this.displayText))
				{
					this.ShowTexts();
				}
			}
		}
		
		public void TabChanged(int index, GUIBox box)
		{
			if(this.box2 == box)
			{
				this.current = index;
				this.ShowLogs();
			}
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.Cancel(origin);
		}
		
		private void Cancel(GUIBox origin)
		{
			// type
			if(this.box == origin)
			{
				this.screen.Close();
			}
			// log
			else if(this.box2 == origin)
			{
				if(this.showTypeBox)
				{
					this.nextBox = 1;
					if(MenuBoxDisplay.Same.Equals(this.display))
					{
						this.box = this.box2;
						this.box2 = null;
						this.ShowTypes();
						
						if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
						{
							this.box3.InitOut();
						}
					}
					else if(MenuBoxDisplay.One.Equals(this.display))
					{
						this.box2.InitOut();
						
						if(this.box3 != null && !this.box3.FadingOut && !this.box3.FadedOut)
						{
							this.box3.InitOut();
						}
					}
					else if(MenuBoxDisplay.Multi.Equals(this.display))
					{
						this.box.SetFocus();
					}
					else if(MenuBoxDisplay.Sequence.Equals(this.display))
					{
						this.box2.InitOut();
						this.box.SetFocus();
					}
				}
				else
				{
					this.screen.Close();
				}
			}
			// text
			else if(this.box3 == origin)
			{
				this.nextBox = 2;
				if(MenuBoxDisplay.Same.Equals(this.displayText))
				{
					this.box2 = this.box3;
					this.box3 = null;
					this.ShowLogs();
					this.box2.SetFocus();
					this.SelectionChanged(this.current2, this.box2);
				}
				else if(MenuBoxDisplay.One.Equals(this.displayText))
				{
					this.box3.InitOut();
				}
				else if(MenuBoxDisplay.Multi.Equals(this.displayText))
				{
					this.box2.SetFocus();
				}
				else if(MenuBoxDisplay.Sequence.Equals(this.displayText))
				{
					this.box3.InitOut();
					this.box2.SetFocus();
				}
			}
		}
	}
}
