
using UnityEngine;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework
{
	public class DamageDealerAction : BaseAction
	{
		private BaseAction baseAction;
		
		public DamageDealerAction(BaseAction action, List<Combatant> target, List<BattleEvent> events)
		{
			this.baseAction = action;
			this.user = action.user;
			this.target = target;
			this.events = events;
		}
		
		public override bool IsType(ActionType t)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override void PerformAction()
		{
			// add control blocks
			ORK.Battle.DoAllActionsBlock(1);
			if(ORK.Game.PlayerHandler.IsPlayer(this.user))
			{
				ORK.Battle.DoPlayerActionsBlock(1);
			}
			
			ORK.Battle.Actions.AddActive(this);
			
			if(this.PerformCheck())
			{
				// check target aggression
				if(this.target != null && this.target.Count > 0)
				{
					for(int i=0; i<this.target.Count; i++)
					{
						if(this.target[i] != null && this.user.IsEnemy(this.target[i]))
						{
							this.target[i].CheckAggressive(AggressionType.OnAction, this.user);
							this.target[i].SetAttackedBy(this.user, true);
						}
					}
				}
				
				// base setup
				if(this.baseAction.IsType(ActionType.Ability) || 
					this.baseAction.IsType(ActionType.Attack) ||
					this.baseAction.IsType(ActionType.Item))
				{
					user.LastTargets = this.target;
				}
				
				// start battle event
				if(this.events.Count > 0)
				{
					this.GetNextEvent();
					this.activeEvent.StartEvent(this, this.user.GameObject);
				}
				else
				{
					if(this.target != null && this.target.Count > 0)
					{
						this.Calculate(this.target, 1, true);
					}
					this.EventEnded();
				}
			}
			else
			{
				this.EventEnded();
			}
		}
		
		protected override void ActionStartSetup()
		{
			
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			this.baseAction.Calculate(ts, damageFactor, animate);
		}
		
		public override void EventEnded()
		{
			if(this.events != null && this.events.Count > 0)
			{
				this.GetNextEvent();
				this.activeEvent.StartEvent(this, this.user.GameObject);
			}
			else
			{
				this.activeEvent = null;
				if(this.rayObject != null)
				{
					GameObject.Destroy(this.rayObject);
				}
				
				ORK.Battle.Actions.RemoveActive(this);
				ORK.Battle.CheckBattleEnd();
				
				// remove control blocks
				ORK.Battle.DoAllActionsBlock(-1);
				if(ORK.Game.PlayerHandler.IsPlayer(this.user))
				{
					ORK.Battle.DoPlayerActionsBlock(-1);
				}
			}
		}

		protected override void ActionEndSetup()
		{
			
		}
	}
}
