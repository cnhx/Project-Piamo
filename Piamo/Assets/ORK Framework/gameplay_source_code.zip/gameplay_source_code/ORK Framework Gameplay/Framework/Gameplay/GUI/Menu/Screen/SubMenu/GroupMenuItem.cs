
using UnityEngine;
using ORKFramework;
using ORKFramework.Menu.Parts;
using System.Collections.Generic;

namespace ORKFramework.Menu
{
	public class GroupMenuItem : BaseData
	{
		[ORKEditorHelp("Menu Item", "Select the type of the menu item:\n" +
			"- Change: Change a member of the battle group.\n" +
			"- Remove: Removes a member of the battle group.\n" +
			"- Screen: Call a menu screen with a member of the battle group as user.\n" +
			"- Back: 'Back' button.\n" +
			"- Cancel: 'Cancel' button.", "")]
		public GroupMenuAction action = GroupMenuAction.Cancel;
		
		[ORKEditorHelp("Menu Screen", "Select the menu screen that will be called.", "")]
		[ORKEditorInfo(ORKDataType.MenuScreen)]
		[ORKEditorLayout("action", GroupMenuAction.Screen, endCheckGroup=true)]
		public int screenID = 0;
		
		[ORKEditorHelp("Use Key", "Use an input key to call the action of this menu item (e.g. call a menu screen).\n" +
			"The key is used to use this menu item's action without opening the menu.", "")]
		[ORKEditorLayout(new string[] {"action", "action"}, 
			new System.Object[] {GroupMenuAction.Back, GroupMenuAction.Cancel}, needed=Needed.One, 
			elseCheckGroup=true, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool useKey = false;
		
		[ORKEditorHelp("Call Key", "Select the input key to use this menu item.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("useKey", true, endCheckGroup=true)]
		public int keyID = 0;
		
		[ORKEditorInfo(separator=true, labelText="Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		[ORKEditorLayout(new string[] {"action", "action"}, 
			new System.Object[] {GroupMenuAction.Change, GroupMenuAction.Screen}, needed=Needed.One, 
			endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public LanguageInfo[] button;
		
		public GroupMenuItem()
		{
			
		}
		
		public GroupMenuItem(GroupMenuAction action)
		{
			this.action = action;
		}
		
		public void Use(MenuScreen origin, Combatant battle, Combatant nonBattle)
		{
			if(GroupMenuAction.Change.Equals(this.action) && 
				nonBattle != null)
			{
				if(battle == null)
				{
					origin.Combatant.Group.JoinBattle(nonBattle);
				}
				else
				{
					origin.Combatant.Group.ChangeBattle(battle, nonBattle);
				}
			}
			else if(GroupMenuAction.Remove.Equals(this.action) && 
				battle != null)
			{
				origin.Combatant.Group.LeaveBattle(battle);
			}
			else if(GroupMenuAction.Screen.Equals(this.action) && 
				battle != null)
			{
				if(this.screenID >= 0 && this.screenID < ORK.MenuScreens.Count)
				{
					MenuScreen ms = ORK.MenuScreens.Get(this.screenID);
					ms.Combatant = battle;
					ms.Show(origin);
				}
			}
		}
	}
}
