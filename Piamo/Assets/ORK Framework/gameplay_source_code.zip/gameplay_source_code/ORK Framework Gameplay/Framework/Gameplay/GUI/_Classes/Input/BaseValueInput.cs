
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Display
{
	public class BaseValueInput
	{
		protected string fieldName = "";
		
		protected MultiContent fieldNameContent;
		
		protected Rect fieldRect;
		
		public Rect bounds;
		
		public BaseValueInput()
		{
			
		}
		
		public virtual void CreateField(GUIBox box, GUIStyle textStyle, ref Rect textBounds, ref float contentHeight, ref float maxXPos)
		{
			if(contentHeight > 0)
			{
				contentHeight += box.Settings.lineSpacing;
			}
			textBounds.y = contentHeight;
			
			this.bounds = new Rect(0, contentHeight, textBounds.width, 0);
			
			if(this.fieldName != "")
			{
				this.fieldNameContent = new MultiContent(TextHelper.ReplaceSpecials(this.fieldName), null, null, 
					textStyle, textBounds, box.Settings.lineSpacing, 
					box.Settings.alignment, box.Settings.vAlignment, 
					box.Settings.heightAdjustment, box.Settings.oneline, 
					box.Settings.textFormat, box.Settings.textColumns, 
					box.Settings.textColumnSpacing);
				
				this.fieldRect = new Rect(
					this.fieldNameContent.size.x + box.Settings.inputFieldSpacing, 
					contentHeight, 
					textBounds.width - this.fieldNameContent.size.x - box.Settings.inputFieldSpacing, 
					textStyle.CalcSize(new GUIContent("Field")).y);
				contentHeight += Mathf.Max(this.fieldRect.height, this.fieldNameContent.size.y - textBounds.y);
			}
			else
			{
				this.fieldRect = new Rect(0, contentHeight, textBounds.width, 
					textStyle.CalcSize(new GUIContent("Field")).y);
				contentHeight += this.fieldRect.height;
			}
			this.bounds.height = this.fieldRect.height;
			
			if(maxXPos < this.fieldRect.x)
			{
				maxXPos = this.fieldRect.x;
			}
		}
		
		public virtual void SetFieldX(float newX)
		{
			float dif = this.fieldRect.x - newX;
			if(dif != 0)
			{
				this.fieldRect.x = newX;
				this.fieldRect.width += dif;
			}
		}
		
		public virtual bool ShowField(GUIBox box, int index, bool selected, GUIStyle textStyle)
		{
			if(this.fieldNameContent != null)
			{
				for(int i=0; i<this.fieldNameContent.label.Count; i++)
				{
					this.fieldNameContent.label[i].Show(textStyle);
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Control functions
		============================================================================
		*/
		public virtual bool OkPressed()
		{
			return false;
		}
		
		public virtual bool HorizontalChange(int add)
		{
			return false;
		}
	}
}
