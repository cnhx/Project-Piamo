
using UnityEngine;

namespace ORKFramework
{
	public class GroupSpots : BaseData
	{
		[ORKEditorInfo(labelText="Standard Battle Spot")]
		public BattleSpot spot = new BattleSpot();
		
		
		// player advantage
		[ORKEditorHelp("Use PA Spots", "Player advantage battles use extra battle spots.", "")]
		[ORKEditorInfo(separator=true, labelText="Player Advantage Spots")]
		public bool usePA = false;
		
		[ORKEditorLayout("usePA", true, endCheckGroup=true, autoInit=true)]
		public BattleSpot paSpot;
		
		
		// enemy advantage
		[ORKEditorHelp("Use EA Spots", "Enemy advantage battles use extra battle spots.", "")]
		[ORKEditorInfo(separator=true, labelText="Enemy Advantage Spots")]
		public bool useEA = false;
		
		[ORKEditorLayout("useEA", true, endCheckGroup=true, autoInit=true)]
		public BattleSpot eaSpot;
		
		public GroupSpots()
		{
			
		}
		
		public Vector3 GetSpot(GroupAdvantageType advantage)
		{
			if(this.usePA && GroupAdvantageType.Player.Equals(advantage))
			{
				return this.paSpot.GetSpot();
			}
			else if(this.useEA && GroupAdvantageType.Enemy.Equals(advantage))
			{
				return this.eaSpot.GetSpot();
			}
			return this.spot.GetSpot();
		}
	}
}
