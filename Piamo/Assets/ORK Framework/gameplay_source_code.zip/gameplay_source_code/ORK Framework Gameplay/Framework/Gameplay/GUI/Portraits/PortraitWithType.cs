
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class PortraitWithType : Portrait
	{
		[ORKEditorHelp("Portrait Type", "Select the portrait type of this portrait.\n" +
			"This portrait will be displayed when the selected portrait type is used in a dialogue.", "")]
		[ORKEditorInfo(ORKDataType.PortraitType)]
		public int typeID = 0;
		
		public PortraitWithType()
		{
			
		}
	}
}
