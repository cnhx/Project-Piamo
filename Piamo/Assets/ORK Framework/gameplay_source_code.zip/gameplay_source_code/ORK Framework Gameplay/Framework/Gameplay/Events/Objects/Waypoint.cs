
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class Waypoint : BaseData
	{
		[ORKEditorHelp("Find Object", "The waypoint will search for an object in the scene.\n" +
			"If disabled, the waypoint has to be added in the event inspector.", "")]
		public bool findObject = false;
		
		[ORKEditorLayout("findObject", true, endCheckGroup=true, autoInit=true)]
		public FindObjectSetting findObjectSetting;
		
		/*[ORKEditorHelp("Find With Tag", "The object is searched using it's tag instead of name.", "")]
		[ORKEditorLayout("findObject", true)]
		public bool findWithTag = false;
		
		[ORKEditorHelp("Find All", "Find all objects with the defined name (or tag).\n" +
			"If disabled, the first object found will be used.", "")]
		public bool findMultiple = false;
		
		[ORKEditorHelp("Object Name", "The name (or tag) to search for.\n" +
			"When searching for a name, you can use '/' to traverse hierarchies like a path.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string findName = "";*/
		
		
		// ingame
		private List<GameObject> gameObjects = new List<GameObject>();
		
		private bool searched = false;
		
		public Waypoint()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(this.findObject && data.Contains<bool>("findWithTag"))
			{
				this.findObjectSetting = new FindObjectSetting();
				
				bool tmp = false;
				data.Get("findWithTag", ref tmp);
				if(tmp)
				{
					this.findObjectSetting.type = FindObjectType.Tag;
				}
				data.Get("findMultiple", ref this.findObjectSetting.multiple);
				data.Get("findName", ref this.findObjectSetting.name);
			}
		}
		
		public void Clear()
		{
			this.gameObjects = new List<GameObject>();
			this.searched = false;
		}
		
		
		/*
		============================================================================
		Object functions
		============================================================================
		*/
		public void SetObject(GameObject obj)
		{
			this.gameObjects.Add(obj);
		}
		
		public void FindObject(GameObject user)
		{
			if(this.findObject && this.findObjectSetting != null)
			{
				this.gameObjects = this.findObjectSetting.Find(user);
			}
			this.searched = true;
		}
		
		/*public void FindObject()
		{
			if(this.findObject)
			{
				this.gameObjects = new List<GameObject>();
				if(this.findMultiple)
				{
					if(this.findWithTag)
					{
						GameObject[] tmp = GameObject.FindGameObjectsWithTag(this.findName);
						if(tmp != null && tmp.Length > 0)
						{
							this.gameObjects.AddRange(tmp);
						}
					}
					else
					{
						GameObject[] tmp = GameObject.FindObjectsOfType(typeof(GameObject)) as GameObject[];
						if(tmp != null && tmp.Length > 0)
						{
							for(int i=0; i<tmp.Length; i++)
							{
								if(tmp[i].name == this.findName)
								{
									this.gameObjects.Add(tmp[i]);
								}
							}
						}
					}
				}
				else
				{
					if(this.findWithTag)
					{
						GameObject tmp = GameObject.FindGameObjectWithTag(this.findName);
						if(tmp != null)
						{
							this.gameObjects.Add(tmp);
						}
					}
					else
					{
						GameObject tmp = GameObject.Find(this.findName);
						if(tmp != null)
						{
							this.gameObjects.Add(tmp);
						}
					}
				}
			}
			this.searched = true;
		}*/
		
		public List<GameObject> GetObject(BaseEvent baseEvent)
		{
			List<GameObject> list = new List<GameObject>();
			if(this.gameObjects.Count == 0 && !this.searched)
			{
				this.FindObject(baseEvent.GameObject);
			}
			if(this.gameObjects.Count > 0)
			{
				list.AddRange(this.gameObjects);
			}
			return list;
		}
	}
}

