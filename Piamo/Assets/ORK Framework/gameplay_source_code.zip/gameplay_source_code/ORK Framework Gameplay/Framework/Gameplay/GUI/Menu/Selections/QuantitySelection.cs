
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Menu
{
	public class QuantitySelection : BaseIndexData, IChoice
	{
		[ORKEditorHelp("Name", "The name of this GUI box.", "")]
		[ORKEditorInfo("Base Settings", "Set the name and base settings of this quantity selection.", "", 
			expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the quantity selection.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox, endFoldout=true)]
		public int guiBoxID = 0;
		
		
		// content
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo("Content Settings", "Set the content of this quantity selection.", "")]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the description box.", "")]
		[ORKEditorInfo(expandWidth=true, label=new string[] {"%n = name"})]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle", true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		// messages
		[ORKEditorHelp("Top Message", "The text displayed above the quantity.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Top Message", 
			label=new string[] {
				"%n = name, %d = description, %i = icon", 
				"%c = currency name, %cd = currency description, %ci = currency icon", 
				"%p = price, %t = total price (quantity * price)", 
				"%m = inventory money, %ms = inventory money - total, %ma = inventory money + total", 
				"%q = inventory quantity, %qs = inventory quantity - quantity, %qa = inventory quantity + quantity"
		})]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		public string[] topMessage = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		[ORKEditorHelp("Quantity Message", "The text displaying the quantity.\n" +
			"Must contain a % to display the quantity, if not in the text, it'll be forced.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Quantity Message", 
			label=new string[] {"% = quantity, %m = maximum quantity"})]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		public string[] quantityMessage = ArrayHelper.CreateArray(ORK.Languages.Count, "%");
		
		[ORKEditorHelp("Bottom Message", "The text displayed below the quantity.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Bottom Message", endFoldout=true, 
			label=new string[] {
				"%n = name, %d = description, %i = icon", 
				"%c = currency name, %cd = currency description, %ci = currency icon", 
				"%p = price, %t = total price (quantity * price)", 
				"%m = inventory money, %ms = inventory money - total, %ma = inventory money + total", 
				"%q = inventory quantity, %qs = inventory quantity - quantity, %qa = inventory quantity + quantity"
		})]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		public string[] bottomMessage = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// selection
		[ORKEditorHelp("Selection Type", "Select how the quantity will be selected:\n" +
			"- Horizontal Buttons: Horizontally aligned buttons are used.\n" +
			"- Vertical Buttons: Vertically aligned buttons are used.\n" +
			"- Both Buttons: Horizontal and vertical buttons are used.", "")]
		[ORKEditorInfo("Quantity Settings", "Define the buttons used to change the quantity.", "")]
		public QuantityInputType type = QuantityInputType.HorizontalButtons;
		
		[ORKEditorInfo(separator=true, labelText="Horizontal Buttons")]
		[ORKEditorLayout("type", QuantityInputType.VerticalButtons, 
			elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public QuantityButtons horizontal;
		
		[ORKEditorInfo(separator=true, labelText="Vertical Buttons", endFoldout=true)]
		[ORKEditorLayout("type", QuantityInputType.HorizontalButtons, 
			elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public QuantityButtons vertical;
		
		
		// ingame
		private QuantityData data;
		
		private GUIBox box;
		
		private bool cancelFlag = false;
		
		
		// quantity
		private int quantity = 0;
		
		public QuantitySelection()
		{
			
		}
		
		public QuantitySelection(string name)
		{
			this.name = name;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return true;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return true;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		private void GetMessage(ref string t, ref string top, ref string q, ref string bottom)
		{
			int total = this.quantity * this.data.price;
			t = this.useTitle ? this.title[ORK.Game.Language].Replace("%n", this.data.shortcut.GetName()) : "";
			top = this.topMessage[ORK.Game.Language].
				Replace("%n", this.data.shortcut.GetName()).
				Replace("%d", this.data.shortcut.GetDescription()).
				Replace("%i", this.data.shortcut.GetIconTextCode()).
				Replace("%ci", ORK.Currencies.Get(this.data.currencyID).GetIconTextCode()).
				Replace("%cd", ORK.Currencies.GetDescription(this.data.currencyID)).
				Replace("%c", ORK.Currencies.GetName(this.data.currencyID)).
				Replace("%p", this.data.price.ToString()).
				Replace("%t", total.ToString()).
				Replace("%ms", (this.data.availableCurrency - total).ToString()).
				Replace("%ma", (this.data.availableCurrency + total).ToString()).
				Replace("%m", this.data.availableCurrency.ToString()).
				Replace("%qs", (this.data.availableQuantity - this.quantity).ToString()).
				Replace("%qa", (this.data.availableQuantity + this.quantity).ToString()).
				Replace("%q", this.data.availableQuantity.ToString());
			bottom = this.bottomMessage[ORK.Game.Language].
				Replace("%n", this.data.shortcut.GetName()).
				Replace("%d", this.data.shortcut.GetDescription()).
				Replace("%i", this.data.shortcut.GetIconTextCode()).
				Replace("%ci", ORK.Currencies.Get(this.data.currencyID).GetIconTextCode()).
				Replace("%cd", ORK.Currencies.GetDescription(this.data.currencyID)).
				Replace("%c", ORK.Currencies.GetName(this.data.currencyID)).
				Replace("%p", this.data.price.ToString()).
				Replace("%t", total.ToString()).
				Replace("%ms", (this.data.availableCurrency - total).ToString()).
				Replace("%ma", (this.data.availableCurrency + total).ToString()).
				Replace("%m", this.data.availableCurrency.ToString()).
				Replace("%qs", (this.data.availableQuantity - this.quantity).ToString()).
				Replace("%qa", (this.data.availableQuantity + this.quantity).ToString()).
				Replace("%q", this.data.availableQuantity.ToString());
			
			if(!this.quantityMessage[ORK.Game.Language].Contains("%"))
			{
				q = this.quantity.ToString();
			}
			else
			{
				q = this.quantityMessage[ORK.Game.Language].
					Replace("%m", this.data.maxQuantity.ToString()).
					Replace("%", this.quantity.ToString());
			}
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(QuantityData data)
		{
			this.data = data;
			this.cancelFlag = false;
			
			this.quantity = this.data.maxQuantity == 0 ? 0 : 1;
			
			this.Show();
		}
		
		public void Show()
		{
			this.box = ORK.GUIBoxes.Create(this.guiBoxID);
			string title = "";
			string top = "";
			string q = "";
			string bottom = "";
			this.GetMessage(ref title, ref top, ref q, ref bottom);
			this.box.Content = new QuantityContent(top, q, bottom, title, this);
			this.box.InitIn();
			ORK.GUI.FocusBlocked = true;
			ORK.GUI.SelectedShortcut = this.data.shortcut;
		}

		public void FocusGained(GUIBox origin)
		{
			ORK.GUI.SelectedShortcut = this.data.shortcut;
		}

		public void FocusLost(GUIBox origin)
		{
			ORK.GUI.SelectedShortcut = null;
		}

		public void Closed(GUIBox origin)
		{
			if(this.cancelFlag)
			{
				this.data.Cancel();
			}
			else
			{
				this.data.Execute(this.quantity);
			}
			
			this.data = null;
			this.cancelFlag = false;
			this.box = null;
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void ChoiceSelected(int index, GUIBox origin)
		{
			this.cancelFlag = index == 1;
			this.box.InitOut();
		}
		
		public void ChangeQuantity(int change, bool loop)
		{
			this.quantity += change;
			if(this.quantity < 1)
			{
				this.quantity = loop ? this.data.maxQuantity : (this.data.maxQuantity == 0 ? 0 : 1);
			}
			else if(this.quantity > this.data.maxQuantity)
			{
				this.quantity = loop ? (this.data.maxQuantity == 0 ? 0 : 1) : this.data.maxQuantity;
			}
			if(this.box.Content is QuantityContent)
			{
				string title = "";
				string top = "";
				string q = "";
				string bottom = "";
				this.GetMessage(ref title, ref top, ref q, ref bottom);
				((QuantityContent)this.box.Content).SetContent(top, q, bottom, title);
			}
		}

		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}

		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.cancelFlag = true;
			this.box.InitOut();
		}
	}
}
