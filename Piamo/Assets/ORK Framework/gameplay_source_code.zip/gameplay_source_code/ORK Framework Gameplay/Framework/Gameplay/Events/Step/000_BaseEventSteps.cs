
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	public static class EventStepHelper
	{
		public static Dictionary<System.Type, NodeInfo> GetSteps(System.Type eventType)
		{
			Dictionary<System.Type, NodeInfo> list = new Dictionary<System.Type, NodeInfo>();
			System.Type[] types = System.Reflection.Assembly.GetExecutingAssembly().GetTypes();
			foreach(System.Type type in types)
			{
				if(type.Namespace == "ORKFramework.Events.Steps")
				{
					ORKEventStepAttribute step = null;
					System.Object[] attr = type.GetCustomAttributes(typeof(ORKEventStepAttribute), true);
					if(attr.Length > 0)
					{
						step = attr[0] as ORKEventStepAttribute;
					}
					
					if(step != null && step.Available(eventType))
					{
						string[] help = new string[0];
						attr = type.GetCustomAttributes(typeof(ORKEditorHelpAttribute), true);
						if(attr.Length > 0)
						{
							help = (attr[0] as ORKEditorHelpAttribute).text;
						}
						
						string[] subMenu = new string[0];
						attr = type.GetCustomAttributes(typeof(ORKNodeInfoAttribute), true);
						if(attr.Length > 0)
						{
							subMenu = (attr[0] as ORKNodeInfoAttribute).subMenu;
						}
						list.Add(type, new NodeInfo(help, subMenu));
					}
				}
			}
			return list;
		}
	}
	
	public abstract class BaseEventStep : CoreEventStep
	{
		[ORKEditorHelp("Enabled", "This step is enabled and will be executed.\n" +
			"If disabled, the step wont execute and the next step ('Next' or 'Success') will be executed.", "")]
		[ORKEditorInfo(hide=true)]
		public bool active = true;
		
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		public abstract void Execute(BaseEvent baseEvent);
		
		public virtual void Continue(BaseEvent baseEvent)
		{
			
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeName()
		{
			return "";
		}
		
		public override string GetNodeDetails()
		{
			return "";
		}
		
		public override string GetNextName(int index)
		{
			return "Next";
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override int GetNextCount()
		{
			return 1;
		}
		
		public override int GetNext(int index)
		{
			return this.next;
		}
		
		public override void SetNext(int index, int next)
		{
			this.next = next;
		}
		
		
		/*
		============================================================================
		Enable functions
		============================================================================
		*/
		public override bool IsEnabled
		{
			get{ return this.active;}
		}
		
		public virtual bool ExecuteOnStop
		{
			get{ return false;}
		}
	}
	
	public abstract class BaseEventCheckStep : BaseEventStep
	{
		[ORKEditorInfo(hide=true)]
		public int nextFail = -1;
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Success";
			}
			else if(index == 1)
			{
				return "Failed";
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return 2;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.nextFail;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.nextFail = next;
			}
		}
	}
	
	[ORKEditorHelp("Wait", "Waits for a defined time.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base Steps")]
	public class WaitStep : BaseEventStep
	{
		[ORKEditorHelp("Time (s)", "The time in seconds to wait before executing the next step.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorHelp("Random", "Wait for a random amount of time between two defined values ('Time' and 'Time 2').\n" +
			"If disabled, the step waits for the time defined in 'Time'.", "")]
		public bool random = false;
		
		[ORKEditorHelp("Time 2 (s)", "The 2nd time in seconds - the wait time will be between 'Time' and 'Time 2'.", "")]
		[ORKEditorLimit("time", false)]
		[ORKEditorLayout("random", true, endCheckGroup=true)]
		public float time2 = 1;
		
		public WaitStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.random)
			{
				baseEvent.StartTime(Random.Range(this.time, this.time2), this.next);
			}
			else
			{
				baseEvent.StartTime(this.time, this.next);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.random ? this.time + " - " + this.time2 + "s" : this.time + "s");
		}
	}
	
	[ORKEditorHelp("Random", "Randomly executes a next step out of a list of defined steps.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base Steps")]
	public class RandomStep : BaseEventStep
	{
		[ORKEditorInfo(hide=true, instanceCallback="buttons:randomstep")]
		public int[] random = new int[] {-1};
		
		public RandomStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.StepFinished(this.random[Random.Range(0, this.random.Length)]);
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			return "Random " + index;
		}
		
		public override int GetNextCount()
		{
			return this.random.Length;
		}
		
		public override int GetNext(int index)
		{
			return this.random[index];
		}
		
		public override void SetNext(int index, int next)
		{
			this.random[index] = next;
		}
	}
	
	[ORKEditorHelp("Wait For Input", "Waits for an input key to be pressed, " +
		"either for a set amount of time, or until the key has been pressed.\n" +
		"If waiting for time, 'Success' will be executed if the key was pressed in time, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base Steps")]
	public class WaitForInputStep : BaseEventStep
	{
		[ORKEditorHelp("Any Key", "Any key (keyboard, mouse, etc.) can be used.", "")]
		public bool any = false;
		
		[ORKEditorHelp("Input Key", "Select the input key that will be used.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("any", false, endCheckGroup=true)]
		public int id = 0;
		
		[ORKEditorHelp("Wait", "The event will wait for a set amount of time for the key press.\n" +
			"If disabled, the event will wait until the key has been pressed.", "")]
		public bool wait = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds to wait for the key to be pressed.", "")]
		[ORKEditorLayout("wait", true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorLayout(endCheckGroup=true, setDefault=true, defaultValue=-1)]
		[ORKEditorInfo(hide=true)]
		public int nextFail = -1;
		
		public WaitForInputStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.wait)
			{
				if(this.any)
				{
					baseEvent.WaitForButton(new int[0], this.time, new int[] {this.next}, this.nextFail);
				}
				else
				{
					baseEvent.WaitForButton(new int[] {this.id}, this.time, new int[] {this.next}, this.nextFail);
				}
			}
			else
			{
				if(this.any)
				{
					baseEvent.WaitForButton(new int[0], -1, new int[] {this.next}, this.next);
				}
				else
				{
					baseEvent.WaitForButton(new int[] {this.id}, -1, new int[] {this.next}, this.next);
				}
			}
		}
		
		
		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Success";
			}
			else if(index == 1)
			{
				return "Failed";
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.wait ? 2 : 1;
		}
		
		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				return this.nextFail;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				this.nextFail = next;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.any ? "Any Key" : ORK.InputKeys.GetName(this.id)) + 
				(this.wait ? ", " + this.time + "s" : "");
		}
	}
	
	[ORKEditorHelp("Wait For Input Fork", "Waits for an input key (out of multiple keys) to be pressed, " +
		"either for a set amount of time, or until the key has been pressed.\n" +
		"The next step of the input key that's pressed first will be executed.\n" +
		"If waiting for time and no key was pressed in time, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base Steps")]
	public class WaitForInputForkStep : BaseEventStep
	{
		[ORKEditorHelp("Wait", "The event will wait for a set amount of time for a key press.\n" +
			"If disabled, the event will wait until a key has been pressed.", "")]
		public bool wait = false;
		
		[ORKEditorHelp("Time (s)", "The time in seconds to wait for a key to be pressed.", "")]
		[ORKEditorLayout("wait", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float time = 1;
		
		[ORKEditorArray(false, "Add Input Key", "Adds an input key.", "", 
			"Remove", "Removes this input key.", "", noRemoveCount=1, isHorizontal=true)]
		public InputKeyNextNode[] inputKey = new InputKeyNextNode[] { new InputKeyNextNode()};
		
		public WaitForInputForkStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int[] ks = new int[this.inputKey.Length];
			int[] ns = new int[this.inputKey.Length];
			
			for(int i=0; i<this.inputKey.Length; i++)
			{
				ks[i] = this.inputKey[i].inputKeyID;
				ns[i] = this.inputKey[i].next;
			}
			
			baseEvent.WaitForButton(ks, this.wait ? this.time : -1, ns, this.next);
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(this.wait)
			{
				if(index == 0)
				{
					return "Failed";
				}
				else if(index > 0)
				{
					return "Input Key " + (index - 1) + ": " + ORK.InputKeys.GetName(this.inputKey[index - 1].inputKeyID);
				}
			}
			else
			{
				return "Input Key " + index + ": " + ORK.InputKeys.GetName(this.inputKey[index].inputKeyID);
			}
			return "";
		}
		
		public override int GetNextCount()
		{
			return this.inputKey.Length + (this.wait ? 1 : 0);
		}
		
		public override int GetNext(int index)
		{
			if(this.wait)
			{
				if(index == 0)
				{
					return this.next;
				}
				else if(index > 0)
				{
					return this.inputKey[index - 1].next;
				}
			}
			else
			{
				return this.inputKey[index].next;
			}
			return -1;
		}
		
		public override void SetNext(int index, int next)
		{
			if(this.wait)
			{
				if(index == 0)
				{
					this.next = next;
				}
				else if(index > 0)
				{
					this.inputKey[index - 1].next = next;
				}
			}
			else
			{
				this.inputKey[index].next = next;
			}
		}
	}
	
	[ORKEditorHelp("Auto Save Game", "Saves the game to the AUTO save game file or creates a temporary retry save game.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Base Steps")]
	public class AutoSaveGameStep : BaseEventStep
	{
		[ORKEditorHelp("Save To Retry", "Creates a temporary retry save game.\n" +
			"The retry save game will be lost when loading it or quitting the game.\n" +
			"If disabled, the game will use the AUTO save game file to create a permanently save game.", "")]
		public bool retry = false;
		
		public AutoSaveGameStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.retry)
			{
				ORK.SaveGame.Save(SaveGameHandler.RETRY_INDEX);
			}
			else
			{
				ORK.SaveGame.Save(SaveGameHandler.AUTOSAVE_INDEX);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.retry ? "Retry" : "AUTO";
		}
	}
	
	[ORKEditorHelp("Game Over", "Ends the game and calls the game over screen.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base Steps")]
	public class GameOverStep : BaseEventStep
	{
		public GameOverStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.SetGameOver();
			baseEvent.StepFinished(baseEvent.step.Length);
		}
		
		public override int GetNextCount()
		{
			return 0;
		}
		
		public override int GetNext(int index)
		{
			return -1;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Ends the event";
		}
	}
	
	[ORKEditorHelp("Comment", "Leave a comment in your event.\n" +
		"This step does nothing and is only for commentary purposes.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base Steps")]
	public class CommentStep : BaseEventStep
	{
		[ORKEditorHelp("Comment", "The comment.", "")]
		[ORKEditorInfo(isTextArea=true)]
		public string comment = "";
		
		public CommentStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.comment;
		}
	}
	
	[ORKEditorHelp("Re-Find Objects", "Search for actors and waypoints again.\n" +
		"Only actors or waypoints that have 'Find Object' enabled will be searched again.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Base Steps")]
	public class ReFindObjectsStep : BaseEventStep
	{
		[ORKEditorHelp("Find Actors", "Actors will be searched again.", "")]
		public bool findActors = true;
		
		[ORKEditorHelp("Find Waypoints", "Waypoints will be searched again.", "")]
		public bool findWaypoints = true;
		
		public ReFindObjectsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is GameEvent)
			{
				if(this.findActors)
				{
					((GameEvent)baseEvent).ReFindActors();
				}
				if(this.findWaypoints)
				{
					((GameEvent)baseEvent).ReFindWaypoints();
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Block Input Key", "Blocks or unblocks an input key.\n" +
		"A blocked input key wont receive any input.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base Steps")]
	public class BlockInputKeyStep : BaseEventStep
	{
		[ORKEditorHelp("Block/Unblock", "If enabled, the input key will be blocked.\n" +
			"If disabled, the input key will be unblocked.", "")]
		public bool block = false;
		
		[ORKEditorHelp("All Keys", "Block or unblock all input keys.\n" +
			"If disabled, only a selected input key will be blocked or unblocked.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Input Key", "Select the input key that will be blocked or unblocked.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int id = 0;
		
		public BlockInputKeyStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				for(int i=0; i<ORK.InputKeys.Count; i++)
				{
					ORK.InputKeys.Get(i).Blocked = this.block;
				}
			}
			else
			{
				ORK.InputKeys.Get(this.id).Blocked = this.block;
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.block ? "Block " : "Unblock ") + 
				(this.all ? "All Keys" : ORK.InputKeys.GetName(this.id));
		}
	}
	
	[ORKEditorHelp("Block Control Map", "Blocks or unblocks a control map.\n" +
		"A blocked control map can't be used.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base Steps")]
	public class BlockControlMapStep : BaseEventStep
	{
		[ORKEditorHelp("Block/Unblock", "If enabled, the control map will be blocked.\n" +
			"If disabled, the control map will be unblocked.", "")]
		public bool block = false;
		
		[ORKEditorHelp("All Control Maps", "Block or unblock all control maps.\n" +
			"If disabled, only a selected control map will be blocked or unblocked.", "")]
		public bool all = false;
		
		[ORKEditorHelp("Control Map", "Select the control map that will be blocked or unblocked.", "")]
		[ORKEditorInfo(ORKDataType.ControlMap)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int id = 0;
		
		public BlockControlMapStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				for(int i=0; i<ORK.ControlMaps.Count; i++)
				{
					ORK.ControlMaps.Get(i).Blocked = this.block;
				}
			}
			else
			{
				ORK.ControlMaps.Get(this.id).Blocked = this.block;
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.block ? "Block " : "Unblock ") + 
				(this.all ? "All Control Maps" : ORK.ControlMaps.GetName(this.id));
		}
	}
	
	[ORKEditorHelp("Search Objects", "Searches for game objects in the scene and " +
		"adds or removes them to the 'Found Objects' list, or removes all found objects from the list.\n" +
		"Found objects can be used in event steps by using the 'Found Objects' selection.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base Steps")]
	public class SearchObjectsStep : BaseEventStep
	{
		[ORKEditorHelp("Change Type", "Select how the found objects will be changed:\n" +
			"- Add: The objects will be added to the found objects.\n" +
			"- Remove: The objects will be removed from the found objects.\n" +
			"- Clear: All found objects will be removed.", "")]
		public ListChangeType changeType = ListChangeType.Add;
		
		
		// find settings
		[ORKEditorInfo(separator=true, labelText="Find Objects")]
		[ORKEditorLayout("changeType", ListChangeType.Clear, 
			elseCheckGroup=true, autoInit=true)]
		public FindObjectSetting findObject;
		
		
		// searching object
		[ORKEditorHelp("Search from Object", 
			"Search using a different object than the event object for range checks.\n" +
			"If disabled, the event object (e.g. the user of an action or " +
			"the game object with the event interaction) will be used.", "")]
		[ORKEditorInfo(separator=true, labelText="Search Origin")]
		public bool fromObject = false;
		
		[ORKEditorLayout("fromObject", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public EventObjectSetting searchObject;
		
		public SearchObjectsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ListChangeType.Clear.Equals(this.changeType))
			{
				baseEvent.ChangeFoundObjects(null, this.changeType);
			}
			else
			{
				baseEvent.ChangeFoundObjects(
					this.findObject.Find(this.fromObject ? 
						TransformHelper.GetFirstObject(this.searchObject.GetObject(baseEvent)) : 
						baseEvent.GameObject), 
					this.changeType);
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.changeType.ToString();
		}
	}
}
