
namespace ORKFramework
{
	public class ClassChange : BaseData
	{
		[ORKEditorHelp("Class", "Select the class the combatant will change to.", "")]
		[ORKEditorInfo(ORKDataType.Class)]
		public int classID = 0;
		
		[ORKEditorHelp("Forget Old Abilities", "Abilities learned through the previous class will be lost.", "")]
		public bool forget = false;
		
		[ORKEditorHelp("Learn Abilities", "Abilities of the new class will be learned " +
			"(up to the current level and class level).", "")]
		public bool learn = false;
		
		[ORKEditorHelp("Reset Class Level", "The class level will be reset to the combatant's start class level.", "")]
		public bool reset = false;
		
		[ORKEditorHelp("Remove Old Bonuses", "The status value bonuses earned by the status value development of the " +
			"previous class will be removed.", "")]
		public bool rem = false;
		
		[ORKEditorHelp("Get New Bonuses", "The status value bonuses of the new classes status value development " +
			"will be applied (up to the current class level).", "")]
		public bool add = false;
		
		[ORKEditorHelp("Reset Attack Attributes", "Reset the start values of attack attributes.", "")]
		public bool resetAtkAttrStart = false;
		
		[ORKEditorHelp("Reset Defence Attributes", "Reset the start values of attack attributes.", "")]
		public bool resetDefAttrStart = false;
		
		public ClassChange()
		{
			
		}
		
		public void Change(Combatant c)
		{
			if(c != null)
			{
				c.ChangeClass(this.classID, this.forget, this.learn, this.reset, this.rem, this.add, 
					this.resetAtkAttrStart, this.resetDefAttrStart);
			}
		}
	}
}

