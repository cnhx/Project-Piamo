
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Display
{
	public class BoolValueInput : BaseValueInput
	{
		public bool value = false;
		
		public BoolValueInput(bool value, string fieldName)
		{
			this.value = value;
			this.fieldName = fieldName;
		}
		
		public override bool ShowField(GUIBox box, int index, bool selected, GUIStyle textStyle)
		{
			base.ShowField(box, index, selected, textStyle);
			
			bool tmpValue = this.value;
			this.value = GUI.Toggle(this.fieldRect, this.value, "");
			return tmpValue != this.value;
		}
		
		
		/*
		============================================================================
		Control functions
		============================================================================
		*/
		public override bool OkPressed()
		{
			this.value = !this.value;
			return true;
		}
		
		public override bool HorizontalChange(int add)
		{
			this.value = !this.value;
			return true;
		}
	}
}
