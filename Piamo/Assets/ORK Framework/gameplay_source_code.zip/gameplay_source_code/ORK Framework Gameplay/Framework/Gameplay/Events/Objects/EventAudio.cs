
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework.Events
{
	public class EventAudio : BaseData
	{
		[ORKEditorHelp("Audio Clip", "Select the audio clip you want to use.", "")]
		public AudioClip clip;
		
		public EventAudio()
		{
			
		}
		
		
		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public void SetClip(AudioClip c)
		{
			this.clip = c;
		}
		
		public AudioClip GetClip()
		{
			return this.clip;
		}
	}
}

