
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GUIBoxButton : BaseData
	{
		[ORKEditorHelp("Position (Anchor)", "The position of the buttons in the GUI box.", "")]
		public TextAnchor anchor = TextAnchor.LowerRight;
		
		[ORKEditorHelp("Bounds", "The bounds of the button.\n" +
			"X=0, Y=0 is at the selected position of the GUI box.", "")]
		public Rect bounds = new Rect(-150, 30, 150, 30);
		
		[ORKEditorInfo("Button Settings", "Define the settings (padding, alignment, etc.) of this button.", "", 
			endFoldout=true, foldoutDefault=false)]
		public ButtonSettings settings = new ButtonSettings();
		
		[ORKEditorInfo(separator=true, labelText="Button Content")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		public LanguageContent[] content = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count);
		
		public GUIBoxButton()
		{
			
		}
		
		public GUIBoxButton(Rect b, string n)
		{
			this.bounds = b;
			for(int i=0; i<this.content.Length; i++)
			{
				this.content[i].name = n;
			}
		}
		
		public ChoiceContent GetButton(GUIStyle textStyle, Rect boxBounds)
		{
			ChoiceContent cc = this.content[ORK.Game.Language].GetChoiceContent();
			cc.InitContent(textStyle, new Rect(0, 0, this.bounds.width, this.bounds.height), false, this.settings, null);
			
			Rect buttonBounds = this.bounds;
			
			GUIHelper.GetRectAnchor(ref buttonBounds, boxBounds.width, boxBounds.height, this.anchor);
			
			cc.SetBounds(buttonBounds);
			return cc;
		}
	}
}
