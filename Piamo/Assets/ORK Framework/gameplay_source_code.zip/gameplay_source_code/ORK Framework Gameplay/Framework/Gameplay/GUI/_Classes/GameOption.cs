
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Display
{
	public class GameOption : BaseData
	{
		[ORKEditorHelp("Option Type", "Select the type of the option:\n" +
			"- Custom: A custom option, changes game variables.\n" +
			"- Music Volume: Changes the music volume (0-1)." +
			"- Sound Volume: Changes the sound volume (0-1)." +
			"- Text Speed: Changes the speed of text typing in GUI boxes.\n" +
			"- Random Battle Chance: Changes the chance for random battles. " +
			"Used as percent of the chance defined in random battle areas (plus bonuses).", "")]
		public GameOptionType type = GameOptionType.Custom;
		
		[ORKEditorHelp("Field Name", "The name of the input field displayed in the GUI box.", "")]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorInfo(separator=true, expandWidth=true, labelText="Field Name")]
		public string[] name = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// custom (variable)
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		[ORKEditorLayout("type", GameOptionType.Custom)]
		public StringValue variableKey = new StringValue();
		
		[ORKEditorHelp("Input Type", "Select the type of the input value (game variable):\n" +
			"- String: A string variable (text field).\n" +
			"- Bool: A bool variable (toggle field).\n" +
			"- Float: A float variable (horizontal slider).\n" +
			"The initial value of the input will be taken from the used game variable.", "")]
		public GameVariableInputType inputType = GameVariableInputType.String;
		
		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		[ORKEditorInfo(separator=true, labelText="Start Value (float)")]
		[ORKEditorLayout("inputType", GameVariableInputType.Float)]
		public FormulaOperator floatOperator = FormulaOperator.Add;
		
		[ORKEditorHelp("As Int", "The input value will be treated as an integer, i.e. only whole numbers.", "")]
		[ORKEditorInfo(separator=true)]
		public bool asInt = false;
		
		[ORKEditorInfo(separator=true, labelText="Minimum Value")]
		[ORKEditorLayout(autoInit=true)]
		public FloatValue minValue;
		
		[ORKEditorInfo(separator=true, labelText="Maximum Value")]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true, endGroups=2)]
		public FloatValue maxValue;
		
		
		// volumes
		[ORKEditorHelp("Int Volume", "Display the volume as an integer, i.e. a value from 0 to 10.\n" +
			"If disabled, the volume will be displayed as a float, i.e. 0 to 1.", "")]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {GameOptionType.MusicVolume, GameOptionType.SoundVolume}, 
			needed=Needed.One, endCheckGroup=true)]
		[ORKEditorInfo(separator=true)]
		public bool volumeAsInt = false;
		
		
		// text speed
		[ORKEditorHelp("Minimum Text Speed", "The minimum text speed that can be set.\n" +
			"The text speed defined in GUI boxes will be divided by the text speed option.\n" +
			"If the text speed is set to 0, text typing will be deactivated.", "")]
		[ORKEditorLayout("type", GameOptionType.TextSpeed)]
		[ORKEditorInfo(separator=true)]
		public int minTextSpeed = 0;
		
		[ORKEditorHelp("Maximum Text Speed", "The maximum text speed that can be set.\n" +
			"The text speed defined in GUI boxes will be divided by the text speed option.\n" +
			"If the text speed is set to 0, text typing will be deactivated.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public int maxTextSpeed = 4;
		
		
		// random battle chance
		[ORKEditorHelp("Maximum Chance", "The maximum random battle chance that can be set.\n" +
			"The minimum is 0 (i.e. 0 % - no random battles at all).\n" +
			"100 is 100 %, the default random battle chance.\n" +
			"200 is 200 %, double random battle chance.", "")]
		[ORKEditorLayout("type", GameOptionType.RandomBattleChance)]
		[ORKEditorInfo(separator=true)]
		public float maxRandomBattleChance = 100;
		
		[ORKEditorHelp("Int Chance", "Display the random battle chance as an integer.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool rbcAsInt = false;
		
		
		// in-game
		private System.Object initialValue;
		
		public GameOption()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<string>("fieldName"))
			{
				string tmp = "";
				data.Get("fieldName", ref tmp);
				this.name[0] = tmp;
			}
		}
		
		
		/*
		============================================================================
		Value functions
		============================================================================
		*/
		public BaseValueInput GetValueInput(VariableHandler variableHandler)
		{
			if(GameOptionType.Custom.Equals(this.type))
			{
				if(GameVariableInputType.String.Equals(this.inputType))
				{
					this.initialValue = variableHandler.GetString(this.variableKey.GetValue());
					return new StringValueInput((string)this.initialValue, this.name[ORK.Game.Language]);
				}
				else if(GameVariableInputType.Bool.Equals(this.inputType))
				{
					this.initialValue = variableHandler.GetBool(this.variableKey.GetValue());
					return new BoolValueInput((bool)this.initialValue, this.name[ORK.Game.Language]);
				}
				else if(GameVariableInputType.Float.Equals(this.inputType))
				{
					if(this.asInt)
					{
						this.initialValue = (int)variableHandler.GetFloat(this.variableKey.GetValue());
						return new IntValueInput(
							(int)this.initialValue, 
							(int)this.minValue.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader), 
							(int)this.maxValue.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader), 
							this.name[ORK.Game.Language]);
					}
					else
					{
						this.initialValue = variableHandler.GetFloat(this.variableKey.GetValue());
						return new FloatValueInput(
							(float)this.initialValue, 
							this.minValue.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader), 
							this.maxValue.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader), 
							this.name[ORK.Game.Language]);
					}
				}
			}
			else if(GameOptionType.MusicVolume.Equals(this.type))
			{
				if(this.volumeAsInt)
				{
					this.initialValue = (int)(ORK.Game.MusicVolume * 10);
					return new IntValueInput((int)this.initialValue, 0, 10, this.name[ORK.Game.Language]);
				}
				else
				{
					this.initialValue = ORK.Game.MusicVolume;
					return new FloatValueInput(ORK.Game.MusicVolume, 0, 1, this.name[ORK.Game.Language]);
				}
			}
			else if(GameOptionType.SoundVolume.Equals(this.type))
			{
				if(this.volumeAsInt)
				{
					this.initialValue = (int)(ORK.Game.SoundVolume * 10);
					return new IntValueInput((int)this.initialValue, 0, 10, this.name[ORK.Game.Language]);
				}
				else
				{
					this.initialValue = ORK.Game.SoundVolume;
					return new FloatValueInput(ORK.Game.SoundVolume, 0, 1, this.name[ORK.Game.Language]);
				}
			}
			else if(GameOptionType.TextSpeed.Equals(this.type))
			{
				this.initialValue = ORK.Game.TextSpeed;
				return new IntValueInput(ORK.Game.TextSpeed, this.minTextSpeed, this.maxTextSpeed, this.name[ORK.Game.Language]);
			}
			else if(GameOptionType.RandomBattleChance.Equals(this.type))
			{
				if(this.rbcAsInt)
				{
					this.initialValue = (int)(ORK.Game.RandomBattleChance);
					return new IntValueInput((int)this.initialValue, 0, (int)this.maxRandomBattleChance, this.name[ORK.Game.Language]);
				}
				else
				{
					this.initialValue = ORK.Game.RandomBattleChance;
					return new FloatValueInput(ORK.Game.RandomBattleChance, 0, this.maxRandomBattleChance, this.name[ORK.Game.Language]);
				}
			}
			return null;
		}
		
		public void SetNewValue(VariableHandler variableHandler, BaseValueInput input)
		{
			if(input != null)
			{
				if(GameOptionType.Custom.Equals(this.type))
				{
					if(variableHandler != null)
					{
						if(GameVariableInputType.String.Equals(this.inputType) && 
							input is StringValueInput)
						{
							variableHandler.Set(this.variableKey.GetValue(), ((StringValueInput)input).value);
						}
						else if(GameVariableInputType.Bool.Equals(this.inputType) && 
							input is BoolValueInput)
						{
							variableHandler.Set(this.variableKey.GetValue(), ((BoolValueInput)input).value);
						}
						else if(GameVariableInputType.Float.Equals(this.inputType))
						{
							if(this.asInt && input is IntValueInput)
							{
								variableHandler.ChangeFloat(this.variableKey.GetValue(), 
									((IntValueInput)input).value, this.floatOperator);
							}
							else if(!this.asInt && input is FloatValueInput)
							{
								variableHandler.ChangeFloat(this.variableKey.GetValue(), 
									((FloatValueInput)input).value, this.floatOperator);
							}
						}
					}
				}
				else if(GameOptionType.MusicVolume.Equals(this.type))
				{
					if(this.volumeAsInt && input is IntValueInput)
					{
						ORK.Game.MusicVolume = ((IntValueInput)input).value / 10.0f;
					}
					else if(!this.volumeAsInt && input is FloatValueInput)
					{
						ORK.Game.MusicVolume = ((FloatValueInput)input).value;
					}
				}
				else if(GameOptionType.SoundVolume.Equals(this.type))
				{
					if(this.volumeAsInt && input is IntValueInput)
					{
						ORK.Game.SoundVolume = ((IntValueInput)input).value / 10.0f;
					}
					else if(!this.volumeAsInt && input is FloatValueInput)
					{
						ORK.Game.SoundVolume = ((FloatValueInput)input).value;
					}
				}
				else if(GameOptionType.TextSpeed.Equals(this.type) && 
					input is IntValueInput)
				{
					ORK.Game.TextSpeed = ((IntValueInput)input).value;
				}
				else if(GameOptionType.RandomBattleChance.Equals(this.type))
				{
					if(this.rbcAsInt && input is IntValueInput)
					{
						ORK.Game.RandomBattleChance = ((IntValueInput)input).value;
					}
					else if(!this.rbcAsInt && input is FloatValueInput)
					{
						ORK.Game.RandomBattleChance = ((FloatValueInput)input).value;
					}
				}
			}
		}
		
		public void ResetValue(VariableHandler variableHandler)
		{
			if(this.initialValue != null)
			{
				if(GameOptionType.Custom.Equals(this.type))
				{
					if(variableHandler != null)
					{
						if(GameVariableInputType.String.Equals(this.inputType) && 
							this.initialValue is string)
						{
							variableHandler.Set(this.variableKey.GetValue(), (string)this.initialValue);
						}
						else if(GameVariableInputType.Bool.Equals(this.inputType) && 
							this.initialValue is bool)
						{
							variableHandler.Set(this.variableKey.GetValue(), (bool)this.initialValue);
						}
						else if(GameVariableInputType.Float.Equals(this.inputType))
						{
							if(this.asInt && this.initialValue is int)
							{
								variableHandler.ChangeFloat(this.variableKey.GetValue(), 
									(int)this.initialValue, this.floatOperator);
							}
							else if(!this.asInt && this.initialValue is float)
							{
								variableHandler.ChangeFloat(this.variableKey.GetValue(), 
									(float)this.initialValue, this.floatOperator);
							}
						}
					}
				}
				else if(GameOptionType.MusicVolume.Equals(this.type))
				{
					if(this.volumeAsInt && this.initialValue is int)
					{
						ORK.Game.MusicVolume = ((int)this.initialValue) / 10.0f;
					}
					else if(!this.volumeAsInt && this.initialValue is float)
					{
						ORK.Game.MusicVolume = (float)this.initialValue;
					}
				}
				else if(GameOptionType.SoundVolume.Equals(this.type))
				{
					if(this.volumeAsInt && this.initialValue is int)
					{
						ORK.Game.SoundVolume = ((int)this.initialValue) / 10.0f;
					}
					else if(!this.volumeAsInt && this.initialValue is float)
					{
						ORK.Game.SoundVolume = (float)this.initialValue;
					}
				}
				else if(GameOptionType.TextSpeed.Equals(this.type) && 
					this.initialValue is int)
				{
					ORK.Game.TextSpeed = (int)this.initialValue;
				}
				else if(GameOptionType.RandomBattleChance.Equals(this.type))
				{
					if(this.rbcAsInt && this.initialValue is int)
					{
						ORK.Game.RandomBattleChance = (int)this.initialValue;
					}
					else if(!this.rbcAsInt && this.initialValue is float)
					{
						ORK.Game.RandomBattleChance = (float)this.initialValue;
					}
				}
			}
		}
	}
}
