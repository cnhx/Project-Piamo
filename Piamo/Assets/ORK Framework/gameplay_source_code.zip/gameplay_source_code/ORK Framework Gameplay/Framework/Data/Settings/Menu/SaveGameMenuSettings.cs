
using UnityEngine;

namespace ORKFramework
{
	public class SaveGameMenuSettings : BaseSettings
	{
		[ORKEditorHelp("Save Slots", "The number of available slots to save the game.", "")]
		[ORKEditorInfo("Save Game Settings", "Base save game settings, " +
			"e.g. number of available save slots, game load screen fading, etc.", "")]
		[ORKEditorLimit(1, false)]
		public int saveSlots = 3;
		
		// data settings
		[ORKEditorHelp("Save To", "Select where the save games will be stored:\n" +
			"- PlayerPrefs: The Unity PlayerPrefs are used.\n" +
			"- File: A file is saved using Application.persistentDataPath.\n" +
			"See the Unity Documentation for more information about where the file will be stored on the different platforms.", "")]
		[ORKEditorInfo(separator=true, labelText="Data Settings")]
		public SaveGameType saveGameType = SaveGameType.File;
		
		[ORKEditorHelp("Encrypt Data", "The save game data will be encrypted.\n" +
			"If not selected, the data is saved in plain text.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool encryptData = false;
		
		
		// screen fade in
		[ORKEditorHelp("Fade Out", "The screen will fade out.", "")]
		[ORKEditorInfo("Screen Fade Out", "The screen can fade out before loading the saved scene.", "")]
		public bool useFadeOut = true;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useFadeOut", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings fadeOut = new FadeColorSettings(0.5f, 0, 1);
		
		
		// screen fade out
		[ORKEditorHelp("Fade In", "The screen will fade in.", "")]
		[ORKEditorInfo("Screen Fade In", "The screen can fade in after loading the saved scene.", "")]
		public bool useFadeIn = true;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useFadeIn", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings fadeIn = new FadeColorSettings(0.5f, 1, 0);
		
		
		// save settings
		[ORKEditorHelp("Statistics", "Game statistics will be saved.", "")]
		[ORKEditorInfo("Save Settings", "Select the data of a running game that will be saved in a save game.", "", 
			labelText="Game Data")]
		public bool saveStatistics = true;
		
		[ORKEditorHelp("Game Time", "The current game time will be saved.", "")]
		public bool saveTime = true;
		
		[ORKEditorHelp("Groups", "The player groups (i.e. all combatants and their current levels, equipment, etc.) will be saved.", "")]
		public bool saveGroups = true;
		
		[ORKEditorHelp("Factions", "The factions (i.e. the sympathy values.) will be saved.", "")]
		public bool saveFactions = true;
		
		[ORKEditorHelp("Logs", "The learned logs will be saved.", "")]
		public bool saveLogs = true;
		
		[ORKEditorHelp("Quests", "The learned/finished quests will be saved.", "")]
		public bool saveQuests = true;
		
		[ORKEditorHelp("Positions", "The position of all group members will be saved.", "")]
		[ORKEditorLayout("saveGroups", true)]
		public bool saveGroupPosition = true;
		
		[ORKEditorHelp("Load Scene", "The scene that will be loaded when loading a game without group positions.", "")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public string saveSceneName = "";
		
		[ORKEditorHelp("Spawn ID", "The spawn point ID where the group (if saved) will spawn.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public int saveSpawnID = 0;
		
		[ORKEditorHelp("Block States", "The state of blocked Input Keys, Control Maps and HUDs will be saved.", "")]
		public bool saveBlockStates = true;
		
		// scene data
		[ORKEditorHelp("Save Boxes", "Select how the content of item boxes will be saved (using the box ID of item collectors):\n" +
			"- None: The content wont be saved, i.e. boxes will fill again when reentering a scene.\n" +
			"- Game: The content will be remebered in a running game.\n" +
			"- Save: The content will be saved in a save game.", "")]
		[ORKEditorInfo(separator=true, labelText="Scene Data", isEnumToolbar=true, toolbarWidth=75)]
		public SaveOption boxSaveOption = SaveOption.Save;
		
		[ORKEditorHelp("Save Items", "Select how collected items will be saved (using the scene ID of item collectors):\n" +
			"- None: Collected items wont be saved, i.e. they will reappear when reentering a scene.\n" +
			"- Game: Collected items will be remebered in a running game.\n" +
			"- Save: Collected items will be saved in a save game.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public SaveOption itemSaveOption = SaveOption.Save;
		
		[ORKEditorHelp("Save Drops", "Select how the item drops will be saved:\n" +
			"- None: Drops wont be saved, i.e. they will be gone when reentering a scene.\n" +
			"- Game: Drops will be remebered in a running game.\n" +
			"- Save: Drops will be saved in a save game.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public SaveOption dropSaveOption = SaveOption.None;
		
		[ORKEditorHelp("Save Battles", "Select how the battles using a scene ID will be saved:\n" +
			"- None: Finished battles wont be saved, i.e. they will reappear when reentering a scene.\n" +
			"- Game: Finished battles will be remebered in a running game.\n" +
			"- Save: Finished battles will be saved in a save game.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public SaveOption battlesSaveOption = SaveOption.Save;
		
		[ORKEditorHelp("Save Shops", "Select how the content of shops will be saved (using the shop ID):\n" +
			"- None: The content wont be saved, i.e. shops will reset again when opening them.\n" +
			"- Game: The content will be remebered in a running game.\n" +
			"- Save: The content will be saved in a save game.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public SaveOption shopsSaveOption = SaveOption.Save;
		
		[ORKEditorHelp("Object Variables", "Select how game variables bound to objects will be saved:\n" +
			"- None: The variables wont be saved, i.e. they wont be used at all.\n" +
			"- Game: The variables will be remebered in a running game.\n" +
			"- Save: The variables will be saved in a save game.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public SaveOption objectVariableOption = SaveOption.Save;
		
		[ORKEditorHelp("Scene Positions", "Save the stored scene positions of all scenes.", "")]
		public bool saveScenePosition = true;
		
		// inventory
		[ORKEditorHelp("Items", "All items in the inventory will be saved.", "")]
		[ORKEditorInfo(separator=true, labelText="Inventory Data")]
		public bool saveItems = true;
		
		[ORKEditorHelp("Weapons", "All weapons in the inventory will be saved.\n" +
			"Equipped weapons will only be saved if the party is saved.", "")]
		public bool saveWeapons = true;
		
		[ORKEditorHelp("Armors", "All armors in the inventory will be saved.\n" +
			"Equipped armors will only be saved if the party is saved.", "")]
		public bool saveArmors = true;
		
		[ORKEditorHelp("Recipes", "All learned crafting recipes will be saved", "")]
		public bool saveRecipes = true;
		
		[ORKEditorHelp("Money", "The current amount of money will be saved.", "")]
		public bool saveMoney = true;
		
		// game variables
		[ORKEditorHelp("Game Variables", "Select which game variables will be saved:\n" +
			"- None: No game variable will be saved.\n" +
			"- Select: Select which game variables will be saved.\n" +
			"- All: All game variables will be saved, but you can exclude specific variables.", "")]
		[ORKEditorInfo(separator=true, labelText="Game Variable Data", callbackAfter="check:gamevariables")]
		public Selector gameVariableSelector = Selector.All;
		
		[ORKEditorHelp("Game Variable Key", "The key (name) of the game variable.", "")]
		[ORKEditorInfo(endFoldout=true, hideName=true, setWidth=true, fieldWidth=400, isVariableField=true)]
		[ORKEditorArray(false, "Add Game Variable", "Adds a game variable to the list.", "", 
			"Remove", "Removes the game variable.", "", isHorizontal=true)]
		[ORKEditorLayout("gameVariableSelector", Selector.None, elseCheckGroup=true, endCheckGroup=true)]
		public string[] gameVariableList = new string[0];
		
		
		// file settings
		// file button
		[ORKEditorInfo("File Settings", "Set the content of the file buttons.", "", 
			labelText="File Info", callbackBefore="label:fileinfo")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageContent[] fileInfo = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"File %"});
		
		// empty button
		[ORKEditorInfo(separator=true, labelText="Empty File Info", callbackBefore="label:questioninfo", endFoldout=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageContent[] emptyInfo = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Empty %"});
		
		
		// auto save
		[ORKEditorHelp("File Name", "This text is used to display the index text of the auto save file.", "")]
		[ORKEditorInfo("Auto Save Settings", "The game can be automatically saved by " +
			"using AUTO_SAVE type save points.", "", 
			labelText="Auto File Name", expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] autoFileName = ArrayHelper.CreateArray(ORK.Languages.Count, "AUTO");
		
		[ORKEditorHelp("Show Message", "A message will be displayed when auto saving the game.", "")]
		[ORKEditorInfo(separator=true)]
		public bool showAutoSaveMessage = false;
		
		[ORKEditorHelp("GUI Box", "Select the GUI box used to display the message.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("showAutoSaveMessage", true)]
		public int autoBoxID = 0;
		
		[ORKEditorHelp("Visibility Time (s)", "The time in seconds the message will be displayed.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float autoVisibilityTime = 3;
		
		[ORKEditorHelp("Message", "The message that will be displayed.", "")]
		[ORKEditorInfo(separator=true, endFoldout=true, labelText="Auto Save Message", isTextArea=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string[] autoSaveMessage = ArrayHelper.CreateArray(ORK.Languages.Count, "Autosave");
		
		
		// save game menu
		[ORKEditorInfo("Save Game Menu", "Settings for the save file selection menu.", "", endFoldout=true)]
		public SaveGameChoice saveMenu = new SaveGameChoice();
		
		
		// load game menu
		[ORKEditorInfo("Load Game Menu", "Settings for the load file selection menu.", "", endFoldout=true)]
		public LoadGameChoice loadMenu = new LoadGameChoice();
		
		
		// save point
		[ORKEditorHelp("Show Choice", "A choice dialogue (save, load, cancel) is displayed when the player " +
			"interacts with a save point.\n" +
			"If not set, the save menu is shown.", "")]
		[ORKEditorInfo("Save Point Settings", "This settings determine the options " +
			"and appearance of the save point dialogue.", "")]
		public bool showSPChoice = true;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("showSPChoice", true, endCheckGroup=true)]
		public SavePointChoice savePoint = new SavePointChoice();
		
		public SaveGameMenuSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}
		
		public override void SetRealIDs()
		{
			
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "saveGameMenu"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}
		
		public override int Copy(int index)
		{
			return -1;
		}
		
		public override void Remove(int index)
		{
			
		}
		
		public override void Move(int index, bool down)
		{
			
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public GUIContent GetFileInfo()
		{
			return this.fileInfo[ORK.Game.Language].GetContent();
		}
		
		public GUIContent GetEmptyInfo()
		{
			return this.emptyInfo[ORK.Game.Language].GetContent();
		}
		
		public ChoiceContent[] GetFileList(bool isLoad)
		{
			ChoiceContent[] choice;
			int offset = 0;
			
			if(isLoad && ORK.SaveGame.FileExists(SaveGameHandler.AUTOSAVE_INDEX))
			{
				choice = new ChoiceContent[this.saveSlots + 2];
				offset = 1;
				choice[0] = new ChoiceContent(ORK.SaveGame.GetFileInfo(SaveGameHandler.AUTOSAVE_INDEX), true);
			}
			else
			{
				choice = new ChoiceContent[this.saveSlots + 1];
			}
			
			for(int i=0; i<choice.Length-offset-1; i++)
			{
				choice[i + offset] = new ChoiceContent(ORK.SaveGame.GetFileInfo(i), !isLoad || ORK.SaveGame.FileExists(i));
			}
			choice[choice.Length - 1] = new ChoiceContent(ORK.MenuSettings.GetCancelContent());
			return choice;
		}
		
		
		/*
		============================================================================
		Auto save functions
		============================================================================
		*/
		public void ShowAutoSaveMessage()
		{
			ORK.GUI.CreateInfoBox(this.autoSaveMessage[ORK.Game.Language], "", 
				this.autoBoxID, this.autoVisibilityTime, null, null, Vector2.zero).InitIn();
		}
		
		public string GetAutoName()
		{
			return this.autoFileName[ORK.Game.Language];
		}
		
		
		/*
		============================================================================
		Save file type functions
		============================================================================
		*/
		public bool IsPlayerPrefs()
		{
			return SaveGameType.PlayerPrefs.Equals(this.saveGameType);
		}
		
		public bool IsFile()
		{
			return SaveGameType.File.Equals(this.saveGameType);
		}
		
		
		/*
		============================================================================
		Save data functions
		============================================================================
		*/
		public bool CanSaveGameVariable(string key)
		{
			bool save = Selector.All.Equals(this.gameVariableSelector);
			for(int i=0; i<this.gameVariableList.Length; i++)
			{
				if(this.gameVariableList[i] == key)
				{
					save = !save;
					break;
				}
			}
			return save;
		}
	}
}

