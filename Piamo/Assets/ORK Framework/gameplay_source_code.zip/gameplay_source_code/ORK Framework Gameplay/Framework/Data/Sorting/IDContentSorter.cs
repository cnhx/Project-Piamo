
using System.Collections.Generic;

namespace ORKFramework
{
	public class IDContentSorter : IComparer<IContent>
	{
		private bool invert = false;
		
		public IDContentSorter(bool invert)
		{
			this.invert = invert;
		}
		
		public int Compare(IContent x , IContent y)
		{
			if(this.invert)
			{
				return y.ID.CompareTo(x.ID);
			}
			else
			{
				return x.ID.CompareTo(y.ID);
			}
		}
	}
}
