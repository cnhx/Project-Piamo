
using System.IO;
using System.Collections.Generic;
using UnityEngine;

namespace ORKFramework
{
	public class BackupSettings : BaseSettings
	{
		[ORKEditorHelp("Number of Backups", "Set how many backups of your ORK project data will be stored.\n" +
			"Set to 0 if you don't want to keep any backups.", "")]
		[ORKEditorInfo("Backup Settings", "General backup settings.", "", endFoldout=true)]
		public int numberOfBackups = 10;
		
		public BackupSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}
		
		public override void SetRealIDs()
		{
			
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "backupSettings"; }
		}
		
		
		/*
		============================================================================
		Backup functionality
		============================================================================
		*/
		public bool CreateBackupDirectory()
		{
			if(!Directory.Exists(ORK.BACKUP_PATH))
			{
				Directory.CreateDirectory(ORK.BACKUP_PATH);
				return true;
			}
			return false;
		}
		
		public List<string> GetBackupList()
		{
			if(Application.isEditor && Directory.Exists(ORK.BACKUP_PATH))
			{
				return new List<string>(Directory.GetFiles(ORK.BACKUP_PATH));
			}
			return new List<string>();
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}
		
		public override int Copy(int index)
		{
			return -1;
		}
		
		public override void Remove(int index)
		{
			
		}
		
		public override void Move(int index, bool down)
		{
			
		}
	}
}

