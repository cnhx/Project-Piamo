
using UnityEngine;

namespace ORKFramework
{
	public class InventorySettings : BaseSettings
	{
		// editor help text display
		[ORKEditorHelp("Inventory Type", "Select the inventory type.\n" +
			"- Group: The whole player group shares an inventory.\n" +
			"- Individual: Each group member has its own inventory. This means " +
			"they can only use items from their own inventory.", "")]
		[ORKEditorInfo("Inventory Settings", "Base inventory management settings.", "", 
			isEnumToolbar=true, labelText="Limit Settings")]
		public CombatantScope type = CombatantScope.Group;
		
		[ORKEditorHelp("Auto Stack", "Items are automatically stacked, i.e. items that are equal will be grouped together.\n" +
			"If disabled, items will be left individually, even if other items of the same kind are already in the inventory.", "")]
		public bool autoStack = true;
		
		
		// quantity limit
		[ORKEditorHelp("Quantity Limit", "Items, weapons and armors are limited by a maximum quantity (individually).\n" +
			"If disabled, there is no general quantity limit.\n" +
			"Items, weapons and armors can override the quantity limit settings.", "")]
		[ORKEditorInfo(separator=true, labelText="Quantity Limit")]
		public bool limitQuantity = false;
		
		[ORKEditorHelp("Maximum Quantity", "The maximum quantity that can be in the inventory of each item, weapon and armor.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("limitQuantity", true, endCheckGroup=true)]
		public int quantityLimit = 99;
		
		
		// space limit
		[ORKEditorHelp("Space Limit", "The inventory will be limited by space - items, weapons and armors will occupy space.\n" +
			"If disabled, there is no inventory limit and items, weapons and armors can be added without limitations.", "")]
		[ORKEditorInfo(separator=true, labelText="Space Limit")]
		public bool limit = false;
		
		[ORKEditorInfo("Limit Value", "Define the inventory limit.\n" +
			"If group inventory is used, the limit is calculated by summing up the value for all active group members.", "", 
			endFoldout=true, separatorForce=true)]
		[ORKEditorLayout("limit", true, autoInit=true)]
		public FloatValue limitValue;
		
		[ORKEditorHelp("Block Adding", "Items, weapons and armors can't be added if the inventory limit is reached.", "")]
		public bool blockAdd = false;
		
		[ORKEditorArray(true, "Add Effect Cast", "Adds an effect cast. " +
			"The status effect will be cast on the inventory owner when the inventory is filled to a defined percentage.", "", 
			"Remove", "Removes this effect cast.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public InventoryFullCast[] fullCast = new InventoryFullCast[0];
		
		
		// drop item settings
		[ORKEditorHelp("Drop On Ground", "The item will be spawned on the ground (using a raycast, see the Unity documentations for details).", "")]
		[ORKEditorInfo("Drop Item Settings", "Items, equipment and money can be  dropped into the game world by the player or defeated combatants.", "")]
		public bool dropOnGround = false;
		
		[ORKEditorHelp("Layer Mask", "The layer mask used for the raycast.", "")]
		[ORKEditorLayout("dropOnGround", true, endCheckGroup=true)]
		public LayerMask dropMask = -1;
		
		[ORKEditorHelp("Collector Start Type", "Select how dropped items can be collected.", "")]
		public EventStartType dropStartType = EventStartType.Interact;
		
		[ORKEditorHelp("Offset X", "The offset added to the position of the combatant who drops the item.\n" +
			"The X and Y values are used for random calculation.\n" +
			"E.g. X=1 and Y=-1: The item will be dropped at a random offset between 1 and -1 on the X-axis.", "")]
		[ORKEditorInfo(separator=true, labelText="Offset Settings")]
		public Vector2 dropOffsetX = new Vector2(1, -1);
		
		[ORKEditorHelp("Offset Y", "The offset added to the position of the combatant who drops the item.\n" +
			"The X and Y values are used for random calculation.\n" +
			"E.g. X=1 and Y=-1: The item will be dropped at a random offset between 1 and -1 on the Y-axis.", "")]
		public Vector2 dropOffsetY = new Vector2(1, -1);
		
		[ORKEditorHelp("Offset Z", "The offset added to the position of the combatant who drops the item.\n" +
			"The X and Y values are used for random calculation.\n" +
			"E.g. X=1 and Y=-1: The item will be dropped at a random offset between 1 and -1 on the Z-axis.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public Vector2 dropOffsetZ = new Vector2(1, 1);
		
		
		// item collection
		[ORKEditorInfo("Item Collection", "This settings are used by item collectors when " +
			"picking up single or random items, equipment or money in a scene.", "", endFoldout=true)]
		public ItemCollectionChoice itemCollection = new ItemCollectionChoice();
		
		
		// item box
		[ORKEditorInfo("Item Box", "This settings are used by item collectors when " +
			"picking up items, equipment or money from a box in a scene.", "", endFoldout=true)]
		public ItemBoxChoice itemBoxCollection = new ItemBoxChoice();
		
		
		// crafting layout
		[ORKEditorInfo("Default Recipe Layout", "The crafting recipe layout is used in " +
			"crafting menus to display information about a crafting recipe.\n" +
			"The default layout can be overridden by crafting recipes and crafting menus.", "", endFoldout=true)]
		public CraftingRecipeLayout craftignLayout = new CraftingRecipeLayout();
		
		
		// notifications
		[ORKEditorInfo("Notification Settings", "Inventory changes and crafting recipes can display notifications.", "", 
			endFoldout=true)]
		public InventoryNotificationSettings notifications = new InventoryNotificationSettings();
		
		public InventorySettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}
		
		public override void SetRealIDs()
		{
			
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "inventorySettings"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}
		
		public override int Copy(int index)
		{
			return -1;
		}
		
		public override void Remove(int index)
		{
			
		}
		
		public override void Move(int index, bool down)
		{
			
		}
		
		public bool IsGroup()
		{
			return CombatantScope.Group.Equals(this.type);
		}
		
		public bool IsIndividual()
		{
			return CombatantScope.Individual.Equals(this.type);
		}
		
		public void AddDropOffset(ref Vector3 position)
		{
			position += new Vector3(
				Random.Range(this.dropOffsetX.x, this.dropOffsetX.y), 
				Random.Range(this.dropOffsetY.x, this.dropOffsetY.y), 
				Random.Range(this.dropOffsetZ.x, this.dropOffsetZ.y));
			
		}
	}
}

