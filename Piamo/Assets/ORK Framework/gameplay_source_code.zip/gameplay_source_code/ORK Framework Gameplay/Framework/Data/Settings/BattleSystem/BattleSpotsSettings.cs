
using UnityEngine;

namespace ORKFramework
{
	public class BattleSpotsSettings : BaseSettings
	{
		// default battle spots
		[ORKEditorHelp("Use Y Rotation", "Use the battle spot's rotation of the Y-axis when spawning combatants.\n" +
			"If disabled, the rotation of a spawned combatant wont be changed.", "")]
		[ORKEditorInfo("Base Settings", "Base settings for battle spots.\n" +
			"Battle spots are used in arena battles when no a combatant needs a spot that hasn't been defined in the scene.\n" +
			"The combatants are placed at the positions of battle spots at the start of the battle.", "")]
		public bool useYRotation = true;
		
		[ORKEditorHelp("Use Scale", "Use the battle spot's scale (localScale) when spawning combatants.\n" +
			"If disabled, the scale of a spawned combatant wont be changed.", "")]
		public bool useScale = false;
		
		// place on ground
		[ORKEditorHelp("Place On Ground", "The battle spots will be placed directly on the ground, using a raycast to find the ground.\n" +
			"If disabled, the battle spots will remain at their original position.", "")]
		[ORKEditorInfo(separator=true)]
		public bool onGround = false;
		
		[ORKEditorHelp("Distance", "The distance used for the raycast.", "")]
		[ORKEditorLayout("onGround", true)]
		public float distance = 100.0f;
		
		[ORKEditorHelp("Layer Mask", "The layer mask used for the raycast.\n" +
			"Select the layers that will be recognized as the ground.", "")]
		public LayerMask layerMask = -1;
		
		[ORKEditorInfo(endFoldout=true, labelText="Raycast Random Offset")]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public RandomVector3 rayOffset;
		
		
		// player spots
		[ORKEditorInfo("Player Spots", "Default battle spots of the player group.", "", 
			callbackBefore="check:spots")]
		[ORKEditorArray(false, foldout=true, foldoutText=new string[] {
			"Member", "Define the default battle spot for this member of the player group.", ""
		})]
		public GroupSpots[] playerSpot = ArrayHelper.CreateArray<GroupSpots>(ORK.GameSettings.maxBattleGroup);
		
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Additional Spot", callbackBefore="label:additional")]
		public BattleSpot playerExtra = new BattleSpot();
		
		
		// ally spots
		[ORKEditorInfo("Ally Spots", "Default battle spots of combatants who are allies of the player.", "")]
		[ORKEditorArray(false, "Add Ally Spot", "Adds a ally battle spot.", "", 
			"Remove", "Removes this ally spot.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Member", "Define the default battle spot for this member of ally groups.", ""
		})]
		public GroupSpots[] allySpot = new GroupSpots[0];
		
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Additional Spot", callbackBefore="label:additional")]
		public BattleSpot allyExtra = new BattleSpot();
		
		
		// enemy spots
		[ORKEditorInfo("Enemy Spots", "Default battle spots of combatants who are enemies of the player.", "")]
		[ORKEditorArray(false, "Add Enemy Spot", "Adds an enemy battle spot.", "", 
			"Remove", "Removes this enemy spot.", "", isCopy=true, isMove=true, 
			foldout=true, foldoutText=new string[] {
				"Member", "Define the default battle spot for this member of enemy groups.", ""
		})]
		public GroupSpots[] enemySpot = new GroupSpots[0];
		
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Additional Spot", callbackBefore="label:additional")]
		public BattleSpot enemyExtra = new BattleSpot();
		
		public BattleSpotsSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}
		
		public override void SetRealIDs()
		{
			
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "battleSpots"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}
		
		public override int Copy(int index)
		{
			return -1;
		}
		
		public override void Remove(int index)
		{
			
		}
		
		public override void Move(int index, bool down)
		{
			
		}
		
		
		/*
		============================================================================
		Battle spot functions
		============================================================================
		*/
		public Vector3 GetPlayerSpot(int index, GroupAdvantageType advantage)
		{
			if(index >= 0 && index < this.playerSpot.Length)
			{
				return this.playerSpot[index].GetSpot(advantage);
			}
			return this.playerExtra.GetSpot();
		}
		
		public Vector3 GetAllySpot(int index, GroupAdvantageType advantage)
		{
			if(index >= 0 && index < this.allySpot.Length)
			{
				return this.allySpot[index].GetSpot(advantage);
			}
			return this.allyExtra.GetSpot();
		}
		
		public Vector3 GetEnemySpot(int index, GroupAdvantageType advantage)
		{
			if(index >= 0 && index < this.enemySpot.Length)
			{
				return this.enemySpot[index].GetSpot(advantage);
			}
			return this.enemyExtra.GetSpot();
		}
	}
}
