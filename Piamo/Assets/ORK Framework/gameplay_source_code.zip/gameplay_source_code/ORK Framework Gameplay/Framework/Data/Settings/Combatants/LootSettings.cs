
using UnityEngine;
using ORKFramework.AI;

namespace ORKFramework
{
	public class LootSettings : BaseSettings
	{
		public Loot[] data = new Loot[] {new Loot("Default Loot")};
		
		public LootSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
			this.SetRealIDs(this.data);
		}
		
		public override void SetRealIDs()
		{
			this.SetRealIDs(this.data);
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "loot"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			if(index >= 0 && index < this.data.Length)
			{
				return this.data[index].name;
			}
			else
			{
				return "Loot(" + index + ") not found";
			}
		}

		public override string[] GetNames(bool addIndex)
		{
			string[] names = new string[this.data.Length];
			for(int i=0; i<names.Length; i++)
			{
				if(addIndex)
				{
					names[i] = i + ": " + this.data[i].name;
				}
				else
				{
					names[i] = this.data[i].name;
				}
			}
			return names;
		}
		
		public override int Count
		{
			get{ return this.data.Length;}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			ArrayHelper.Add(ref this.data, new Loot("New"));
			DataHelper.Added(ORKDataType.Loot);
			return this.data.Length - 1;
		}
		
		public override int Copy(int index)
		{
			ArrayHelper.Add(ref this.data, this.GetCopy(index));
			DataHelper.Added(ORKDataType.Loot);
			return this.data.Length - 1;
		}
		
		public Loot GetCopy(int index)
		{
			Loot t = new Loot();
			if(index >= 0 && index < this.data.Length)
			{
				t.SetData(this.data[index].GetData());
			}
			return t;
		}
		
		public override void Remove(int index)
		{
			ArrayHelper.RemoveAt(ref this.data, index);
			DataHelper.Removed(ORKDataType.Loot, index);
		}
		
		public Loot Get(int index)
		{
			if(index >= 0 && index < this.Count)
			{
				return this.data[index];
			}
			else
			{
				return this.data[0];
			}
		}
		
		public override void Move(int index, bool down)
		{
			if(down)
			{
				ArrayHelper.MoveDown(ref this.data, index);
			}
			else
			{
				ArrayHelper.MoveUp(ref this.data, index);
			}
			DataHelper.Moved(ORKDataType.Loot, down, index);
		}
	}
}
